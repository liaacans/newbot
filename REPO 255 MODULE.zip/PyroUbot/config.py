import os
from dotenv import load_dotenv

load_dotenv(".env")

MAX_BOT = int(os.getenv("MAX_BOT", "9999"))

DEVS = list(map(int, os.getenv("DEVS", "7637070288").split()))

API_ID = int(os.getenv("API_ID", "37193955"))

API_HASH = os.getenv("API_HASH", "b46a4ee710c6af3afdbdaf054df805df")

BOT_TOKEN = os.getenv("BOT_TOKEN", "8677519583:AAF6jHA3kgcwFiKbg44Pb3vUaE6WxPp1fc4")

OWNER_ID = int(os.getenv("OWNER_ID", "7637070288"))

BLACKLIST_CHAT = list(map(int, os.getenv("BLACKLIST_CHAT", "-1003659966140").split()))

RMBG_API = os.getenv("RMBG_API", "a6qxsmMJ3CsNo7HyxuKGsP1o")

MONGO_URL = os.getenv("MONGO_URL", "mongodb+srv://rkhoirulbashar_db_user:CdHHAehaI7TWIQcm@cluster0.7bd6kkq.mongodb.net/?appName=Cluster0")

LOGS_MAKER_UBOT = int(os.getenv("LOGS_MAKER_UBOT", "-1003659966140"))