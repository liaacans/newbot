const fs = require("fs");

const settings = require("../settings.js");
const OWNER_ID = "./db/onlyID.json";
const ALLOWED_GROUP_ID = settings.groupId;

const {
    domain,
    plta,
    pltc,
    domainV2,
    pltaV2,
    pltcV2,
    domainV3,
    pltaV3,
    pltcV3,
    domainV4,
    pltaV4,
    pltcV4,
    domainV5,
    pltaV5,
    pltcV5,
    eggs,
    loc,
    dev,
    panel
} = settings;


// database cooldown
const COOLDOWN_FILE = "./db/cooldown.json";
const cooldowns = {};

function loadCooldown() {
  if (!fs.existsSync(COOLDOWN_FILE)) {
    fs.writeFileSync(COOLDOWN_FILE, JSON.stringify({ globalCooldown: 5000 }, null, 2));
  }
  return JSON.parse(fs.readFileSync(COOLDOWN_FILE));
}

function saveCooldown(data) {
  fs.writeFileSync(COOLDOWN_FILE, JSON.stringify(data, null, 2));
}

// fungsi checkCooldown
function checkCooldown(msg) {
  const db = loadCooldown();
  const userId = msg.from.id.toString();
  const now = Date.now();

  if (!cooldowns[userId]) {
    cooldowns[userId] = now;
    return false;
  }

  const diff = now - cooldowns[userId];
  if (diff < db.globalCooldown) {
    const sisa = Math.ceil((db.globalCooldown - diff) / 1000);
    return `⏳ ᴛᴜɴɢɢᴜ ${sisa} ᴅᴇᴛɪᴋ ʟᴀɢɪ sᴇʙᴇʟᴜᴍ ᴘᴀᴋᴀɪ ᴄᴏᴍᴍᴀɴᴅ ɪɴɪ!`;
  }

  cooldowns[userId] = now;
  return false;
}

// fungsi load json file
function loadJsonData(filename) {
    try {
        if (fs.existsSync(filename)) {
            const data = fs.readFileSync(filename, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.error(`Error loading ${filename}:`, error);
    }
    return [];
}

// fungsi save json file
function saveJsonData(filename, data) {
    try {
        fs.writeFileSync(filename, JSON.stringify(data, null, 4));
        return true;
    } catch (error) {
        console.error(`Error saving ${filename}:`, error);
        return false;
    }
}

const ADP_FILE = "./db/adp.json";
const CADP_FILE = "./db/cadp.json";

function loadAdp() {
  if (!fs.existsSync(ADP_FILE)) return [];
  return JSON.parse(fs.readFileSync(ADP_FILE));
}

function saveAdp(data) {
  fs.writeFileSync(ADP_FILE, JSON.stringify(data, null, 2));
}

// file database
const OWNER_FILE = './db/users/adminID.json';

const PREMIUM_FILE = './db/users/premiumUsers.json';
const PREMV2_FILE = './db/users/version/premiumV2.json';
const PREMV3_FILE = './db/users/version/premiumV3.json';
const PREMV4_FILE = './db/users/version/premiumV4.json';
const PREMV5_FILE = './db/users/version/premiumV5.json';

const RESS_FILE = './db/users/resellerUsers.json';
const RESSV2_FILE = './db/users/version/resellerV2.json';
const RESSV3_FILE = './db/users/version/resellerV3.json';
const RESSV4_FILE = './db/users/version/resellerV4.json';
const RESSV5_FILE = './db/users/version/resellerV5.json';

module.exports = (bot) => {
    // log command
function notifyOwner(commandName, msg) {
    const userId = msg.from.id;
    const username = msg.from.username || msg.from.first_name;
    const chatId = msg.chat.id;
    const now = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });

    const logMessage = `<pre>📌 Command: /${commandName}
👤 User: @${username}
🆔 ID: ${userId}
🕒 Waktu: ${now}
</pre>
    `;
    bot.sendMessage(OWNER_ID, logMessage, { parse_mode: 'HTML' });
}
    
// cadp
bot.onText(/\/cadp(?:\s+(.+))?/, async (msg, match) => {
  notifyOwner('cadp', msg);
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const text = match[1] ? match[1].trim() : null;

  if (msg.chat.type !== "group" && msg.chat.type !== "supergroup") {
    bot.sendMessage(chatId, "❌ ᴋʜᴜꜱᴜꜱ ɢʀᴜᴘ!");
    return;
  }

  const isCooldown = checkCooldown(msg);
  if (isCooldown) return bot.sendMessage(chatId, isCooldown);

  const premiumUsers = JSON.parse(fs.readFileSync(PREMIUM_FILE));
  const isPremium = premiumUsers.includes(String(userId));
  if (!isPremium) {
    bot.sendMessage(chatId, "❌ ᴍɪɴᴛᴀ ᴄʀᴇᴀᴛᴇ ᴅᴜʟᴜ ꜱᴀᴍᴀ ᴏᴡɴᴇʀ!", {
      reply_markup: {
        inline_keyboard: [[{ text: "ʟᴀᴘᴏʀᴀɴ", url: `https://t.me/@${dev}` }]],
      },
    });
    return;
  }

  // cek argumen
  if (!text) {
    bot.sendMessage(chatId, "❌ Format Salah!\nContoh: /cadp namapanel,idtele");
    return;
  }

  const commandParams = text.split(",");
  if (commandParams.length < 2) {
    bot.sendMessage(chatId, "❌ Format Salah!\nContoh: /cadp namapanel,idtele");
    return;
  }

  bot.sendMessage(chatId, "⏳");

  const panelName = commandParams[0].trim();
  const telegramId = commandParams[1].trim();
  const password = panelName + Math.random().toString(36).slice(2, 5);

  const adpData = loadAdp();
  adpData.push({
    userId: userId,
    panelName: panelName,
    domain: domain,
    tokenA: plta,
    tokenC: pltc,
  });
  saveAdp(adpData);

  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        email: `${panelName}@admin.king`,
        username: panelName,
        first_name: panelName,
        last_name: "admin",
        language: "en",
        root_admin: true,
        password: password,
      }),
    });

    const data = await response.json();
    if (data.errors) {
      bot.sendMessage(chatId, JSON.stringify(data.errors[0], null, 2));
      return;
    }

    const user = data.attributes;
    const userInfo = `
TYPE: ADMIN PANEL
➟ ID: ${user.id}
➟ USERNAME: ${user.username}
➟ EMAIL: ${user.email}
➟ NAME: ${user.first_name} ${user.last_name}
➟ ADMIN: ${user.root_admin}`;
    bot.sendMessage(chatId, userInfo);

    bot.sendPhoto(telegramId, panel, {
      caption: `<b>🔐 Sukses Created Admin Panel!</b>
▸ ID User: ${user.id}

⚠️ Mencegah kerusuhan dalam panel, akses anda dibatasi hanya melihat token!
<blockquote>ketik: /adpinfo ${panelName}</blockquote>

<b>📌 Rules Admin Panel</b>
▸ No Rusuh Panel!
▸ Simpan data akun
▸ No Share Free!
`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "🌐 Domain", url: domain },
            { text: "🔑 Salin Password", switch_inline_query_current_chat: password },
          ],
        ],
      },
    });

    bot.sendMessage(
      chatId,
      `✅ *Berhasil kirim Admin panel ke @${msg.from.username}*\n(ID: ${telegramId})`,
      { parse_mode: "Markdown", reply_to_message_id: msg.message_id }
    );

    let db = [];
    if (fs.existsSync(CADP_FILE)) {
      db = JSON.parse(fs.readFileSync(CADP_FILE));
    }
    if (!db.includes(String(userId))) {
      db.push(String(userId));
      fs.writeFileSync(CADP_FILE, JSON.stringify(db, null, 2));
    }
  } catch (error) {
    console.error(error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan dalam pembuatan admin. Silakan coba lagi nanti."
    );
  }
});

    // cadpv2
bot.onText(/\/cadpv2(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const text = match[1];
    
  if (msg.chat.type !== "group" && msg.chat.type !== "supergroup") {
  bot.sendMessage(msg.chat.id, "❌ ᴋʜᴜꜱᴜꜱ ɢʀᴜᴘ!");
  return;
  }
    
  const premV2Users = JSON.parse(fs.readFileSync(PREMV2_FILE));
  const isPremiumV2 = premV2Users.includes(String(msg.from.id));   
      if (!isPremiumV2) {
    bot.sendMessage(chatId, "❌ ᴋʜᴜꜱᴜꜱ ᴘʀᴇᴍɪᴜᴍ ᴠ2!", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ᴊᴏɪɴ ꜱᴇʀᴠᴇʀ", url: `https://t.me/${dev}` }],
        ],
      },
    });
    return;
  }
  
  const commandParams = match[1].split(",");
if (commandParams.length < 2) {
  bot.sendMessage(
    chatId,
    "❌ Format Salah! Penggunaan: /cadpv2 nama,idtele"
  );
  return;
}

  const panelName = commandParams[0].trim();
  const telegramId = commandParams[1].trim();

  const password = panelName + Math.random().toString(36).slice(2, 5);
    
  try {
    const response = await fetch(`${domainV2}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${pltaV2}`,
      },
      body: JSON.stringify({
        email: `${panelName}@admin.nael`,
        username: panelName,
        first_name: panelName,
        last_name: "admin",
        language: "en",
        root_admin: true,
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      bot.sendMessage(chatId, JSON.stringify(data.errors[0], null, 2));
      return;
    }
    const user = data.attributes;
    const userInfo = `
TYPE: ADMIN PANEL V2
➟ ID: ${user.id}
➟ USERNAME: ${user.username}
➟ EMAIL: ${user.email}
➟ NAME: ${user.first_name} ${user.last_name}
➟ LANGUAGE: ${user.language}
➟ ADMIN: ${user.root_admin}
➟ CREATED AT: ${user.created_at}
    `;
    bot.sendMessage(chatId, userInfo);
     
    const caption = `🔐 Sukses Created Admin Panel V2!

👤 Username: <code>${user.username}</code>
🔑 Password: <code>${password}</code>
🌐 Login: ${domainV2}

<blockquote>📌 Catatan :
Simpan informasi data ini dengan aman
dan jangan bagikan ke orang lain!
</blockquote>
`;

bot.sendPhoto(telegramId, panel, { caption, parse_mode: "HTML" });
   
  } catch (error) {
    console.error(error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan dalam pembuatan admin. Silakan coba lagi nanti."
    );
  }
});
 
    // cadpv3
bot.onText(/\/cadpv3(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const text = match[1];
    
  if (msg.chat.type !== "group" && msg.chat.type !== "supergroup") {
  bot.sendMessage(msg.chat.id, "❌ ᴋʜᴜꜱᴜꜱ ɢʀᴜᴘ!");
  return;
}
    
  const premV3Users = JSON.parse(fs.readFileSync(PREMV3_FILE));
  const isPremiumV3 = premV3Users.includes(String(msg.from.id));   
      if (!isPremiumV3) {
    bot.sendMessage(chatId, "❌ ᴋʜᴜꜱᴜꜱ ᴘʀᴇᴍɪᴜᴍ ᴠ3!", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ᴊᴏɪɴ ꜱᴇʀᴠᴇʀ", url: `https://t.me/${dev}` }],
        ],
      },
    });
    return;
  }
  
  const commandParams = match[1].split(",");
if (commandParams.length < 2) {
  bot.sendMessage(
    chatId,
    "❌ Format Salah! Penggunaan: /cadpv3 nama,idtele"
  );
  return;
}

  const panelName = commandParams[0].trim();
  const telegramId = commandParams[1].trim();

  const password = panelName + Math.random().toString(36).slice(2, 5);
    
  try {
    const response = await fetch(`${domainV3}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${pltaV3}`,
      },
      body: JSON.stringify({
        email: `${panelName}@admin.nael`,
        username: panelName,
        first_name: panelName,
        last_name: "admin",
        language: "en",
        root_admin: true,
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      bot.sendMessage(chatId, JSON.stringify(data.errors[0], null, 2));
      return;
    }
    const user = data.attributes;
    const userInfo = `
TYPE: ADMIN PANEL V3
➟ ID: ${user.id}
➟ USERNAME: ${user.username}
➟ EMAIL: ${user.email}
➟ NAME: ${user.first_name} ${user.last_name}
➟ LANGUAGE: ${user.language}
➟ ADMIN: ${user.root_admin}
➟ CREATED AT: ${user.created_at}
    `;
    bot.sendMessage(chatId, userInfo);
     
    const caption = `🔐 Sukses Created Admin Panel V3!

👤 Username: <code>${user.username}</code>
🔑 Password: <code>${password}</code>
🌐 Login: ${domainV3}

<blockquote>📌 Catatan :
Simpan informasi data ini dengan aman
dan jangan bagikan ke orang lain!
</blockquote>
`;

bot.sendPhoto(telegramId, panel, { caption, parse_mode: "HTML" });
   
  } catch (error) {
    console.error(error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan dalam pembuatan admin. Silakan coba lagi nanti."
    );
  }
});
    
    // cadpv4
bot.onText(/\/cadpv4(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const text = match[1];
    
  if (msg.chat.type !== "group" && msg.chat.type !== "supergroup") {
  bot.sendMessage(msg.chat.id, "❌ ᴋʜᴜꜱᴜꜱ ɢʀᴜᴘ!");
  return;
}
    
  const premV4Users = JSON.parse(fs.readFileSync(PREMV4_FILE));
  const isPremiumV4 = premV4Users.includes(String(msg.from.id));   
      if (!isPremiumV4) {
    bot.sendMessage(chatId, "❌ ᴋʜᴜꜱᴜꜱ ᴘʀᴇᴍɪᴜᴍ ᴠ4!", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ᴊᴏɪɴ ꜱᴇʀᴠᴇʀ", url: `https://t.me/${dev}` }],
        ],
      },
    });
    return;
  }
  
  const commandParams = match[1].split(",");
if (commandParams.length < 2) {
  bot.sendMessage(
    chatId,
    "❌ Format Salah! Penggunaan: /cadpv4 nama,idtele"
  );
  return;
}

  const panelName = commandParams[0].trim();
  const telegramId = commandParams[1].trim();

  const password = panelName + Math.random().toString(36).slice(2, 5);
    
  try {
    const response = await fetch(`${domainV4}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${pltaV4}`,
      },
      body: JSON.stringify({
        email: `${panelName}@admin.nael`,
        username: panelName,
        first_name: panelName,
        last_name: "admin",
        language: "en",
        root_admin: true,
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      bot.sendMessage(chatId, JSON.stringify(data.errors[0], null, 2));
      return;
    }
    const user = data.attributes;
    const userInfo = `
TYPE: ADMIN PANEL V4
➟ ID: ${user.id}
➟ USERNAME: ${user.username}
➟ EMAIL: ${user.email}
➟ NAME: ${user.first_name} ${user.last_name}
➟ LANGUAGE: ${user.language}
➟ ADMIN: ${user.root_admin}
➟ CREATED AT: ${user.created_at}
    `;
    bot.sendMessage(chatId, userInfo);
     
    const caption = `🔐 Sukses Created Admin Panel V4!

👤 Username: <code>${user.username}</code>
🔑 Password: <code>${password}</code>
🌐 Login: ${domainV4}

<blockquote>📌 Catatan :
Simpan informasi data ini dengan aman
dan jangan bagikan ke orang lain!
</blockquote>
`;

bot.sendPhoto(telegramId, panel, { caption, parse_mode: "HTML" });
   
  } catch (error) {
    console.error(error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan dalam pembuatan admin. Silakan coba lagi nanti."
    );
  }
});
    
    // cadpv5
bot.onText(/\/cadpv5(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const text = match[1];
    
  if (msg.chat.type !== "group" && msg.chat.type !== "supergroup") {
  bot.sendMessage(msg.chat.id, "❌ ᴋʜᴜꜱᴜꜱ ɢʀᴜᴘ!");
  return;
}
    
  const premV5Users = JSON.parse(fs.readFileSync(PREMV5_FILE));
  const isPremiumV5 = premV5Users.includes(String(msg.from.id));   
      if (!isPremiumV5) {
    bot.sendMessage(chatId, "❌ ᴋʜᴜꜱᴜꜱ ᴘʀᴇᴍɪᴜᴍ ᴠ5!", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ᴊᴏɪɴ ꜱᴇʀᴠᴇʀ", url: `https://t.me/${dev}` }],
        ],
      },
    });
    return;
  }
  
  const commandParams = match[1].split(",");
if (commandParams.length < 2) {
  bot.sendMessage(
    chatId,
    "❌ Format Salah! Penggunaan: /cadpv5 nama,idtele"
  );
  return;
}

  const panelName = commandParams[0].trim();
  const telegramId = commandParams[1].trim();

  const password = panelName + Math.random().toString(36).slice(2, 5);
    
  try {
    const response = await fetch(`${domainV5}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${pltaV5}`,
      },
      body: JSON.stringify({
        email: `${panelName}@admin.nael`,
        username: panelName,
        first_name: panelName,
        last_name: "admin",
        language: "en",
        root_admin: true,
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      bot.sendMessage(chatId, JSON.stringify(data.errors[0], null, 2));
      return;
    }
    const user = data.attributes;
    const userInfo = `
TYPE: ADMIN PANEL V5
➟ ID: ${user.id}
➟ USERNAME: ${user.username}
➟ EMAIL: ${user.email}
➟ NAME: ${user.first_name} ${user.last_name}
➟ LANGUAGE: ${user.language}
➟ ADMIN: ${user.root_admin}
➟ CREATED AT: ${user.created_at}
    `;
    bot.sendMessage(chatId, userInfo);
     
    const caption = `🔐 Sukses Created Admin Panel V5!

👤 Username: <code>${user.username}</code>
🔑 Password: <code>${password}</code>
🌐 Login: ${domainV5}

<blockquote>📌 Catatan :
Simpan informasi data ini dengan aman
dan jangan bagikan ke orang lain!
</blockquote>
`;

bot.sendPhoto(telegramId, panel, { caption, parse_mode: "HTML" });
   
  } catch (error) {
    console.error(error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan dalam pembuatan admin. Silakan coba lagi nanti."
    );
  }
});
    
bot.onText(/\/listcadp/, (msg) => {
  const chatId = msg.chat.id;

  if (!fs.existsSync(CADP_FILE)) {
    return bot.sendMessage(chatId, "❌ Tidak ada data user tersimpan.");
  }

  const db = JSON.parse(fs.readFileSync(CADP_FILE));

  if (db.length === 0) {
    return bot.sendMessage(chatId, "❌ Belum ada user yang tercatat.");
  }

  let text = "<b>📋 User yang /cadp:</b>\n\n";
  db.forEach((id, index) => {
    text += `${index + 1}. <code>${id}</code>\n`;
  });

  bot.sendMessage(chatId, text, { parse_mode: "HTML" });
});

    // adpinfo
bot.onText(/\/adpinfo(?:\s+(.+))?/, (msg, match) => {
  notifyOwner('adpinfo', msg);
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const panelQuery = match[1].trim();
  const text = match[1];
    
  if (!text) {
      return bot.sendMessage(chatId,
"❌ Format salah!\nContoh: /adpinfo namaAdp");
  }
    
  if (msg.chat.type !== "private") {
    return bot.sendMessage(chatId, "❌ ᴋʜᴜꜱᴜꜱ ᴘʀɪᴠᴀᴛᴇ ᴄʜᴀᴛ!", {
      reply_to_message_id: msg.message_id
    });
  }
    
  const adpData = loadAdp();
  const userPanel = adpData.find(
  (u) => u.panelName === panelQuery && u.userId === userId
  );

  if (!userPanel) {
    bot.sendMessage(chatId, `❌ ɴᴀᴍᴀ ᴀᴅᴘ ${panelQuery} ᴛɪᴅᴀᴋ ᴀᴅᴀ ᴅɪ ᴅᴀᴛᴀʙᴀꜱᴇ!`);
  } else if (userPanel.userId !== userId)
  {
    bot.sendMessage(chatId, `❌ ᴄᴏᴍᴍᴀɴᴅ ʜᴀɴʏᴀ ʙɪꜱᴀ ᴅɪɢᴜɴᴀᴋᴀɴ ᴏʟᴇʜ ᴜsᴇʀ ʏᴀɴɢ ᴄʀᴇᴀᴛᴇ ᴀᴅᴘ! ᴄʀᴇᴀᴛᴇ ᴜʟᴀɴɢ ꜱᴜᴘᴀʏᴀ ʙɪꜱᴀ ᴀᴋꜱᴇꜱ.`);
  }
          
  bot.sendMessage(chatId, "⏳");
  const b = `<blockquote>`;
  const bq = `</blockquote>`;
    
  bot.sendMessage(
    chatId,
    `🔑 <b>Acccount Adp ${panelQuery}</b>
${b}➟ Domain Panel:${bq}
<code>${userPanel.domain}</code>

${b}➟ Apikey PTLA:${bq}
<code>${userPanel.tokenA}</code>

${b}➟ Apikey PTLC:${bq}
<code>${userPanel.tokenC}</code>`, { parse_mode: "HTML" });
});
    
    // unli ke whatsapp
bot.onText(/\/unliwa (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  
  if ((msg.chat.type !== "group" && msg.chat.type !== "supergroup") && msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ ᴋʜᴜꜱᴜꜱ ɢʀᴜᴘ!");
  }
    
  const text = match[1];

  const isCooldown = checkCooldown(msg);
  if (isCooldown) return bot.sendMessage(chatId, isCooldown);

  const ressUsers = JSON.parse(fs.readFileSync(RESS_FILE));
  const isReseller = ressUsers.includes(String(msg.from.id));

  if (!isReseller) {
    return bot.sendMessage(chatId, "❌ Khusus Reseller!", {
      reply_markup: {
        inline_keyboard: [[{ text: `LAPORAN", url: "https://t.me/${dev}` }]],
      },
    });
  }

  const t = text.split(",");
  if (t.length < 2) {
    return bot.sendMessage(chatId, "⚠️ Format: /unli namapanel,nomorwa");
  }

  const username = t[0].trim();
  const waNumber = t[1].replace(/[^0-9]/g, ""); // nomor WA tujuan
  const jid = waNumber + "@s.whatsapp.net"; // jid WA
  const name = username + "unli";
  const egg = settings.eggs;
  const loc = settings.loc;
  const memo = "0";
  const cpu = "0";
  const disk = "0";
  const email = `${username}@unli.nael`;
  const spc =
    'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const password = username + Math.random().toString(36).slice(2, 5);
    
  let user;
  let server;

  try {
    // CREATE USER
    const response = await fetch(`${domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: "en",
        password: password,
      }),
    });

    const data = await response.json();
    if (data.errors) {
      return bot.sendMessage(
        chatId,
        `❌ Error: ${JSON.stringify(data.errors[0], null, 2)}`
      );
    }
    user = data.attributes;

    // CREATE SERVER
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        name: name,
        description: "",
        user: user.id,
        egg: parseInt(egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_20",
        startup: spc,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start",
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu,
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1,
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: [],
        },
      }),
    });

    const data2 = await response2.json();
    if (data2.errors) {
      return bot.sendMessage(
        chatId,
        `❌ Error saat buat server: ${JSON.stringify(data2.errors[0], null, 2)}`
      );
    }
    server = data2.attributes;
  } catch (error) {
    return bot.sendMessage(chatId, `❌ Error: ${error.message}`);
  }

  if (user && server) {
    // kirim ke WA
    await sock.sendMessage(jid, {
  image: { url: panel },
  caption: `*🔐 Sukses Created Panel!*
▸ Name: ${username}
▸ Email: ${email}
▸ ID: ${user.id}

*🌐 Domain Panel*
▸ Username: ${user.username}
▸ Password: ${password}
▸ Login: ${domain}

*⚠️ Rules Panel*
▸ Sensor domain
▸ Simpan data akun
▸ Garansi 15 hari`
  });

    // notif di Telegram
    bot.sendMessage(
      chatId,
      `✅ Sukses kirim panel ke Nomer WhatsApp: ${waNumber}`
    );
  } else {
    bot.sendMessage(
      chatId,
      `❌ Akun panel tidak ada! Laporkan ke @${dev}.`
    );
  }
});
    
    // unli
bot.onText(/\/unli(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;

  if (msg.chat.type !== "group" && msg.chat.type !== "supergroup") {
  bot.sendMessage(msg.chat.id, "❌ ᴋʜᴜꜱᴜꜱ ɢʀᴜᴘ!");
  return;
  }

  const text = match[1];

  const ressUsers = JSON.parse(fs.readFileSync(RESS_FILE));
  const isReseller = ressUsers.includes(String(msg.from.id));

  if (!isReseller) {
    bot.sendMessage(chatId, "❌ ᴋʜᴜꜱᴜꜱ ʀᴇꜱᴇʟʟᴇʀ!", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ʟᴀᴘᴏʀᴀɴ", url: `https://t.me/${dev}` }],
        ],
      },
    });
    return;
  }

  await bot.sendMessage(chatId, "⏳");
    
  const t = text.split(",");
  if (t.length < 2) {
    bot.sendMessage(chatId, "⚠️ Format: /unli namapanel,idtele");
    return;
  }

  const username = t[0].trim();
  const u = parseInt(t[1].trim());
  const name = username + "unli";
  const egg = eggs;
  const loc = settings.loc;
  const memo = "0";
  const cpu = "0";
  const disk = "0";
  const email = `${username}@unli.nael`;
  const spc =
    'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const password = username + Math.random().toString(36).slice(2, 5);

  let user, server;

  try {
    // CREATE USER
    const response = await fetch(`${domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: "en",
        password: password,
      }),
    });

    const data = await response.json();
    if (data.errors) {
      if (
        data.errors[0].meta.rule === "unique" &&
        data.errors[0].meta.source_field === "email"
      ) {
        bot.sendMessage(chatId, "⚠️ Email & Username sudah ada di panel! Coba lagi.");
      } else {
        bot.sendMessage(chatId, `❌ Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;

    // CREATE SERVER
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        name: name,
        description: "",
        user: user.id,
        egg: parseInt(egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_20",
        startup: spc,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start",
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu,
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1,
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: [],
        },
      }),
    });

    const data2 = await response2.json();
    if (data2.errors) {
      bot.sendMessage(chatId, `❌ Error saat buat server: ${JSON.stringify(data2.errors[0], null, 2)}`);
      return;
    }
    server = data2.attributes;

  } catch (error) {
    bot.sendMessage(chatId, `❌ Error API: ${error.message}`);
    return;
  }

  if (user && server) {
    bot.sendMessage(
      chatId,
      `Type: Panel Unli
📡 ID: ${user.id}
👤 USERNAME: ${username}
⚙️ MEMORY: ${server.limits.memory === 0 ? "Unlimited" : server.limits.memory} MB
`
    );

    function esc(text) {
      return String(text).replace(/([_*\[\]()~`>#+\-=|{}.!])/g, '\\$1');
    }

    const safeName = esc(username);
    const safeEmail = esc(email);
    const safeId = esc(user.id);
    const safeUser = esc(user.username);
    const safePass = esc(password);
    const safeDomain = esc(domain);

    const copyUser = `\`${safeUser}\``;
    const copyPass = `\`${safePass}\``;
    const spoilerDomain = `||${safeDomain}||`;

    try {
      await bot.sendPhoto(u, panel, {
        caption: `🔐 *Sukses Created Panel\\!*
▸ Name: ${safeName}
▸ Email: ${safeEmail}
▸ ID: ${safeId}
▸ RAM: Unlimited

🌐 *Akun Panel*
▸ Username: ${copyUser}
▸ Password: ${copyPass}
▸ Login: ${spoilerDomain}

⚠️ *Rules Panel*
▸ Sensor domain
▸ Simpan data akun
▸ Garansi 15 hari`,
        parse_mode: "MarkdownV2",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🌐 Domain", url: domain },
              { text: "🔑 Salin Password", switch_inline_query_current_chat: password }
            ],
          ],
        },
      });

      bot.sendMessage(
        chatId,
        `✅ Berhasil kirim panel ke @${msg.from.username}\n(ID: ${u})`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
                               
    } catch (err) {
      bot.sendMessage(chatId, `⚠️ Gagal kirim panel ke user ID ${u}.  
Kemungkinan user belum start bot / blokir bot.\n\nDetail error: ${err.message}`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    }

  } else {
    bot.sendMessage(chatId, `❌ Akun panel tidak ada! Laporkan ke @${dev}.`);
  }
});
    
   // unli v2
bot.onText(/\/unliv2(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
    
  /*if (msg.chat.type !== "group" && msg.chat.type !== "supergroup") {
  bot.sendMessage(msg.chat.id, "❌ ᴋʜᴜꜱᴜꜱ ɢʀᴜᴘ!");
  return;
  }

  const isCooldown = checkCooldown(msg);
    if (isCooldown) return bot.sendMessage(chatId, isCooldown);*/
    
  const ressV2Users = JSON.parse(fs.readFileSync(RESSV2_FILE));
  const isResellerV2 = ressV2Users.includes(String(msg.from.id));   
      if (!isResellerV2) {
    bot.sendMessage(chatId, "❌ ᴋʜᴜꜱᴜꜱ ʀᴇꜱᴇʟʟᴇʀ ᴠ2!", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ᴊᴏɪɴ ꜱᴇʀᴠᴇʀ", url: `https://t.me/${dev}` }],
        ],
      },
    });
    return;
  }

  const t = text.split(",");
  if (t.length < 2) {
    bot.sendMessage(chatId, "⚠️ Format: /unliv2 namapanel,idtele");
    return;
  }

  const username = t[0].trim();
  const u = parseInt(t[1].trim());
  const name = username + "unli";
  const egg = eggs;
  const loc = settings.loc;
  const memo = "0";
  const cpu = "0";
  const disk = "0";
  const email = `${username}@unli.nael`;
  const spc =
    'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const password = username + Math.random().toString(36).slice(2, 5);
    
  let user;
  let server;

  try {
    // CREATE USER
    const response = await fetch(`${domainV2}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${pltaV2}`,
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: "en",
        password: password,
      }),
    });

    const data = await response.json();
    if (data.errors) {
      if (
        data.errors[0].meta.rule === "unique" &&
        data.errors[0].meta.source_field === "email"
      ) {
        bot.sendMessage(chatId, "⚠️ Email & Username sudah ada di panel! Coba lagi.");
      } else {
        bot.sendMessage(chatId, `❌ Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;

    // CREATE SERVER
    const response2 = await fetch(`${domainV2}/api/application/servers`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${pltaV2}`,
      },
      body: JSON.stringify({
        name: name,
        description: "",
        user: user.id,
        egg: parseInt(egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_20",
        startup: spc,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start",
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu,
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1,
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: [],
        },
      }),
    });

    const data2 = await response2.json();
    if (data2.errors) {
      bot.sendMessage(chatId, `❌ Error saat buat server: ${JSON.stringify(data2.errors[0], null, 2)}`);
      return;
    }
    server = data2.attributes;

  } catch (error) {
    bot.sendMessage(chatId, `❌ Error: ${error.message}`);
    return;
  }

  if (user && server) {
    bot.sendMessage(
      chatId,
      `Type: Panel Unli V2
📡 ID: ${user.id}
👤 USERNAME: ${username}
⚙️ MEMORY: ${server.limits.memory === 0 ? "Unlimited" : server.limits.memory} MB
`
    );

function esc(text) {
  return String(text).replace(/([_*\[\]()~`>#+\-=|{}.!])/g, '\\$1');
}

const safeName = esc(username);
const safeEmail = esc(email);
const safeId = esc(user.id);
const safeUser = esc(user.username);
const safePass = esc(password);
const safeDomain = esc(domainV2);

// copy
const copyUser = `\`${safeUser}\``;
const copyPass = `\`${safePass}\``;
    
// spoiler
const spoilerDomain = `||${safeDomain}||`;

bot.sendPhoto(u, panel, {
  caption: `🔐 *Sukses Created Panel V2\\!*
▸ Name: ${safeName}
▸ Email: ${safeEmail}
▸ ID: ${safeId}
▸ RAM: Unlimited

🌐 *Akun Panel V2*
▸ Username: ${copyUser}
▸ Password: ${copyPass}
▸ Login: ${spoilerDomain}

⚠️ *Rules Panel*
▸ Sensor domain
▸ Simpan data akun
▸ Garansi 15 hari`,
  parse_mode: "MarkdownV2",
  reply_markup: {
    inline_keyboard: [
      [
        { text: "🌐 Domain", url: domainV2 },
        { text: "🔑 Salin Password", switch_inline_query_current_chat: password }
      ],
    ],
  },
});

    bot.sendMessage(
      chatId,
      `✅ Berhasil kirim panel V2 ke @${msg.from.username}\n(ID: ${u})`
    );
  } else {
    bot.sendMessage(chatId, `❌ Akun panel tidak ada! Laporkan ke @${dev}.`);
  }
});
    
  // unli v3
bot.onText(/\/unliv3(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
    
  if (msg.chat.type !== "group" && msg.chat.type !== "supergroup") {
  bot.sendMessage(msg.chat.id, "❌ ᴋʜᴜꜱᴜꜱ ɢʀᴜᴘ!");
  return;
  }

  const isCooldown = checkCooldown(msg);
    if (isCooldown) return bot.sendMessage(chatId, isCooldown);
    
  const ressV3Users = JSON.parse(fs.readFileSync(RESSV3_FILE));
  const isResellerV3 = ressV3Users.includes(String(msg.from.id));   
      if (!isResellerV3) {
    bot.sendMessage(chatId, "❌ ᴋʜᴜꜱᴜꜱ ʀᴇꜱᴇʟʟᴇʀ ᴠ3!", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ᴊᴏɪɴ ꜱᴇʀᴠᴇʀ", url: `https://t.me/${dev}` }],
        ],
      },
    });
    return;
  }

  const t = text.split(",");
  if (t.length < 2) {
    bot.sendMessage(chatId, "⚠️ Format: /unliv3 namapanel,idtele");
    return;
  }

  const username = t[0].trim();
  const u = parseInt(t[1].trim());
  const name = username + "unli";
  const egg = eggs;
  const loc = settings.loc;
  const memo = "0";
  const cpu = "0";
  const disk = "0";
  const email = `${username}@unli.nael`;
  const spc =
    'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const password = username + Math.random().toString(36).slice(2, 5);
    
  let user;
  let server;

  try {
    // CREATE USER
    const response = await fetch(`${domainV3}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${pltaV3}`,
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: "en",
        password: password,
      }),
    });

    const data = await response.json();
    if (data.errors) {
      if (
        data.errors[0].meta.rule === "unique" &&
        data.errors[0].meta.source_field === "email"
      ) {
        bot.sendMessage(chatId, "⚠️ Email & Username sudah ada di panel! Coba lagi.");
      } else {
        bot.sendMessage(chatId, `❌ Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;

    // CREATE SERVER
    const response2 = await fetch(`${domainV3}/api/application/servers`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${pltaV3}`,
      },
      body: JSON.stringify({
        name: name,
        description: "",
        user: user.id,
        egg: parseInt(egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_20",
        startup: spc,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start",
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu,
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1,
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: [],
        },
      }),
    });

    const data2 = await response2.json();
    if (data2.errors) {
      bot.sendMessage(chatId, `❌ Error saat buat server: ${JSON.stringify(data2.errors[0], null, 2)}`);
      return;
    }
    server = data2.attributes;

  } catch (error) {
    bot.sendMessage(chatId, `❌ Error: ${error.message}`);
    return;
  }

  if (user && server) {
    bot.sendMessage(
      chatId,
      `Type: Panel Unli V3
📡 ID: ${user.id}
👤 USERNAME: ${username}
⚙️ MEMORY: ${server.limits.memory === 0 ? "Unlimited" : server.limits.memory} MB
`
    );

function esc(text) {
  return String(text).replace(/([_*\[\]()~`>#+\-=|{}.!])/g, '\\$1');
}

const safeName = esc(username);
const safeEmail = esc(email);
const safeId = esc(user.id);
const safeUser = esc(user.username);
const safePass = esc(password);
const safeDomain = esc(domainV3);

// copy
const copyUser = `\`${safeUser}\``;
const copyPass = `\`${safePass}\``;
    
// spoiler
const spoilerDomain = `||${safeDomain}||`;

bot.sendPhoto(u, panel, {
  caption: `🔐 *Sukses Created Panel V3\\!*
▸ Name: ${safeName}
▸ Email: ${safeEmail}
▸ ID: ${safeId}
▸ RAM: Unlimited

🌐 *Akun Panel V3*
▸ Username: ${copyUser}
▸ Password: ${copyPass}
▸ Login: ${spoilerDomain}

⚠️ *Rules Panel*
▸ Sensor domain
▸ Simpan data akun
▸ Garansi 15 hari`,
  parse_mode: "MarkdownV2",
  reply_markup: {
    inline_keyboard: [
      [
        { text: "🌐 Domain", url: domainV3 },
        { text: "🔑 Salin Password", switch_inline_query_current_chat: password }
      ],
    ],
  },
});

    bot.sendMessage(
      chatId,
      `✅ Berhasil kirim panel V3 ke @${msg.from.username}\n(ID: ${u})`
    );
  } else {
    bot.sendMessage(chatId, `❌ Akun panel tidak ada! Laporkan ke @${dev}.`);
  }
});
   
  // unli v4
bot.onText(/\/unliv4(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
    
  if (msg.chat.type !== "group" && msg.chat.type !== "supergroup") {
  bot.sendMessage(msg.chat.id, "❌ ᴋʜᴜꜱᴜꜱ ɢʀᴜᴘ!");
  return;
  }

  const isCooldown = checkCooldown(msg);
    if (isCooldown) return bot.sendMessage(chatId, isCooldown);
    
  const ressV4Users = JSON.parse(fs.readFileSync(RESSV4_FILE));
  const isResellerV4 = ressV4Users.includes(String(msg.from.id));   
      if (!isResellerV4) {
    bot.sendMessage(chatId, "❌ ᴋʜᴜꜱᴜꜱ ʀᴇꜱᴇʟʟᴇʀ ᴠ4!", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ᴊᴏɪɴ ꜱᴇʀᴠᴇʀ", url: `https://t.me/${dev}` }],
        ],
      },
    });
    return;
  }

  const t = text.split(",");
  if (t.length < 2) {
    bot.sendMessage(chatId, "⚠️ Format: /unliv4 namapanel,idtele");
    return;
  }

  const username = t[0].trim();
  const u = parseInt(t[1].trim());
  const name = username + "unli";
  const egg = eggs;
  const loc = settings.loc;
  const memo = "0";
  const cpu = "0";
  const disk = "0";
  const email = `${username}@unli.nael`;
  const spc =
    'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const password = username + Math.random().toString(36).slice(2, 5);
    
  let user;
  let server;

  try {
    // CREATE USER
    const response = await fetch(`${domainV4}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${pltaV4}`,
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: "en",
        password: password,
      }),
    });

    const data = await response.json();
    if (data.errors) {
      if (
        data.errors[0].meta.rule === "unique" &&
        data.errors[0].meta.source_field === "email"
      ) {
        bot.sendMessage(chatId, "⚠️ Email & Username sudah ada di panel! Coba lagi.");
      } else {
        bot.sendMessage(chatId, `❌ Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;

    // CREATE SERVER
    const response2 = await fetch(`${domainV4}/api/application/servers`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${pltaV4}`,
      },
      body: JSON.stringify({
        name: name,
        description: "",
        user: user.id,
        egg: parseInt(egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_20",
        startup: spc,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start",
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu,
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1,
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: [],
        },
      }),
    });

    const data2 = await response2.json();
    if (data2.errors) {
      bot.sendMessage(chatId, `❌ Error saat buat server: ${JSON.stringify(data2.errors[0], null, 2)}`);
      return;
    }
    server = data2.attributes;

  } catch (error) {
    bot.sendMessage(chatId, `❌ Error: ${error.message}`);
    return;
  }

  if (user && server) {
    bot.sendMessage(
      chatId,
      `Type: Panel Unli V4
📡 ID: ${user.id}
👤 USERNAME: ${username}
⚙️ MEMORY: ${server.limits.memory === 0 ? "Unlimited" : server.limits.memory} MB
`
    );

function esc(text) {
  return String(text).replace(/([_*\[\]()~`>#+\-=|{}.!])/g, '\\$1');
}

const safeName = esc(username);
const safeEmail = esc(email);
const safeId = esc(user.id);
const safeUser = esc(user.username);
const safePass = esc(password);
const safeDomain = esc(domainV4);

// copy
const copyUser = `\`${safeUser}\``;
const copyPass = `\`${safePass}\``;
    
// spoiler
const spoilerDomain = `||${safeDomain}||`;

bot.sendPhoto(u, panel, {
  caption: `🔐 *Sukses Created Panel V4\\!*
▸ Name: ${safeName}
▸ Email: ${safeEmail}
▸ ID: ${safeId}
▸ RAM: Unlimited

🌐 *Akun Panel V4*
▸ Username: ${copyUser}
▸ Password: ${copyPass}
▸ Login: ${spoilerDomain}

⚠️ *Rules Panel*
▸ Sensor domain
▸ Simpan data akun
▸ Garansi 15 hari`,
  parse_mode: "MarkdownV2",
  reply_markup: {
    inline_keyboard: [
      [
        { text: "🌐 Domain", url: domainV4 },
        { text: "🔑 Salin Password", switch_inline_query_current_chat: password }
      ],
    ],
  },
});

    bot.sendMessage(
      chatId,
      `✅ Berhasil kirim panel V4 ke @${msg.from.username}\n(ID: ${u})`
    );
  } else {
    bot.sendMessage(chatId, `❌ Akun panel tidak ada! Laporkan ke @${dev}.`);
  }
});
    
  // unli v5
bot.onText(/\/unliv5(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
    
  if (msg.chat.type !== "group" && msg.chat.type !== "supergroup") {
  bot.sendMessage(msg.chat.id, "❌ ᴋʜᴜꜱᴜꜱ ɢʀᴜᴘ!");
  return;
  }

  const isCooldown = checkCooldown(msg);
    if (isCooldown) return bot.sendMessage(chatId, isCooldown);
    
  const ressV5Users = JSON.parse(fs.readFileSync(RESSV5_FILE));
  const isResellerV5 = ressV5Users.includes(String(msg.from.id));   
      if (!isResellerV5) {
    bot.sendMessage(chatId, "❌ ᴋʜᴜꜱᴜꜱ ʀᴇꜱᴇʟʟᴇʀ ᴠ5!", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ᴊᴏɪɴ ꜱᴇʀᴠᴇʀ", url: `https://t.me/${dev}` }],
        ],
      },
    });
    return;
  }

  const t = text.split(",");
  if (t.length < 2) {
    bot.sendMessage(chatId, "⚠️ Format: /unliv5 namapanel,idtele");
    return;
  }

  const username = t[0].trim();
  const u = parseInt(t[1].trim());
  const name = username + "unli";
  const egg = eggs;
  const loc = settings.loc;
  const memo = "0";
  const cpu = "0";
  const disk = "0";
  const email = `${username}@unli.nael`;
  const spc =
    'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
  const password = username + Math.random().toString(36).slice(2, 5);
    
  let user;
  let server;

  try {
    // CREATE USER
    const response = await fetch(`${domainV5}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${pltaV5}`,
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: "en",
        password: password,
      }),
    });

    const data = await response.json();
    if (data.errors) {
      if (
        data.errors[0].meta.rule === "unique" &&
        data.errors[0].meta.source_field === "email"
      ) {
        bot.sendMessage(chatId, "⚠️ Email & Username sudah ada di panel! Coba lagi.");
      } else {
        bot.sendMessage(chatId, `❌ Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;

    // CREATE SERVER
    const response2 = await fetch(`${domainV5}/api/application/servers`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${pltaV5}`,
      },
      body: JSON.stringify({
        name: name,
        description: "",
        user: user.id,
        egg: parseInt(egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_20",
        startup: spc,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start",
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu,
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1,
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: [],
        },
      }),
    });

    const data2 = await response2.json();
    if (data2.errors) {
      bot.sendMessage(chatId, `❌ Error saat buat server: ${JSON.stringify(data2.errors[0], null, 2)}`);
      return;
    }
    server = data2.attributes;

  } catch (error) {
    bot.sendMessage(chatId, `❌ Error: ${error.message}`);
    return;
  }

  if (user && server) {
    bot.sendMessage(
      chatId,
      `Type: Panel Unli V5
📡 ID: ${user.id}
👤 USERNAME: ${username}
⚙️ MEMORY: ${server.limits.memory === 0 ? "Unlimited" : server.limits.memory} MB
`
    );

function esc(text) {
  return String(text).replace(/([_*\[\]()~`>#+\-=|{}.!])/g, '\\$1');
}

const safeName = esc(username);
const safeEmail = esc(email);
const safeId = esc(user.id);
const safeUser = esc(user.username);
const safePass = esc(password);
const safeDomain = esc(domainV5);

// copy
const copyUser = `\`${safeUser}\``;
const copyPass = `\`${safePass}\``;
    
// spoiler
const spoilerDomain = `||${safeDomain}||`;

bot.sendPhoto(u, panel, {
  caption: `🔐 *Sukses Created Panel V5\\!*
▸ Name: ${safeName}
▸ Email: ${safeEmail}
▸ ID: ${safeId}
▸ RAM: Unlimited

🌐 *Akun Panel V5*
▸ Username: ${copyUser}
▸ Password: ${copyPass}
▸ Login: ${spoilerDomain}

⚠️ *Rules Panel*
▸ Sensor domain
▸ Simpan data akun
▸ Garansi 15 hari`,
  parse_mode: "MarkdownV2",
  reply_markup: {
    inline_keyboard: [
      [
        { text: "🌐 Domain", url: domainV5 },
        { text: "🔑 Salin Password", switch_inline_query_current_chat: password }
      ],
    ],
  },
});

    bot.sendMessage(
      chatId,
      `✅ Berhasil kirim panel V5 ke @${msg.from.username}\n(ID: ${u})`
    );
  } else {
    bot.sendMessage(chatId, `❌ Akun panel tidak ada! Laporkan ke @${dev}.`);
  }
});
    
    // specs ram
const specs = {
  "1gbv2": { memo: 1024,  cpu: 30,  disk: 1024 },
  "2gbv2": { memo: 2048,  cpu: 60,  disk: 2048 },
  "3gbv2": { memo: 3072,  cpu: 90,  disk: 3072 },
  "4gbv2": { memo: 4096,  cpu: 120, disk: 4096 },
  "5gbv2": { memo: 5120,  cpu: 150, disk: 5120 },
  "6gbv2": { memo: 6144,  cpu: 180, disk: 6144 },
  "7gbv2": { memo: 7168,  cpu: 210, disk: 7168 },
  "8gbv2": { memo: 8192,  cpu: 240, disk: 8192 },
  "9gbv2": { memo: 9216,  cpu: 270, disk: 9216 },
  "10gbv2":{ memo: 10240, cpu: 300, disk: 10240 },

  "1gbv3": { memo: 1024,  cpu: 30,  disk: 1024 },
  "2gbv3": { memo: 2048,  cpu: 60,  disk: 2048 },
  "3gbv3": { memo: 3072,  cpu: 90,  disk: 3072 },
  "4gbv3": { memo: 4096,  cpu: 120, disk: 4096 },
  "5gbv3": { memo: 5120,  cpu: 150, disk: 5120 },
  "6gbv3": { memo: 6144,  cpu: 180, disk: 6144 },
  "7gbv3": { memo: 7168,  cpu: 210, disk: 7168 },
  "8gbv3": { memo: 8192,  cpu: 240, disk: 8192 },
  "9gbv3": { memo: 9216,  cpu: 270, disk: 9216 },
  "10gbv3":{ memo: 10240, cpu: 300, disk: 10240 },

  "1gbv4": { memo: 1024,  cpu: 30,  disk: 1024 },
  "2gbv4": { memo: 2048,  cpu: 60,  disk: 2048 },
  "3gbv4": { memo: 3072,  cpu: 90,  disk: 3072 },
  "4gbv4": { memo: 4096,  cpu: 120, disk: 4096 },
  "5gbv4": { memo: 5120,  cpu: 150, disk: 5120 },
  "6gbv4": { memo: 6144,  cpu: 180, disk: 6144 },
  "7gbv4": { memo: 7168,  cpu: 210, disk: 7168 },
  "8gbv4": { memo: 8192,  cpu: 240, disk: 8192 },
  "9gbv4": { memo: 9216,  cpu: 270, disk: 9216 },
  "10gbv4":{ memo: 10240, cpu: 300, disk: 10240 },

  "1gbv5": { memo: 1024,  cpu: 30,  disk: 1024 },
  "2gbv5": { memo: 2048,  cpu: 60,  disk: 2048 },
  "3gbv5": { memo: 3072,  cpu: 90,  disk: 3072 },
  "4gbv5": { memo: 4096,  cpu: 120, disk: 4096 },
  "5gbv5": { memo: 5120,  cpu: 150, disk: 5120 },
  "6gbv5": { memo: 6144,  cpu: 180, disk: 6144 },
  "7gbv5": { memo: 7168,  cpu: 210, disk: 7168 },
  "8gbv5": { memo: 8192,  cpu: 240, disk: 8192 },
  "9gbv5": { memo: 9216,  cpu: 270, disk: 9216 },
  "10gbv5":{ memo: 10240, cpu: 300, disk: 10240 }
};

    // 1gb-10gb
bot.onText(/\/(1gb|2gb|3gb|4gb|5gb|6gb|7gb|8gb|9gb|10gb)(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const plan = match[1];
  const text = match[2];
    
  if (msg.chat.type !== "group" && msg.chat.type !== "supergroup") {
  bot.sendMessage(msg.chat.id, "❌ ᴋʜᴜꜱᴜꜱ ɢʀᴜᴘ!");
  return;
  }
    
  const ressUsers = JSON.parse(fs.readFileSync(RESS_FILE));
  const isReseller = ressUsers.includes(String(msg.from.id));
    
  if (!isReseller) {
    bot.sendMessage(chatId, "❌ ᴋʜᴜꜱᴜꜱ ʀᴇꜱᴇʟʟᴇʀ!", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ʟᴀᴘᴏʀᴀɴ", url: `https://t.me/${dev}` }],
        ],
      },
    });
    return;
  }

  const [username,u] = text.split(",");
  if (!username || !u) return bot.sendMessage(chatId, `Usage: /${plan} namapanel,idtele`);

  const { memo, cpu, disk } = specs;
  const name = username+plan;
  const email = `${username}@buyer.nael`;
  const password = username+Math.random().toString(36).slice(2,5);
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';

  let user,server;
  try {
    const res1 = await fetch(`${domain}/api/application/users`, {
      method:"POST",
      headers:{ "Content-Type":"application/json", Authorization:`Bearer ${plta}` },
      body:JSON.stringify({ email, username, first_name:username, last_name:username, language:"en", password })
    });
    const data1 = await res1.json();
    if (data1.errors) return bot.sendMessage(chatId, `Error user: ${JSON.stringify(data1.errors[0])}`);
    user = data1.attributes;

    const res2 = await fetch(`${domain}/api/application/servers`, {
      method:"POST",
      headers:{ "Content-Type":"application/json", Authorization:`Bearer ${plta}` },
      body:JSON.stringify({
        name, user:user.id, egg:parseInt(eggs),
        docker_image:"ghcr.io/parkervcp/yolks:nodejs_24", startup:spc,
        environment:{ INST:"npm",USER_UPLOAD:"0",AUTO_UPDATE:"0",CMD_RUN:"npm start" },
        limits:{ memory:memo,swap:0,disk,io:500,cpu },
        feature_limits:{ databases:5,backups:5,allocations:1 },
        deploy:{ locations:[parseInt(settings.loc)],dedicated_ip:false,port_range:[] }
      })
    });
    const data2 = await res2.json();
    server = data2.attributes;
  } catch(e) {
    return bot.sendMessage(chatId, `Error: ${e.message}`);
  }

  if (!user || !server) return bot.sendMessage(chatId,"Gagal membuat data panel.");

  bot.sendMessage(chatId, `*- BERIKUT DATA PANEL ${plan} -*
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory} MB
DISK: ${server.limits.disk} MB
CPU: ${server.limits.cpu}%`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });

  bot.sendPhoto(u, panel, {
      caption: `*🔐 Sukses Created Panel ${plan}!*
▸ Name: ${username}
▸ Email: ${email}
▸ ID: ${user.id}
▸ RAM: ${plan}

*🌐 Akun Panel*
▸ Username: \`${user.username}\`
▸ Password: \`${password}\`

*⚠️ Rules Panel*
▸ Sensor domain
▸ Simpan data akun
▸ Garansi 15 hari
`,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [
          { text: "🌐 Domain", url: domain },
          { text: "🔑 Salin Password", switch_inline_query_current_chat: password }
          ],
        ],
      },
    });
});
    
    // 1gb-10gb v2-v5
bot.onText(/\/(\d+gbv[2-5])(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const plan = match[1];
  const text = match[2];

  if (msg.chat.type !== "group" && msg.chat.type !== "supergroup") {
    bot.sendMessage(msg.chat.id, "❌ ᴋʜᴜꜱᴜꜱ ɢʀᴜᴘ!");
    return;
  }

  const verMatch = plan.match(/v([2-5])$/i);
  const version = verMatch ? verMatch[1] : "2";

  const domainMap = {
    "2": domainV2,
    "3": domainV3,
    "4": domainV4,
    "5": domainV5
  };
  const pltaMap = {
    "2": pltaV2,
    "3": pltaV3,
    "4": pltaV4,
    "5": pltaV5
  };
  const specsMap = {
    "2": specs,
    "3": specs,
    "4": specs,
    "5": specs
  };
  const ressFileMap = {
    "2": RESSV2_FILE,
    "3": RESSV3_FILE,
    "4": RESSV4_FILE,
    "5": RESSV5_FILE
  };

  const domain = domainMap[version];
  const plta = pltaMap[version];
  const specsUsed = specsMap[version];
  const RESS_FILE = ressFileMap[version];

  if (!domain || !plta || !specsUsed || !RESS_FILE) {
    return bot.sendMessage(chatId, `❌ ᴀᴋᴜɴ ᴀᴅᴘ V${version} ᴍᴀꜱɪʜ ᴋᴏꜱᴏɴɢ!`);
  }

  const ressUsers = JSON.parse(fs.readFileSync(RESS_FILE));
  const isReseller = ressUsers.includes(String(msg.from.id));

  if (!isReseller) {
    bot.sendMessage(chatId, `❌ ᴋʜᴜꜱᴜꜱ ʀᴇꜱᴇʟʟᴇʀ ᴠ${version}!`, {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ᴊᴏɪɴ ꜱᴇʀᴠᴇʀ", url: `https://t.me/${dev}` }],
        ],
      },
    });
    return;
  }

  const [username,u] = (text||"").split(",");
  if (!username || !u) return bot.sendMessage(chatId, `⚠️ Usage: /${plan} namapanel,idtele`);

  const { memo,cpu,disk } = specsUsed[plan] || {};
  if (typeof memo === "undefined") return bot.sendMessage(chatId, `⚠️ Spesifikasi untuk ${plan} V${version} tidak ditemukan di specs.`);

  const name = username+plan;
  const email = `${username}@buyer.nael`;
  const password = username+Math.random().toString(36).slice(2,5);
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';

  let user,server;
  try {
    const res1 = await fetch(`${domain}/api/application/users`, {
      method:"POST",
      headers:{ "Content-Type":"application/json", Authorization:`Bearer ${plta}` },
      body:JSON.stringify({ email, username, first_name:username, last_name:username, language:"en", password })
    });
    const data1 = await res1.json();
    if (data1.errors) return bot.sendMessage(chatId, `Error user: ${JSON.stringify(data1.errors[0])}`);
    user = data1.attributes;

    const res2 = await fetch(`${domain}/api/application/servers`, {
      method:"POST",
      headers:{ "Content-Type":"application/json", Authorization:`Bearer ${plta}` },
      body:JSON.stringify({
        name, user:user.id, egg:parseInt(eggs),
        docker_image:"ghcr.io/parkervcp/yolks:nodejs_24", startup:spc,
        environment:{ INST:"npm",USER_UPLOAD:"0",AUTO_UPDATE:"0",CMD_RUN:"npm start" },
        limits:{ memory:memo,swap:0,disk,io:500,cpu },
        feature_limits:{ databases:5,backups:5,allocations:1 },
        deploy:{ locations:[parseInt(settings.loc)],dedicated_ip:false,port_range:[] }
      })
    });
    const data2 = await res2.json();
    server = data2.attributes;
  } catch(e) {
    return bot.sendMessage(chatId, `Error: ${e.message}`);
  }

  if (!user || !server) return bot.sendMessage(chatId,"Gagal membuat data panel.");

  bot.sendMessage(chatId, `*- BERIKUT DATA PANEL ${plan} -*
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory} MB
DISK: ${server.limits.disk} MB
CPU: ${server.limits.cpu}%`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });

  bot.sendPhoto(u, panel, {
    caption: `*🔐 Sukses Created Panel ${plan} V${version}!*
▸ Name: ${username}
▸ Email: ${email}
▸ ID: ${user.id}
▸ RAM: ${plan}

*🌐 Akun Panel V${version}*
▸ Username: \`${user.username}\`
▸ Password: \`${password}\`

*⚠️ Rules Panel*
▸ Sensor domain
▸ Simpan data akun
▸ Garansi 15 hari
`,
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "🌐 Domain", url: domain },
          { text: "🔑 Salin Password", switch_inline_query_current_chat: password }
        ],
      ],
    },
  });
});
    
// delsrv
bot.onText(/\/delsrv (.+)/, async (msg, match) => {
  notifyOwner('delsrv', msg);
  const chatId = msg.chat.id;
    
  if ((msg.chat.type !== "group" && msg.chat.type !== "supergroup") && msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ ᴋʜᴜꜱᴜꜱ ɢʀᴜᴘ!");
  }
    
  const srv = match[1].trim();

  const isCooldown = checkCooldown(msg);
    if (isCooldown) return bot.sendMessage(chatId, isCooldown);
    
  const ownerUsers = JSON.parse(fs.readFileSync(OWNER_FILE));
  const isOwner = ownerUsers.includes(String(msg.from.id));
  if (!isOwner) {
    bot.sendMessage(chatId, "❌ ᴋʜᴜsᴜs ᴏᴡɴᴇʀ", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ʟᴀᴘᴏʀᴀɴ", url: `https://t.me/${dev}`}],
        ],
      },
    });
    return;
  }

  if (!srv) {
    bot.sendMessage(
      chatId,
      "Mohon masukkan ID server yang ingin dihapus, contoh: /delsrv 1234"
    );
    return;
  }

  try {
    let f = await fetch(domain + "/api/application/servers/" + srv, {
      method: "DELETE",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
    });

    let res = f.ok ? { errors: null } : await f.json();

    if (res.errors) {
      bot.sendMessage(chatId, "❌ sᴇʀᴠᴇʀ ᴛɪᴅᴀᴋ ᴀᴅᴀ");
    } else {
      bot.sendMessage(chatId, `✅ ꜱᴜᴋꜱᴇꜱ ᴅᴇʟᴇᴛᴇ ꜱᴇʀᴠᴇʀ ${srv}`, { parse_mode: "MarkDown",
    reply_to_message_id: msg.message_id });
    }
  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, "Terjadi kesalahan saat menghapus server.");
  }
});

// listsrvoff
bot.onText(/\/listsrvoff/, async (msg) => {
  const chatId = msg.chat.id;
    
  if ((msg.chat.type !== "group" && msg.chat.type !== "supergroup") && msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ ᴋʜᴜꜱᴜꜱ ɢʀᴜᴘ!");
  }

  const isCooldown = checkCooldown(msg);
  if (isCooldown) return bot.sendMessage(chatId, isCooldown);

  try {
    const ownerUsers = JSON.parse(fs.readFileSync(OWNER_FILE));
    const isOwner = ownerUsers.includes(String(msg.from.id));
    if (!isOwner) {
      return bot.sendMessage(chatId, "❌ ᴋʜᴜsᴜs ᴏᴡɴᴇʀ", {
        reply_markup: {
          inline_keyboard: [[{ text: "ʟᴀᴘᴏʀᴀɴ", url: `https://t.me/${dev}`}]],
        },
      });
    }

    let offlineServers = [];
    let page = 1;
    let totalPages = 1;

    // Ambil semua halaman server
    do {
      let f = await fetch(`${domain}/api/application/servers?page=${page}`, {
        method: "GET",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${plta}`,
        },
      });

      let res = await f.json();
      let servers = res.data;
      totalPages = res.meta.pagination.total_pages;

      for (let server of servers) {
        let s = server.attributes;
        try {
          let f3 = await fetch(
            `${domain}/api/client/servers/${s.uuid.split("-")[0]}/resources`,
            {
              method: "GET",
              headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${pltc}`,
              },
            }
          );

          let data = await f3.json();
          let status = data.attributes ? data.attributes.current_state : s.status;

          if (status === "offline") {
            offlineServers.push(
              `ID Server: ${s.id}\nNama: ${s.name}\nStatus: ${status}\n`
            );
          }
        } catch (err) {
          console.error(`Gagal ambil data server ${s.id}`, err);
        }
      }

      page++;
    } while (page <= totalPages);

    if (offlineServers.length === 0) {
      return bot.sendMessage(chatId, "✅ Semua server dalam keadaan online.");
    }

    // Gabung semua offline server ke string
    let messageText = `📋 ᴅᴀғᴛᴀʀ sᴇʀᴠᴇʀ ᴏғғʟɪɴᴇ (${offlineServers.length}):\n\n${offlineServers.join("\n")}`;

    // Handle limit karakter Telegram (4096)
    while (messageText.length > 0) {
      let chunk = messageText.slice(0, 4000); 
      messageText = messageText.slice(4000);
      await bot.sendMessage(chatId, chunk);
    }

  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, "⚠️ Terjadi kesalahan saat memproses /listsrvoff.");
  }
});

// delallsrv offline
bot.onText(/\/delsrvoff/, async (msg) => {
  notifyOwner('delsrvoff', msg);
  const chatId = msg.chat.id;

  if ((msg.chat.type !== "group" && msg.chat.type !== "supergroup") && msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ ᴋʜᴜꜱᴜꜱ ɢʀᴜᴘ!");
  }

  const isCooldown = checkCooldown(msg);
  if (isCooldown) return bot.sendMessage(chatId, isCooldown);
    
  bot.sendMessage(chatId, "⏳");

  try {
    const ownerUsers = JSON.parse(fs.readFileSync(OWNER_FILE));
    const isOwner = ownerUsers.includes(String(msg.from.id));
    if (!isOwner) {
      return bot.sendMessage(chatId, "❌ ᴋʜᴜsᴜs ᴏᴡɴᴇʀ", {
        reply_markup: {
          inline_keyboard: [[{ text: "ʟᴀᴘᴏʀᴀɴ", url: `https://t.me/${dev}` }]],
        },
      });
    }

    let page = 1;
    let totalPages = 1;
    let offlineServers = [];

    // Ambil semua server dari semua page
    do {
      let f = await fetch(`${domain}/api/application/servers?page=${page}`, {
        method: "GET",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${plta}`,
        },
      });

      let res = await f.json();
      let servers = res.data;
      totalPages = res.meta.pagination.total_pages;

      for (let server of servers) {
        let s = server.attributes;
        try {
          let f3 = await fetch(
            `${domain}/api/client/servers/${s.uuid.split("-")[0]}/resources`,
            {
              method: "GET",
              headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${pltc}`,
              },
            }
          );

          let data = await f3.json();
          let status = data.attributes ? data.attributes.current_state : s.status;

          if (status === "offline") {
            offlineServers.push({ id: s.id, name: s.name });
          }
        } catch (err) {
          console.error(`Gagal ambil data server ${s.id}`, err);
        }
      }

      page++;
    } while (page <= totalPages);

    if (offlineServers.length === 0) {
      return bot.sendMessage(chatId, "✅ Tidak ada server offline untuk dihapus.");
    }

    let success = [];
    let failed = [];

    for (let srv of offlineServers) {
      try {
        let del = await fetch(`${domain}/api/application/servers/${srv.id}`, {
          method: "DELETE",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${plta}`,
          },
        });

        if (del.status === 204) {
          success.push(`✅ ${srv.name} (ID: ${srv.id})`);
        } else {
          failed.push(`❌ ${srv.name} (ID: ${srv.id})`);
        }
      } catch (err) {
        console.error(`Gagal hapus server ${srv.id}`, err);
        failed.push(`❌ ${srv.name} (ID: ${srv.id})`);
      }
    }

    let report = `🗑️ ʜᴀsɪʟ ᴘᴇɴɢʜᴀᴘᴜsᴀɴ sᴇʀᴠᴇʀ ᴏғғʟɪɴᴇ:\n\n` +
      `ʙᴇʀʜᴀsɪʟ ᴅɪʜᴀᴘᴜs: ${success.length}\n` +
      `ɢᴀɢᴀʟ ᴅɪʜᴀᴘᴜs: ${failed.length}\n\n`;

    if (success.length) {
      report += `✅ ʙᴇʀʜᴀsɪʟ:\n${success.join("\n")}\n\n`;
    }
    if (failed.length) {
      report += `❌ ɢᴀɢᴀʟ:\n${failed.join("\n")}`;
    }

    // Handle limit karakter telegram
    while (report.length > 0) {
      let chunk = report.slice(0, 4000);
      report = report.slice(4000);
      await bot.sendMessage(chatId, chunk);
    }

  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, "⚠️ Terjadi kesalahan saat memproses /delsrvoff.");
  }
});
   
// clearoff - hapus server offline, tunggu 5 menit, lalu hapus user offline
bot.onText(/\/clearoff/, async (msg) => {
  notifyOwner('clearoff', msg);
  const chatId = msg.chat.id;

  if ((msg.chat.type !== "group" && msg.chat.type !== "supergroup") && msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ ᴋʜᴜꜱᴜꜱ ɢʀᴜᴘ!");
  }

  const isCooldown = checkCooldown(msg);
  if (isCooldown) return bot.sendMessage(chatId, isCooldown);

  const ownerUsers = JSON.parse(fs.readFileSync(OWNER_FILE));
  const isOwner = ownerUsers.includes(String(msg.from.id));
  if (!isOwner) {
    return bot.sendMessage(chatId, "❌ ᴋʜᴜsᴜs ᴏᴡɴᴇʀ", {
      reply_markup: {
        inline_keyboard: [[{ text: "ʟᴀᴘᴏʀᴀɴ", url: `https://t.me/${dev}` }]],
      },
    });
  }

  try {
    // Step 1: Hapus server offline
    bot.sendMessage(chatId, "🗑️ Memulai proses penghapusan server offline...");

    let offlineServers = [];
    let page = 1;
    let totalPages = 1;

    // Ambil semua server offline
    do {
      let f = await fetch(`${domain}/api/application/servers?page=${page}`, {
        method: "GET",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${plta}`,
        },
      });

      let res = await f.json();
      let servers = res.data;
      totalPages = res.meta.pagination.total_pages;

      for (let server of servers) {
        let s = server.attributes;
        try {
          let f3 = await fetch(
            `${domain}/api/client/servers/${s.uuid.split("-")[0]}/resources`,
            {
              method: "GET",
              headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${pltc}`,
              },
            }
          );

          let data = await f3.json();
          let status = data.attributes ? data.attributes.current_state : s.status;

          if (status === "offline") {
            offlineServers.push({ id: s.id, name: s.name });
          }
        } catch (err) {
          console.error(`Gagal ambil data server ${s.id}`, err);
        }
      }

      page++;
    } while (page <= totalPages);

    let serverSuccess = [];
    let serverFailed = [];

    // Hapus server offline
    for (let srv of offlineServers) {
      try {
        let del = await fetch(`${domain}/api/application/servers/${srv.id}`, {
          method: "DELETE",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${plta}`,
          },
        });

        if (del.status === 204) {
          serverSuccess.push(`✅ ${srv.name} (ID: ${srv.id})`);
        } else {
          serverFailed.push(`❌ ${srv.name} (ID: ${srv.id})`);
        }
      } catch (err) {
        console.error(`Gagal hapus server ${srv.id}`, err);
        serverFailed.push(`❌ ${srv.name} (ID: ${srv.id})`);
      }
    }

    // Laporkan hasil penghapusan server
    let serverReport = `🗑️ ʜᴀsɪʟ ᴘᴇɴɢʜᴀᴘᴜsᴀɴ sᴇʀᴠᴇʀ ᴏғғʟɪɴᴇ:\n\n` +
      `ʙᴇʀʜᴀsɪʟ ᴅɪʜᴀᴘᴜs: ${serverSuccess.length}\n` +
      `ɢᴀɢᴀʟ ᴅɪʜᴀᴘᴜs: ${serverFailed.length}\n\n`;

    if (serverSuccess.length) {
      serverReport += `✅ ʙᴇʀʜᴀsɪʟ:\n${serverSuccess.slice(0, 10).join("\n")}`;
      if (serverSuccess.length > 10) serverReport += `\n...dan ${serverSuccess.length - 10} lainnya`;
      serverReport += `\n\n`;
    }
    if (serverFailed.length) {
      serverReport += `❌ ɢᴀɢᴀʟ:\n${serverFailed.slice(0, 5).join("\n")}`;
      if (serverFailed.length > 5) serverReport += `\n...dan ${serverFailed.length - 5} lainnya`;
    }

    await bot.sendMessage(chatId, serverReport);

    // Step 2: Tunggu 5 menit
    bot.sendMessage(chatId, "⏳ Menunggu 5 menit sebelum menghapus user offline...");
    
    await new Promise(resolve => setTimeout(resolve, 5 * 60 * 1000)); // 5 menit

    // Step 3: Hapus user offline (kecuali admin panel)
    bot.sendMessage(chatId, "🗑️ Memulai penghapusan user offline...");

    let offlineUsers = [];
    page = 1;
    totalPages = 1;

    // Ambil semua user
    do {
      let f = await fetch(`${domain}/api/application/users?page=${page}`, {
        method: "GET",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${plta}`,
        },
      });

      let res = await f.json();
      let users = res.data;
      totalPages = res.meta.pagination.total_pages;

      for (let user of users) {
        let u = user.attributes;
        
        // Skip admin panel (root_admin)
        if (u.root_admin) continue;

        // Cek apakah user memiliki server
        let hasServer = false;
        try {
          let serverCheck = await fetch(`${domain}/api/application/servers?filter[user_id]=${u.id}`, {
            method: "GET",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: `Bearer ${plta}`,
            },
          });

          let serverData = await serverCheck.json();
          if (serverData.data && serverData.data.length > 0) {
            hasServer = true;
          }
        } catch (err) {
          console.error(`Gagal cek server user ${u.id}`, err);
        }

        // Jika user tidak memiliki server, tambahkan ke list offline
        if (!hasServer) {
          offlineUsers.push({ id: u.id, username: u.username, email: u.email });
        }
      }

      page++;
    } while (page <= totalPages);

    let userSuccess = [];
    let userFailed = [];

    // Hapus user offline
    for (let user of offlineUsers) {
      try {
        let del = await fetch(`${domain}/api/application/users/${user.id}`, {
          method: "DELETE",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${plta}`,
          },
        });

        if (del.status === 204) {
          userSuccess.push(`✅ ${user.username} (${user.email})`);
        } else {
          userFailed.push(`❌ ${user.username} (${user.email})`);
        }
      } catch (err) {
        console.error(`Gagal hapus user ${user.id}`, err);
        userFailed.push(`❌ ${user.username} (${user.email})`);
      }
    }

    // Laporkan hasil penghapusan user
    let userReport = `👥 ʜᴀsɪʟ ᴘᴇɴɢʜᴀᴘᴜsᴀɴ ᴜsᴇʀ ᴏғғʟɪɴᴇ:\n\n` +
      `ʙᴇʀʜᴀsɪʟ ᴅɪʜᴀᴘᴜs: ${userSuccess.length}\n` +
      `ɢᴀɢᴀʟ ᴅɪʜᴀᴘᴜs: ${userFailed.length}\n\n`;

    if (userSuccess.length) {
      userReport += `✅ ʙᴇʀʜᴀsɪʟ:\n${userSuccess.slice(0, 10).join("\n")}`;
      if (userSuccess.length > 10) userReport += `\n...dan ${userSuccess.length - 10} lainnya`;
      userReport += `\n\n`;
    }
    if (userFailed.length) {
      userReport += `❌ ɢᴀɢᴀʟ:\n${userFailed.slice(0, 5).join("\n")}`;
      if (userFailed.length > 5) userReport += `\n...dan ${userFailed.length - 5} lainnya`;
    }

    // Laporkan hasil akhir
    let finalReport = `🎯 **PROSES CLEAROFF SELESAI**\n\n` +
      `📊 **STATISTIK PENGHAPUSAN:**\n` +
      `• Server offline dihapus: ${serverSuccess.length} berhasil, ${serverFailed.length} gagal\n` +
      `• User offline dihapus: ${userSuccess.length} berhasil, ${userFailed.length} gagal\n\n` +
      `⏰ Proses memakan waktu: 5 menit 10 detik`;

    await bot.sendMessage(chatId, userReport);
    await bot.sendMessage(chatId, finalReport, { parse_mode: "Markdown" });

  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, "⚠️ Terjadi kesalahan saat memproses /clearoff.");
  }
});  

// command /delusroff - otomatis delete all
bot.onText(/^\/delusroff$/, async (msg) => {
    const chatId = msg.chat.id;

    if ((msg.chat.type !== "group" && msg.chat.type !== "supergroup") && msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ ᴋʜᴜꜱᴜꜱ ɢʀᴜᴘ!");
  }

  const isCooldown = checkCooldown(msg);
  if (isCooldown) return bot.sendMessage(chatId, isCooldown);

  const ownerUsers = JSON.parse(fs.readFileSync(OWNER_FILE));
  const isOwner = ownerUsers.includes(String(msg.from.id));
  if (!isOwner) {
    return bot.sendMessage(chatId, "❌ ᴋʜᴜsᴜs ᴏᴡɴᴇʀ", {
      reply_markup: {
        inline_keyboard: [[{ text: "ʟᴀᴘᴏʀᴀɴ", url: `https://t.me/${dev}` }]],
      },
    });
  }

    try {
        bot.sendMessage(chatId, "🗑️ Memulai penghapusan user offline...");

        let offlineUsers = [];
        let page = 1;
        let totalPages = 1;

        // Ambil semua user
        do {
            let f = await fetch(`${domain}/api/application/users?page=${page}`, {
                method: "GET",
                headers: {
                    Accept: "application/json",
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${plta}`,
                },
            });

            let res = await f.json();
            let users = res.data;
            totalPages = res.meta.pagination.total_pages;

            for (let user of users) {
                let u = user.attributes;
                
                // Skip admin panel (root_admin)
                if (u.root_admin) continue;

                // Cek apakah user memiliki server
                let hasServer = false;
                try {
                    let serverCheck = await fetch(`${domain}/api/application/servers?filter[user_id]=${u.id}`, {
                        method: "GET",
                        headers: {
                            Accept: "application/json",
                            "Content-Type": "application/json",
                            Authorization: `Bearer ${plta}`,
                        },
                    });

                    let serverData = await serverCheck.json();
                    if (serverData.data && serverData.data.length > 0) {
                        hasServer = true;
                    }
                } catch (err) {
                    console.error(`Gagal cek server user ${u.id}`, err);
                }

                // Jika user tidak memiliki server, tambahkan ke list offline
                if (!hasServer) {
                    offlineUsers.push({ id: u.id, username: u.username, email: u.email });
                }
            }

            page++;
        } while (page <= totalPages);

        let userSuccess = [];
        let userFailed = [];

        // Hapus user offline
        for (let user of offlineUsers) {
            try {
                let del = await fetch(`${domain}/api/application/users/${user.id}`, {
                    method: "DELETE",
                    headers: {
                        Accept: "application/json",
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${plta}`,
                    },
                });

                if (del.status === 204) {
                    userSuccess.push(`✅ ${user.username} (${user.email})`);
                } else {
                    userFailed.push(`❌ ${user.username} (${user.email})`);
                }
            } catch (err) {
                console.error(`Gagal hapus user ${user.id}`, err);
                userFailed.push(`❌ ${user.username} (${user.email})`);
            }
        }

        // Laporkan hasil penghapusan user
        let userReport = `👥 ʜᴀsɪʟ ᴘᴇɴɢʜᴀᴘᴜsᴀɴ ᴜsᴇʀ ᴏғғʟɪɴᴇ:\n\n` +
            `ʙᴇʀʜᴀsɪʟ ᴅɪʜᴀᴘᴜs: ${userSuccess.length}\n` +
            `ɢᴀɢᴀʟ ᴅɪʜᴀᴘᴜs: ${userFailed.length}\n\n`;

        if (userSuccess.length) {
            userReport += `✅ ʙᴇʀʜᴀsɪʟ:\n${userSuccess.slice(0, 10).join("\n")}`;
            if (userSuccess.length > 10) userReport += `\n...dan ${userSuccess.length - 10} lainnya`;
            userReport += `\n\n`;
        }
        if (userFailed.length) {
            userReport += `❌ ɢᴀɢᴀʟ:\n${userFailed.slice(0, 5).join("\n")}`;
            if (userFailed.length > 5) userReport += `\n...dan ${userFailed.length - 5} lainnya`;
        }

        bot.sendMessage(chatId, userReport);

    } catch (error) {
        console.error('Error delusroff:', error);
        bot.sendMessage(chatId, `❌ Terjadi kesalahan: ${error.message}`);
    }
});

// Handler untuk delete all admin
bot.onText(/\/delalladp (.+)/, async (msg, match) => {
      notifyOwner('delalladp', msg);
      const chatId = msg.chat.id;
      const excludedId = match[1].trim();

      if ((msg.chat.type !== "group" && msg.chat.type !== "supergroup") && msg.from.id !== OWNER_ID) {
        return bot.sendMessage(chatId, "❌ ᴋʜᴜꜱᴜꜱ ɢʀᴜᴘ!");
      }

      const isCooldown = checkCooldown(msg);
      if (isCooldown) return bot.sendMessage(chatId, isCooldown);

      const ownerUsers = JSON.parse(fs.readFileSync(OWNER_FILE));
      const isOwner = ownerUsers.includes(String(msg.from.id));
      if (!isOwner) {
        return bot.sendMessage(chatId, "❌ ᴋʜᴜsᴜs ᴏᴡɴᴇʀ", {
          reply_markup: {
            inline_keyboard: [
              [{ text: "ʟᴀᴘᴏʀᴀɴ", url: `https://t.me/${dev}` }],
            ],
          },
        });
      }

      bot.sendMessage(chatId, `⏳ Menghapus semua admin panel kecuali ID: ${excludedId}...`);

      try {
        let page = 1;
        let totalPages = 1;
        let adminUsers = [];
        let deletedCount = 0;
        let failedCount = 0;

        // Ambil semua user dari semua halaman
        do {
          let f = await fetch(`${domain}/api/application/users?page=${page}`, {
            method: "GET",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: `Bearer ${plta}`,
            },
          });

          let res = await f.json();
          let users = res.data;
          totalPages = res.meta.pagination.total_pages;

          // Filter hanya admin panel (root_admin = true)
          for (let user of users) {
            let u = user.attributes;
            if (u.root_admin && u.id.toString() !== excludedId) {
              adminUsers.push({ id: u.id, username: u.username, email: u.email });
            }
          }

          page++;
        } while (page <= totalPages);

        // Hapus admin panel yang tidak termasuk excluded ID
        for (let admin of adminUsers) {
          try {
            let del = await fetch(`${domain}/api/application/users/${admin.id}`, {
              method: "DELETE",
              headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${plta}`,
              },
            });

            if (del.status === 204) {
              deletedCount++;
              console.log(`✅ Deleted admin: ${admin.username} (${admin.id})`);
            } else {
              failedCount++;
              console.log(`❌ Failed to delete admin: ${admin.username} (${admin.id})`);
            }
          } catch (err) {
            failedCount++;
            console.error(`Error deleting admin ${admin.id}:`, err);
          }
        }

        const resultMessage = `🗑️ *HASIL DELETE ALL ADMIN PANEL*

✅ Berhasil dihapus: ${deletedCount}
❌ Gagal dihapus: ${failedCount}
🛡️ ID yang dilindungi: ${excludedId}

${deletedCount > 0 ? '✨ Semua admin panel berhasil dihapus kecuali yang dilindungi!' : '❌ Tidak ada admin panel yang dihapus.'}`;

        bot.sendMessage(chatId, resultMessage, { parse_mode: "Markdown" });

      } catch (error) {
        console.error(error);
        bot.sendMessage(chatId, "❌ Terjadi kesalahan saat menghapus admin panel.");
      }
    });

// command /autodel - set auto delete on/off (untuk group)
bot.onText(/^\/autodel\s+(on|off)$/, (msg, match) => {
    const chatId = msg.chat.id;
    const action = match[1].toLowerCase();

    const ownerUsers = JSON.parse(fs.readFileSync(OWNER_FILE));
      const isOwner = ownerUsers.includes(String(msg.from.id));
      if (!isOwner) {
        return bot.sendMessage(chatId, "❌ ᴋʜᴜsᴜs ᴏᴡɴᴇʀ", {
          reply_markup: {
            inline_keyboard: [
              [{ text: "ʟᴀᴘᴏʀᴀɴ", url: `https://t.me/${dev}` }],
            ],
          },
        });
      }

    bot.sendMessage(chatId, '🔧 Mengatur auto-delete...', {
        reply_to_message_id: msg.message_id
    });
});

// command /setautodel - atur interval (untuk group)
bot.onText(/^\/setautodel\s+(\d+)$/, (msg, match) => {
    const chatId = msg.chat.id;
    const interval = parseInt(match[1]);

    const ownerUsers = JSON.parse(fs.readFileSync(OWNER_FILE));
      const isOwner = ownerUsers.includes(String(msg.from.id));
      if (!isOwner) {
        return bot.sendMessage(chatId, "❌ ᴋʜᴜsᴜs ᴏᴡɴᴇʀ", {
          reply_markup: {
            inline_keyboard: [
              [{ text: "ʟᴀᴘᴏʀᴀɴ", url: `https://t.me/${dev}` }],
            ],
          },
        });
      }

    if (interval < 1 || interval > 24) {
        return bot.sendMessage(chatId, '❌ Interval harus antara 1-24 jam!', {
            reply_to_message_id: msg.message_id
        });
    }

    bot.sendMessage(chatId, `✅ Interval auto-delete diatur menjadi ${interval} jam!`, {
        reply_to_message_id: msg.message_id
    });
});

// command /autodelstatus - cek status (untuk group)
bot.onText(/^\/autodelstatus$/, (msg) => {
    const chatId = msg.chat.id;

    const ownerUsers = JSON.parse(fs.readFileSync(OWNER_FILE));
      const isOwner = ownerUsers.includes(String(msg.from.id));
      if (!isOwner) {
        return bot.sendMessage(chatId, "❌ ᴋʜᴜsᴜs ᴏᴡɴᴇʀ", {
          reply_markup: {
            inline_keyboard: [
              [{ text: "ʟᴀᴘᴏʀᴀɴ", url: `https://t.me/${dev}` }],
            ],
          },
        });
      }

    const statusMessage = `
🔧 **STATUS AUTO-DELETE**

**Status:** ❌ Fitur ini hanya tersedia di private chat bot
**Info:** Gunakan command di private chat bot untuk mengatur auto-delete

**Fitur:**
- Hapus server offline otomatis
- Hapus user offline otomatis  
- Jadwal customizable (1-24 jam)
- Laporan detail setiap eksekusi
    `;

    bot.sendMessage(chatId, statusMessage, { 
        parse_mode: "Markdown",
        reply_to_message_id: msg.message_id
    });
});
 
// total server
bot.onText(/\/totalserver/, async (msg) => {
  const chatId = msg.chat.id;

  if ((msg.chat.type !== "group" && msg.chat.type !== "supergroup") && msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ ᴋʜᴜꜱᴜꜱ ɢʀᴜᴘ!");
  }

  const isCooldown = checkCooldown(msg);
  if (isCooldown) return bot.sendMessage(chatId, isCooldown);

  try {

    let page = 1;
    let totalPages = 1;
    let totalServers = 0;

    // Loop semua halaman server
    do {
      let f = await fetch(`${domain}/api/application/servers?page=${page}`, {
        method: "GET",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${plta}`,
        },
      });

      let res = await f.json();
      totalPages = res.meta.pagination.total_pages;

      if (res.data && res.data.length > 0) {
        totalServers += res.data.length;
      }

      page++;
    } while (page <= totalPages);

    return bot.sendMessage(
      chatId,
      `📊 Total server: *${totalServers}*`,
      { parse_mode: "Markdown",
    reply_to_message_id: msg.message_id }
    );

  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, "⚠️ Terjadi kesalahan saat memproses /totalserver.");
  }
});

// listadmin
bot.onText(/\/listadmin/, async (msg) => {
  const chatId = msg.chat.id;
    
  if ((msg.chat.type !== "group" && msg.chat.type !== "supergroup") && msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ ᴋʜᴜꜱᴜꜱ ɢʀᴜᴘ!");
  }
    
  const userId = msg.from.id;

  const isCooldown = checkCooldown(msg);
  if (isCooldown) return bot.sendMessage(chatId, isCooldown);

  const ownerUsers = JSON.parse(fs.readFileSync(OWNER_FILE));
  const isOwner = ownerUsers.includes(String(msg.from.id));
  if (!isOwner) {
    bot.sendMessage(chatId, "❌ ᴋʜᴜsᴜs ᴏᴡɴᴇʀ", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ʟᴀᴘᴏʀᴀɴ", url: `https://t.me/${dev}` }],
        ],
      },
    });
    return;
  }

  let page = "1";
  try {
    let f = await fetch(`${domain}/api/application/users?page=${page}`, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
    });

    let res = await f.json();
    let users = res.data;

    let messageText = "📋 ᴅᴀғᴛᴀʀ ᴀᴅᴍɪɴ:\n\n";
    for (let user of users) {
      let u = user.attributes;
      if (u.root_admin) {
        messageText += `ID: ${u.id}\n`;
        messageText += `Username: ${u.username}\n`;
        messageText += `Nama: ${u.first_name} ${u.last_name}\n`;
        messageText += `Status: ${u.attributes?.user?.server_limit === null ? "Inactive" : "Active"}\n\n`;
      }
    }

    messageText += `ʜᴀʟᴀᴍᴀɴ: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;

    bot.sendMessage(chatId, messageText);
  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, "Terjadi kesalahan dalam memproses permintaan.");
  }
});
    
// listsrv
bot.onText(/^\/listsrv$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
    
  if (msg.chat.type !== "group" && msg.chat.type !== "supergroup") {
  bot.sendMessage(msg.chat.id, "❌ ᴋʜᴜꜱᴜꜱ ɢʀᴜᴘ!");
  return;
}

  const ownerUsers = JSON.parse(fs.readFileSync(OWNER_FILE));
    
  const isOwner = ownerUsers.includes(String(msg.from.id));
  if (!isOwner) {
    bot.sendMessage(chatId, "❌ ᴋʜᴜsᴜs ᴏᴡɴᴇʀ", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ʟᴀᴘᴏʀᴀɴ", url: `https://t.me/${dev}` }],
        ],
      },
    });
    return;
  }
    
  bot.sendMessage(chatId, "⏳");
   
  let page = 1;
  try {
    let f = await fetch(`${domain}/api/application/servers?page=${page}`, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
    });
    let res = await f.json();
    let servers = res.data;
    let messageText = "ᴅᴀғᴛᴀʀ sᴇʀᴠᴇʀ:\n\n";
    for (let server of servers) {
      let s = server.attributes;

      let f3 = await fetch(
        `${domain}/api/client/servers/${s.uuid.split("-")[0]}/resources`,
        {
          method: "GET",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${pltc}`,
          },
        }
      );
      let data = await f3.json();
      let status = data.attributes ? data.attributes.current_state : s.status;

      messageText += `ID Server: ${s.id}\n`;
      messageText += `Nama Server: ${s.name}\n`;
      messageText += `Status: ${status}\n\n`;
    }

    bot.sendMessage(chatId, messageText);
  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, "Terjadi kesalahan dalam memproses permintaan.");
}});
    
}