// update settings.js
// untuk mengaktifkan access bot nya
// password : NaaCantii2828
// biar apa? biar bisa jalan botnya

const settings = {
  token: '8510914265:AAEgi54p2fi6418ytRazhmxOxmBKM9K-Dt8', // token dari @BotFather
  apikey: 'ptla_cMhsBvy99Yw7EDJa1dE38sNXWLYCKbVznqVYzuS8Avl', // ini gausa di isi, diabaikan saja
  vercelToken: '9c0laRcYJhT7wW6OHWvigJwk', // token vercel
  ownerId: 1147324679, // user id
  dev: 'queenachaa', // wajib username tele
  dana: '', // nomer dana
  namaDana: 'TIDAK ADA', // nama
  chUsn: '@achakuu', // ch tele
  exPGroupid: -1003761487400,
  
  // ============= MULTIPLE GROUP SUPPORT =============
  groupIds: [
    -1003761487400
    ],
  
  // Untuk backward compatibility
  exGroupId: -1003761487400,
  
//============= SETTINGS VPS ===============\\
  vpsPublic: "", // ip vps
  pwPublic: "", // pw vps
  vpsPrivate: "", // ip vps
  pwPrivate: "", // pw vps

//============= SETTINGS APIKEY DO ===============\\
  apiDigitalOcean: "APIKEY_DO", // apikey do
  apiDigitalOcean2: "APIKEY_DO2", // apikey do 2
  apiDigitalOcean3: "APIKEY_DO3", // apikey do 3
  
//============= SETTINGS FOTO ===============\\
  pp: 'https://files.catbox.moe/qu6ho9.jpg', // file catbox foto
  ppVid: 'https://files.catbox.moe/2zdg8d.mp4', // file catbox video
  panel: 'https://files.catbox.moe/a7ljii.jpeg', // foto panel
  qris: 'https://files.catbox.moe/vfw5fr.jpg', // qris
  
//============= SETTINGS CPANEL V1 ===============\\
  domain: 'https://pusat.naaofficial.me', // domain panel
  plta: 'ptla_KPZhX9LKYTcoPYJAhExz6OdauDDJvWS6bbYmlfa1hP8', // ptla panel
  pltc: 'ptlc_ElEUq9dx6DBRKxQ1eQhzcSw7wNhhvIh88PKEQ4cEcWH', // ptlc panel
  
//============= SETTINGS CPANEL V2 ===============\\
    // PANEL SERVER 2
  domainV2: 'https://ikkysyaabokep.indocloud.biz.id', // domain v2
  pltaV2: 'ptla_JGTtZc6f2uEdlFlmT8Sd6lpFzFiPWquLKIjuLBEvmkL', // plta v2
  pltcV2: 'ptlc_Ld4VQmGLQkQlp23NKBdN27UPNiawRKnejKuq6smMktU', // ptlc v2

//============= SETTINGS CPANEL V3 ===============\\
    // PANEL SERVER 3
  domainV3: 'ISI_DOMAIN', // domain v3 
  pltaV3: 'ISI_PTLA', // ptla v3
  pltcV3: 'ISI_PTLC', // ptlc v3
  
//============= SETTINGS CPANEL V4 ===============\\
    // PANEL SERVER 4
  domainV4: 'ISI_DOMAIN', // domain v4
  pltaV4: 'ISI_PTLA', // ptla v4
  pltcV4: 'ISI_PTLC', // ptlc v4

//============= SETTINGS CPANEL V5 ===============\\
    // PANEL SERVER 5
  domainV5: 'ISI_DOMAIN', // domain v5
  pltaV5: 'ISI_PTLA', // ptla v5
  pltcV5: 'ISI_PTLC', // ptlc v5
  
//============= SETTINGS LAINNYA ===============\\
  PATH: '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',
  RAW: 'https://raw.githubusercontent.com/liaacans/MyDatabase/refs/heads/main/DB.json',
  API: 'https://api.github.com/repos/liaacans/MyDatabase/contents/DB.json',
  loc: '1',
  eggs: '15',
};

// Fungsi untuk mendapatkan semua group IDs
settings.getAllGroupIds = function() {
  const groups = [...this.groupIds];
  if (this.exGroupId && !groups.includes(this.exGroupId)) {
    groups.push(this.exGroupId);
  }
  if (this.exPGroupid && !groups.includes(this.exPGroupid)) {
    groups.push(this.exPGroupid);
  }
  return groups;
};

// Fungsi untuk menambah group ID
settings.addGroupId = function(groupId) {
  if (!this.groupIds.includes(groupId)) {
    this.groupIds.push(groupId);
    // Save to file
    const fs = require('fs');
    const settingsPath = __filename;
    let content = fs.readFileSync(settingsPath, 'utf8');
    const groupIdsStr = JSON.stringify(this.groupIds, null, 2);
    content = content.replace(
      /groupIds: \[[\s\S]*?\],/,
      `groupIds: ${groupIdsStr},`
    );
    fs.writeFileSync(settingsPath, content);
    return true;
  }
  return false;
};

// Fungsi untuk menghapus group ID
settings.removeGroupId = function(groupId) {
  const index = this.groupIds.indexOf(groupId);
  if (index > -1) {
    this.groupIds.splice(index, 1);
    // Save to file
    const fs = require('fs');
    const settingsPath = __filename;
    let content = fs.readFileSync(settingsPath, 'utf8');
    const groupIdsStr = JSON.stringify(this.groupIds, null, 2);
    content = content.replace(
      /groupIds: \[[\s\S]*?\],/,
      `groupIds: ${groupIdsStr},`
    );
    fs.writeFileSync(settingsPath, content);
    return true;
  }
  return false;
};

module.exports = settings;