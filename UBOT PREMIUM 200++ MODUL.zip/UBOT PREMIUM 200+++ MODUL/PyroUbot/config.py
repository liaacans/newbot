import os
from dotenv import load_dotenv

load_dotenv(".env")

MAX_BOT = int(os.getenv("MAX_BOT", "100"))

DEVS = list(map(int, os.getenv("DEVS", "7568960443").split()))

API_ID = int(os.getenv("API_ID", "34846365"))

API_HASH = os.getenv("API_HASH", "0b62ccec3ccd6caeb5514a267d89f8b6")

BOT_TOKEN = os.getenv("BOT_TOKEN", "8201573377:AAFIDPVOirDk9jSBOLFwOMAX4kpKufDGxXY")

OWNER_ID = int(os.getenv("OWNER_ID", "7568960443"))

BLACKLIST_CHAT = list(map(int, os.getenv("BLACKLIST_CHAT", "-1002125842026 -1002053287763 -1002044997044 -1002022625433 -1002050846285 -1002400165299 -1002416419679 -1001473548283").split()))

RMBG_API = os.getenv("RMBG_API", "MA2sUZ4HdAfBegL36HiG4BUG")

MONGO_URL = os.getenv("MONGO_URL", "mongodb://ubottme_usuallyif:3ff1cb26f356186de048d49df9a5c8d9ce7e18e4@u0ikyu.h.filess.io:61004/ubottme_usuallyif")
LOGS_MAKER_UBOT = int(os.getenv("LOGS_MAKER_UBOT", "-4628173231"))
