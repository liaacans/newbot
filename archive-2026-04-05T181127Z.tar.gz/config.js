module.exports = {
  bot_token: '8763549790:AAHlfcLzb81oKNOuhH8p_b6RAqZvYDDL1S0',
  owner_ids: ['1147324679'],
  cs_admins: [],
  channel: '@achaimutt',
  channel_otp: "",
  type_ewallet_RUMAHOTP: "DANA",
  nomor_pencairan_RUMAHOTP: "085654127071",
  aboutmilaa: "@achakuuu",
  domain: 'https://www.rumahotp.io/api',
  apikey: 'rk-dev-jOMNOcpw60sn9tCbdrYIu3Px5ji8VGqD',
  cashify_apikey: '',
  cashify_qr_id: '',
  
  // Atlantic PG Configuration
  atlantic_api_key: 'G1g8QlGU0yGX3PguKuVh7lLirjHxhRKrvutiQcx6RehWvjqMptn44HGap0X8KF0Q30dGObSe7MhSAkWshWhpt907NIRnqyhpsgE1',
  atlantic_base_url: 'https://atlantich2h.com',
  
  // Telegram Account Prices berdasarkan ID Nokos
  telegram_account_prices: {
    'indonesia': {
      1: 25000,  // ID 1 = 25.000
      2: 25000,  // ID 2 = 25.000
      3: 20000,  // ID 3 = 20.000
      4: 20000,  // ID 4 = 20.000
      5: 15000,  // ID 5 = 15.000
      6: 10000,  // ID 6 = 10.000
      7: 10000,  // ID 7 = 10.000
      8: 10000,  // ID 8 = 10.000
      9: 5000    // ID 9 = 5.000
    },
    'malaysia': {
      1: 35000,  // ID 1 = 35.000
      2: 35000,  // ID 2 = 35.000
      3: 30000,  // ID 3 = 30.000
      4: 30000,  // ID 4 = 30.000
      5: 25000,  // ID 5 = 25.000
      6: 20000,  // ID 6 = 20.000
      7: 20000,  // ID 7 = 20.000
      8: 20000,  // ID 8 = 20.000
      9: 15000   // ID 9 = 15.000
    },
    'amerika': {
      1: 50000,  // ID 1 = 50.000
      2: 50000,  // ID 2 = 50.000
      3: 45000,  // ID 3 = 45.000
      4: 45000,  // ID 4 = 45.000
      5: 40000,  // ID 5 = 40.000
      6: 35000,  // ID 6 = 35.000
      7: 35000,  // ID 7 = 35.000
      8: 35000,  // ID 8 = 35.000
      9: 30000   // ID 9 = 30.000
    },
    'india': {
      1: 30000,  // ID 1 = 30.000
      2: 30000,  // ID 2 = 30.000
      3: 25000,  // ID 3 = 25.000
      4: 25000,  // ID 4 = 25.000
      5: 20000,  // ID 5 = 20.000
      6: 15000,  // ID 6 = 15.000
      7: 15000,  // ID 7 = 15.000
      8: 15000,  // ID 8 = 15.000
      9: 10000   // ID 9 = 10.000
    },
    'dubai': {
      1: 55000,  // ID 1 = 55.000
      2: 55000,  // ID 2 = 55.000
      3: 50000,  // ID 3 = 50.000
      4: 50000,  // ID 4 = 50.000
      5: 45000,  // ID 5 = 45.000
      6: 40000,  // ID 6 = 40.000
      7: 40000,  // ID 7 = 40.000
      8: 40000,  // ID 8 = 40.000
      9: 35000   // ID 9 = 35.000
    },
    'turki': {
      1: 40000,  // ID 1 = 40.000
      2: 40000,  // ID 2 = 40.000
      3: 35000,  // ID 3 = 35.000
      4: 35000,  // ID 4 = 35.000
      5: 30000,  // ID 5 = 30.000
      6: 25000,  // ID 6 = 25.000
      7: 25000,  // ID 7 = 25.000
      8: 25000,  // ID 8 = 25.000
      9: 20000   // ID 9 = 20.000
    }
  },
  
  // Withdraw prices (setor akun) berdasarkan ID Nokos
  telegram_withdraw_prices: {
    1: 10000,   // ID 1 = 10.000
    2: 10000,   // ID 2 = 10.000
    3: 10000,   // ID 3 = 10.000
    4: 8000,    // ID 4 = 8.000
    5: 6000,    // ID 5 = 6.000
    6: 4000,    // ID 6 = 4.000
    7: 2500,    // ID 7 = 2.500
    8: 2800,    // ID 8 = 2.800
    9: 2000     // ID 9 = 2.000
  },
  
  // Nokos IDs untuk akun Telegram
  telegram_nokos_ids: [1, 2, 3, 4, 5, 6, 7, 8, 9]
};