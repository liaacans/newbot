#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import asyncio
import json
import os
import sys
import re
import secrets
import time
from datetime import datetime
from pathlib import Path
from telethon import TelegramClient, errors
from telethon.tl.functions.account import UpdateStatusRequest
from telethon.tl.functions.auth import LogOutRequest
import argparse

# Konfigurasi
BASE_DIR = Path(__file__).parent.parent
SESSION_DIR = BASE_DIR / 'database' / 'telegram_sessions'
ACCOUNTS_FILE = BASE_DIR / 'database' / 'telegram_accounts.json'
ORDERS_FILE = BASE_DIR / 'database' / 'telegram_orders.json'

# Buat direktori jika belum ada
SESSION_DIR.mkdir(parents=True, exist_ok=True)

# API ID dan Hash untuk Telegram (dari my.telegram.org)
# Ganti dengan credentials Anda sendiri
API_ID = 38617387  # Contoh API ID, ganti dengan milik Anda
API_HASH = '297a1438c58debb60030dd864621d0aa'  # Contoh API Hash, ganti dengan milik Anda

# Negara yang didukung dengan kode area
SUPPORTED_COUNTRIES = {
    'indonesia': {'code': '+62', 'pattern': r'^62\d{9,12}$'},
    'malaysia': {'code': '+60', 'pattern': r'^60\d{8,11}$'},
    'amerika': {'code': '+1', 'pattern': r'^1\d{10}$'},
    'india': {'code': '+91', 'pattern': r'^91\d{10}$'},
    'dubai': {'code': '+971', 'pattern': r'^971\d{9}$'},
    'turki': {'code': '+90', 'pattern': r'^90\d{10}$'}
}

class TelegramAccountManager:
    def __init__(self):
        self.load_data()
    
    def load_data(self):
        """Load data dari file JSON"""
        if ACCOUNTS_FILE.exists():
            with open(ACCOUNTS_FILE, 'r') as f:
                self.accounts = json.load(f)
        else:
            self.accounts = {
                'available': [],
                'sold': [],
                'pending': [],
                'login_attempts': []
            }
            self.save_data()
        
        if ORDERS_FILE.exists():
            with open(ORDERS_FILE, 'r') as f:
                self.orders = json.load(f)
        else:
            self.orders = []
            self.save_orders()
    
    def save_data(self):
        """Save data ke file JSON"""
        with open(ACCOUNTS_FILE, 'w') as f:
            json.dump(self.accounts, f, indent=2, default=str)
    
    def save_orders(self):
        """Save orders ke file JSON"""
        with open(ORDERS_FILE, 'w') as f:
            json.dump(self.orders, f, indent=2, default=str)
    
    def add_account(self, phone_number, country, nokos_id, session_string=None, password=None):
        """Tambah akun Telegram ke database"""
        account_id = secrets.token_hex(8)
        
        # Bersihkan nomor telepon
        clean_phone = re.sub(r'[^\d]', '', phone_number)
        
        new_account = {
            'id': account_id,
            'phone_number': phone_number,
            'country': country,
            'nokos_id': int(nokos_id),
            'session_string': session_string,
            'password': password,
            'status': 'available',
            'created_at': datetime.now().isoformat(),
            'login_count': 0,
            'last_login': None,
            'verified': False,
            'username': None,
            'first_name': None
        }
        
        self.accounts['available'].append(new_account)
        self.save_data()
        
        return new_account, None
    
    def get_available_accounts(self, country=None, nokos_id=None):
        """Get available accounts with filters"""
        available = self.accounts['available']
        
        if country:
            available = [a for a in available if a['country'] == country]
        if nokos_id:
            available = [a for a in available if a['nokos_id'] == int(nokos_id)]
        
        return available
    
    def mark_as_sold(self, account_id, buyer_id, order_id):
        """Mark account as sold"""
        for i, account in enumerate(self.accounts['available']):
            if account['id'] == account_id:
                account['status'] = 'sold'
                account['sold_at'] = datetime.now().isoformat()
                account['buyer_id'] = buyer_id
                account['order_id'] = order_id
                self.accounts['sold'].append(account)
                del self.accounts['available'][i]
                self.save_data()
                
                # Hapus sesi
                self.delete_session(account_id)
                
                return True
        return False
    
    def delete_session(self, account_id):
        """Delete session file for account"""
        session_path = SESSION_DIR / f"{account_id}.session"
        if session_path.exists():
            session_path.unlink()
            return True
        return False
    
    def update_account_info(self, account_id, username, first_name):
        """Update account info after successful login"""
        for account in self.accounts['available']:
            if account['id'] == account_id:
                account['username'] = username
                account['first_name'] = first_name
                account['verified'] = True
                self.save_data()
                return True
        return False
    
    def add_login_attempt(self, account_id, status, message):
        """Log login attempt"""
        attempt = {
            'account_id': account_id,
            'status': status,
            'message': message,
            'timestamp': datetime.now().isoformat()
        }
        self.accounts['login_attempts'].append(attempt)
        
        # Keep only last 50 attempts
        if len(self.accounts['login_attempts']) > 50:
            self.accounts['login_attempts'] = self.accounts['login_attempts'][-50:]
        
        self.save_data()

class TelegramSessionManager:
    def __init__(self, account_manager):
        self.account_manager = account_manager
        self.active_clients = {}
    
    async def add_account_realtime(self, phone_number, country, nokos_id, phone_code=None, password=None, is_owner=True):
        """Add Telegram account in realtime with verification"""
        if not is_owner:
            return {'status': 'error', 'message': 'Hanya owner yang bisa menambah akun'}
        
        # Validasi negara
        if country not in SUPPORTED_COUNTRIES:
            return {'status': 'error', 'message': f'Negara {country} tidak didukung'}
        
        # Format nomor
        country_config = SUPPORTED_COUNTRIES[country]
        clean_phone = re.sub(r'[^\d]', '', phone_number)
        if not clean_phone.startswith(country_config['code'].replace('+', '')):
            clean_phone = country_config['code'].replace('+', '') + clean_phone
        
        full_phone = f"+{clean_phone}"
        
        # Buat ID akun sementara
        temp_id = f"temp_{int(time.time())}_{secrets.token_hex(4)}"
        
        # Buat client Telegram
        session_path = str(SESSION_DIR / temp_id)
        client = TelegramClient(session_path, API_ID, API_HASH)
        
        try:
            await client.connect()
            
            if not await client.is_user_authorized():
                if phone_code:
                    # Verifikasi dengan kode
                    try:
                        await client.sign_in(full_phone, code=phone_code)
                        
                        # Login berhasil
                        me = await client.get_me()
                        
                        # Simpan session string
                        session_string = client.session.save()
                        
                        # Tambahkan ke database
                        account, error = self.account_manager.add_account(
                            full_phone, country, nokos_id, session_string, password
                        )
                        
                        if account:
                            self.account_manager.update_account_info(
                                account['id'], me.username, me.first_name
                            )
                            self.account_manager.add_login_attempt(
                                account['id'], 'success', 'Login berhasil'
                            )
                            
                            # Logout dan tutup koneksi
                            await client(LogOutRequest())
                            await client.disconnect()
                            
                            # Hapus session sementara
                            session_file = Path(session_path + ".session")
                            if session_file.exists():
                                session_file.unlink()
                            
                            return {
                                'status': 'success',
                                'account': account,
                                'user': {
                                    'id': me.id,
                                    'username': me.username,
                                    'first_name': me.first_name,
                                    'phone': me.phone
                                }
                            }
                        else:
                            return {'status': 'error', 'message': error}
                        
                    except errors.PhoneCodeInvalidError:
                        return {'status': 'error', 'message': 'Kode verifikasi salah'}
                    except errors.PhoneCodeExpiredError:
                        return {'status': 'error', 'message': 'Kode verifikasi sudah kadaluarsa'}
                    except errors.SessionPasswordNeededError:
                        return {'status': 'need_password', 'message': 'Kata sandi 2FA diperlukan', 'temp_id': temp_id, 'phone': full_phone}
                    except Exception as e:
                        return {'status': 'error', 'message': str(e)}
                else:
                    # Kirim kode verifikasi
                    try:
                        await client.send_code_request(full_phone)
                        return {
                            'status': 'need_code',
                            'message': f'Kode verifikasi telah dikirim ke {full_phone}',
                            'temp_id': temp_id,
                            'phone': full_phone,
                            'country': country,
                            'nokos_id': nokos_id
                        }
                    except errors.PhoneNumberInvalidError:
                        return {'status': 'error', 'message': 'Nomor telepon tidak valid'}
                    except errors.FloodWaitError as e:
                        return {'status': 'error', 'message': f'Tunggu {e.seconds} detik sebelum mencoba lagi'}
                    except Exception as e:
                        return {'status': 'error', 'message': str(e)}
            else:
                return {'status': 'error', 'message': 'Session sudah aktif'}
                
        except Exception as e:
            return {'status': 'error', 'message': str(e)}
        finally:
            try:
                await client.disconnect()
            except:
                pass
    
    async def verify_code(self, temp_id, phone, country, nokos_id, code, password=None):
        """Verify phone code and complete account addition"""
        session_path = str(SESSION_DIR / temp_id)
        client = TelegramClient(session_path, API_ID, API_HASH)
        
        try:
            await client.connect()
            
            if password:
                # 2FA login
                await client.sign_in(password=password)
            else:
                await client.sign_in(phone, code=code)
            
            me = await client.get_me()
            
            # Simpan session string
            session_string = client.session.save()
            
            # Tambahkan ke database
            account, error = self.account_manager.add_account(
                phone, country, nokos_id, session_string, password
            )
            
            if account:
                self.account_manager.update_account_info(
                    account['id'], me.username, me.first_name
                )
                self.account_manager.add_login_attempt(
                    account['id'], 'success', 'Verifikasi berhasil'
                )
                
                # Logout
                await client(LogOutRequest())
                await client.disconnect()
                
                # Hapus session sementara
                session_file = Path(session_path + ".session")
                if session_file.exists():
                    session_file.unlink()
                
                return {
                    'status': 'success',
                    'account': account,
                    'user': {
                        'id': me.id,
                        'username': me.username,
                        'first_name': me.first_name,
                        'phone': me.phone
                    }
                }
            else:
                return {'status': 'error', 'message': error}
                
        except errors.PasswordHashInvalidError:
            return {'status': 'error', 'message': 'Kata sandi 2FA salah'}
        except errors.PhoneCodeInvalidError:
            return {'status': 'error', 'message': 'Kode verifikasi salah'}
        except errors.PhoneCodeExpiredError:
            return {'status': 'error', 'message': 'Kode verifikasi sudah kadaluarsa'}
        except Exception as e:
            return {'status': 'error', 'message': str(e)}
        finally:
            try:
                await client.disconnect()
            except:
                pass
    
    async def test_login(self, account_id):
        """Test login to verify account is working"""
        account = None
        for acc in self.account_manager.accounts['available']:
            if acc['id'] == account_id:
                account = acc
                break
        
        if not account:
            return {'status': 'error', 'message': 'Akun tidak ditemukan'}
        
        if not account.get('session_string'):
            return {'status': 'error', 'message': 'Session tidak ditemukan'}
        
        session_path = str(SESSION_DIR / f"{account_id}_test")
        
        # Simpan session string ke file sementara
        with open(f"{session_path}.session", 'w') as f:
            f.write(account['session_string'])
        
        client = TelegramClient(session_path, API_ID, API_HASH)
        
        try:
            await client.connect()
            
            if await client.is_user_authorized():
                me = await client.get_me()
                return {
                    'status': 'success',
                    'user': {
                        'id': me.id,
                        'username': me.username,
                        'first_name': me.first_name,
                        'phone': me.phone
                    }
                }
            else:
                return {'status': 'error', 'message': 'Session expired'}
        except Exception as e:
            return {'status': 'error', 'message': str(e)}
        finally:
            await client.disconnect()
            # Hapus session test
            session_file = Path(f"{session_path}.session")
            if session_file.exists():
                session_file.unlink()
    
    async def logout_account(self, account_id):
        """Logout dari akun Telegram"""
        account = None
        for acc in self.account_manager.accounts['available']:
            if acc['id'] == account_id:
                account = acc
                break
        
        if not account:
            return False
        
        if account.get('session_string'):
            # Buat session dari string
            session_path = str(SESSION_DIR / f"{account_id}_logout")
            with open(f"{session_path}.session", 'w') as f:
                f.write(account['session_string'])
            
            client = TelegramClient(session_path, API_ID, API_HASH)
            try:
                await client.connect()
                if await client.is_user_authorized():
                    await client(LogOutRequest())
            except:
                pass
            finally:
                await client.disconnect()
            
            # Hapus file session
            session_file = Path(f"{session_path}.session")
            if session_file.exists():
                session_file.unlink()
        
        # Hapus session string dari database
        account['session_string'] = None
        self.account_manager.save_data()
        
        # Hapus file session utama
        self.account_manager.delete_session(account_id)
        
        return True

async def main():
    parser = argparse.ArgumentParser(description='Telegram Account Manager')
    parser.add_argument('action', choices=['add', 'list', 'info', 'logout', 'check', 'verify', 'test'])
    parser.add_argument('--account-id', help='Account ID')
    parser.add_argument('--phone', help='Phone number')
    parser.add_argument('--country', help='Country')
    parser.add_argument('--nokos-id', help='Nokos ID (1-9)')
    parser.add_argument('--code', help='Verification code')
    parser.add_argument('--password', help='2FA password')
    parser.add_argument('--temp-id', help='Temporary ID for verification')
    parser.add_argument('--owner', action='store_true', help='Is owner')
    
    args = parser.parse_args()
    
    account_manager = TelegramAccountManager()
    session_manager = TelegramSessionManager(account_manager)
    
    if args.action == 'add':
        if not args.phone or not args.country or not args.nokos_id:
            print(json.dumps({'error': 'Missing required parameters: phone, country, nokos_id'}))
            return
        
        is_owner = args.owner or False
        
        result = await session_manager.add_account_realtime(
            args.phone, args.country, int(args.nokos_id), 
            args.code, args.password, is_owner
        )
        print(json.dumps(result))
    
    elif args.action == 'verify':
        if not args.temp_id or not args.phone or not args.country or not args.nokos_id or not args.code:
            print(json.dumps({'error': 'Missing required parameters'}))
            return
        
        result = await session_manager.verify_code(
            args.temp_id, args.phone, args.country, int(args.nokos_id), 
            args.code, args.password
        )
        print(json.dumps(result))
    
    elif args.action == 'list':
        accounts = account_manager.get_available_accounts(args.country, args.nokos_id)
        filtered = []
        for acc in accounts:
            filtered.append({
                'id': acc['id'],
                'phone_number': acc['phone_number'],
                'country': acc['country'],
                'nokos_id': acc['nokos_id'],
                'status': acc['status'],
                'verified': acc.get('verified', False),
                'username': acc.get('username'),
                'first_name': acc.get('first_name'),
                'created_at': acc['created_at']
            })
        print(json.dumps({'status': 'success', 'accounts': filtered, 'count': len(filtered)}))
    
    elif args.action == 'info':
        if not args.account_id:
            print(json.dumps({'error': 'Missing account-id'}))
            return
        
        account = None
        for acc in account_manager.accounts['available']:
            if acc['id'] == args.account_id:
                account = acc
                break
        
        if not account:
            print(json.dumps({'error': 'Account not found'}))
            return
        
        print(json.dumps({'status': 'success', 'account': account}))
    
    elif args.action == 'test':
        if not args.account_id:
            print(json.dumps({'error': 'Missing account-id'}))
            return
        
        result = await session_manager.test_login(args.account_id)
        print(json.dumps(result))
    
    elif args.action == 'logout':
        if not args.account_id:
            print(json.dumps({'error': 'Missing account-id'}))
            return
        
        result = await session_manager.logout_account(args.account_id)
        print(json.dumps({'status': 'success' if result else 'error'}))
    
    elif args.action == 'check':
        if not args.account_id:
            print(json.dumps({'error': 'Missing account-id'}))
            return
        
        account = None
        for acc in account_manager.accounts['available']:
            if acc['id'] == args.account_id:
                account = acc
                break
        
        if account:
            print(json.dumps({'status': 'success', 'exists': True, 'account': account}))
        else:
            print(json.dumps({'status': 'success', 'exists': False}))

if __name__ == '__main__':
    asyncio.run(main())