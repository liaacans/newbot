// premium-store.js
const axios = require('axios');
const config = require('./config');

class PremiumStore {
    constructor() {
        this.apiKey = config.premium_api_key;
        this.baseUrl = config.premium_api_url;
    }

    async request(endpoint, data = {}) {
        try {
            const response = await axios.post(`${this.baseUrl}/${endpoint}`, {
                api_key: this.apiKey,
                ...data
            }, {
                headers: { 'Content-Type': 'application/json' },
                timeout: 30000
            });
            return response.data;
        } catch (error) {
            console.error(`PremiumStore API Error (${endpoint}):`, error.message);
            return { success: false, message: error.message };
        }
    }

    async getProfile() {
        return await this.request('profile');
    }

    async getProducts() {
        return await this.request('products');
    }

    async getStock(productId) {
        return await this.request('stock', { product_id: productId });
    }

    async createOrder(productId, qty, refId) {
        return await this.request('order', {
            product_id: productId,
            qty: qty,
            ref_id: refId
        });
    }

    async checkStatus(invoice) {
        return await this.request('status', { invoice: invoice });
    }

    async createDeposit(amount) {
        return await this.request('pay', { amount: amount });
    }

    async checkDepositStatus(invoice) {
        return await this.request('pay_status', { invoice: invoice });
    }

    async cancelDeposit(invoice) {
        return await this.request('cancel_pay', { invoice: invoice });
    }
}

module.exports = PremiumStore;