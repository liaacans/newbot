module.exports = {
  bot_token: '7515293027:AAG9ICbs_XMlYnJCGUW7dpu8Aea3USAMn6E',
  owner_ids: ['1147324679'],
  cs_admins: [], // Ganti dengan ID Telegram CS Admin
  channel: '@achaimutt',
  channel_otp: "", // kalau gabisa pake @namachannelmu kosongkan juga bisa tuh
  type_ewallet_RUMAHOTP: "DANA",
  nomor_pencairan_RUMAHOTP: "085654127071",
  aboutmilaa: "@achaacloud",
  domain: 'https://www.rumahotp.io/api',
  apikey: 'rk-dev-NJEoOm3yPuOwc5KXESlU3eibvo3Tu8iG',
  cashify_apikey: '',
  cashify_qr_id: '' 
};