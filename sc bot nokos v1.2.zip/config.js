module.exports = {
  bot_token: '7515293027:AAG9ICbs_XMlYnJCGUW7dpu8Aea3USAMn6E',
  owner_ids: ['1147324679'],
  cs_admins: [], // Ganti dengan ID Telegram CS Admin
  channel: '@achaimutt',
  channel_otp: "", // kalau gabisa pake @namachannelmu kosongkan juga bisa tuh
  type_ewallet_RUMAHOTP: "DANA",
  nomor_pencairan_RUMAHOTP: "085654127071",
  aboutmilaa: "@achakuuu",
  domain: 'https://rumahotp.io/api',
  apikey: 'rk-dev-hdKy5nShunD0cONFsNjuwW5kmgocbGME',
  cashify_apikey: '',
  cashify_qr_id: '' 
};