const TelegramBot = require('node-telegram-bot-api');
const axios = require('axios');
const chalk = require('chalk');
const fs = require('fs');
const path = require('path');
const fsAsync = require('fs').promises;
const archiver = require('archiver');
const QRCode = require('qrcode');
const config = require('./config');
const api = require('./x-apikey');
const CashifyService = require('./x-apikeyv2'); 
const cashifyService = new CashifyService(); 


const bot = new TelegramBot(config.bot_token, {
  polling: { 
    interval: 50,
    params: { 
      timeout: 10,
      allowed_updates: ['message', 'callback_query']
    }
  }
});

const x_apikey = config.apikey;
const x_domain = config.domain;
const owner_ids = config.owner_ids;
const channel = config.channel;
const channel_otp = config.channel_otp;
const aboutmilaa = config.aboutmilaa;

const userSessions = new Map();
const userLastMessage = new Map();
const userFirstTimeNotifications = new Set();
const userSelections = new Map();
const userDepositMessages = new Map();
const userPendingCommands = new Map();
const balanceCache = new Map();
const transactionCache = new Map();
const priceCache = new Map();
const priceHistory = new Map();
const lastNotificationTime = new Map();
const sentNotifications = new Map();
const orderProcessing = new Map();
const depositProcessing = new Map();
const voucherCache = new Map();
const UNTUNG_NOKOS = config.UNTUNG_NOKOS || 0; // Default 0 jika tidak ada di config
// Tambahkan Set untuk melacak pesan OTP di channel
const channelOTPMessages = new Map(); // Map<messageId, {orderId, deleteTimeout, timestamp}>
let isCheckingPrices = false;

const dataDir = path.join(__dirname, 'database');
const datafile = path.join(dataDir, 'users.json');
const transactionsFile = path.join(dataDir, 'transactions.json');
const balanceFile = path.join(dataDir, 'balances.json');
const settingsFile = path.join(dataDir, 'settings.json');
const vouchersFile = path.join(dataDir, 'vouchers.json');


if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

if (!global.csChatSessions) {
  global.csChatSessions = new Map();
}

const sendMessage = (chatId, text) => bot.sendMessage(chatId, text);
bot.setMyCommands([
  { command: "start", description: "Start the bot" },
  { command: "broadcast", description: "Broadcast Users (Owner)" },
  { command: "stats", description: "Melihat Saldo Provider (Owner)" },
  { command: "maintenance", description: "Set Maintenance (Owner)" },
  { command: "addsaldo", description: "Menambah Saldo Users (Owner)" },
  { command: "setprofit", description: "Set Profit Harga Nokos (Owner)" }
]);

// ========================= FUNGSI UNTUK MENAMBAH KEUNTUNGAN NOKOS =========================

/**
 * Menambahkan keuntungan ke harga nokos
 * @param {number} originalPrice - Harga asli dari API
 * @returns {number} Harga setelah ditambah keuntungan
 */
function addProfitToPrice(originalPrice) {
    const numPrice = Number(originalPrice) || 0;
    const profit = Number(config.UNTUNG_NOKOS) || 0;
    return numPrice + profit;
}

/**
 * Mengembalikan harga ke nilai asli (untuk refund)
 * @param {number} priceWithProfit - Harga dengan keuntungan
 * @returns {number} Harga asli tanpa keuntungan
 */
function removeProfitFromPrice(priceWithProfit) {
    const numPrice = Number(priceWithProfit) || 0;
    const profit = Number(config.UNTUNG_NOKOS) || 0;
    return Math.max(0, numPrice - profit);
}

/**
 * Memformat harga dengan informasi keuntungan
 * @param {number} originalPrice - Harga asli dari API
 * @param {number} finalPrice - Harga final dengan keuntungan
 * @returns {string} String informasi harga
 */
function formatPriceWithProfit(originalPrice, finalPrice) {
    const profit = finalPrice - originalPrice;
    if (profit > 0) {
        return `${formatCurrency(finalPrice)} (Harga: ${formatCurrency(originalPrice)} + Keuntungan: ${formatCurrency(profit)})`;
    }
    return formatCurrency(finalPrice);
}

function loadSettings() {
  try {
    if (!fs.existsSync(settingsFile)) {
      const defaultSettings = {
        maintenance: false,
        maintenance_reason: '',
        maintenance_time: '',
        payment_method: 'rumahotp'
      };
      saveSettings(defaultSettings);
      return defaultSettings;
    }
    return JSON.parse(fs.readFileSync(settingsFile, 'utf8'));
  } catch (e) {
    return {
      maintenance: false,
      maintenance_reason: '',
      maintenance_time: '',
      payment_method: 'cashify'
    };
  }
}

function saveSettings(settings) {
  try {
    fs.writeFileSync(settingsFile, JSON.stringify(settings, null, 2));
    return true;
  } catch (error) {
    return false;
  }
}

function loadBalances() {
  try {
    if (!fs.existsSync(balanceFile)) {
      return {};
    }
    const data = fs.readFileSync(balanceFile, 'utf8');
    const parsed = JSON.parse(data);
    return parsed;
  } catch (e) {
    console.error('Error loading balances:', e);
    return {};
  }
}

function saveBalances(balances) {
  try {
    fs.writeFileSync(balanceFile, JSON.stringify(balances, null, 2));
    return true;
  } catch (error) {
    console.error('Error saving balances:', error);
    return false;
  }
}

function getUserBalance(userId) {
    try {
        const userIdStr = String(userId);
        
        console.log(`[DEBUG getUserBalance] User ID: ${userId} (string: ${userIdStr})`);
        
        // Cek jika sedang deposit
        if (depositProcessing.has(`${userId}_deposit`)) {
            console.log(`[DEBUG getUserBalance] Deposit processing for ${userId}, clearing cache`);
            balanceCache.delete(userIdStr);
        }
        
        // Cek cache
        if (balanceCache.has(userIdStr)) {
            const cached = balanceCache.get(userIdStr);
            const result = isNaN(cached) ? 0 : Number(cached);
            console.log(`[DEBUG getUserBalance] Cache hit for ${userId}: ${result}`);
            return result;
        }
        
        // Load dari file
        console.log(`[DEBUG getUserBalance] Cache miss for ${userId}, loading from file`);
        const balances = loadBalances();
        
        const rawBalance = balances[userIdStr];
        console.log(`[DEBUG getUserBalance] Raw balance from file: ${rawBalance} (type: ${typeof rawBalance})`);
        
        const balance = parseInt(rawBalance) || 0;
        const numBalance = isNaN(balance) ? 0 : Number(balance);
        
        console.log(`[DEBUG getUserBalance] Parsed balance for ${userId}: ${numBalance}`);
        
        // Update cache
        balanceCache.set(userIdStr, numBalance);
        
        return numBalance;
        
    } catch (error) {
        console.error(`[ERROR getUserBalance] Error for user ${userId}:`, error);
        return 0;
    }
}

function validateAmount(amount) {
    const numAmount = Number(amount);
    if (isNaN(numAmount) || !isFinite(numAmount)) {
        return { valid: false, error: 'Jumlah tidak valid' };
    }
    if (numAmount <= 0) {
        return { valid: false, error: 'Jumlah harus lebih dari 0' };
    }
    return { valid: true, amount: numAmount };
}

function validateUserId(userId) {
    const userIdStr = String(userId);
    if (!userIdStr || userIdStr.length < 5) {
        return { valid: false, error: 'User ID tidak valid' };
    }
    if (!/^\d+$/.test(userIdStr)) {
        return { valid: false, error: 'User ID harus angka' };
    }
    return { valid: true, userId: userIdStr };
}

function setUserBalance(userId, amount) {
    const userIdStr = String(userId);
    const numAmount = Number(amount);
    if (isNaN(numAmount)) return false;
    
    const balances = loadBalances();
    balances[userIdStr] = numAmount;
    
    balanceCache.set(userIdStr, numAmount);
    
    return saveBalances(balances);
}

function addUserBalance(userId, amount) {
    try {
        const validation = validateAmount(amount);
        if (!validation.valid) return false;
        
        const numAmount = validation.amount;
        const userIdStr = String(userId);
        
        const balances = loadBalances();
        const currentBalance = parseInt(balances[userIdStr]) || 0;
        const numCurrent = isNaN(currentBalance) ? 0 : Number(currentBalance);
        
        const newBalance = numCurrent + numAmount;
        
        balances[userIdStr] = newBalance;
        
        balanceCache.set(userIdStr, newBalance);
        
        return saveBalances(balances);
    } catch (error) {
        return false;
    }
}

function deductUserBalance(userId, amount) {
    try {
        const validation = validateAmount(amount);
        if (!validation.valid) return false;
        
        const numAmount = validation.amount;
        const userIdStr = String(userId);
        
        const balances = loadBalances();
        const currentBalance = parseInt(balances[userIdStr]) || 0;
        const numCurrent = isNaN(currentBalance) ? 0 : Number(currentBalance);
        
        if (numCurrent < numAmount) {
            return false;
        }

        const newBalance = numCurrent - numAmount;
        
        balances[userIdStr] = newBalance;

        balanceCache.set(userIdStr, newBalance);
        
        return saveBalances(balances);
    } catch (error) {
        return false;
    }
}

setInterval(() => {
    const now = Date.now();
    for (const [key, timestamp] of depositProcessing.entries()) {
        if (now - timestamp > 5 * 60 * 1000) {
            depositProcessing.delete(key);
        }
    }
}, 60 * 1000);

function saveJSON(file, data) {
  try {
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
    return true;
  } catch (error) {
    return false;
  }
}

function isOrderProcessing(orderId) {
  return orderProcessing.has(orderId);
}

function setOrderProcessing(orderId, processing = true) {
  if (processing) {
    orderProcessing.set(orderId, Date.now());
  } else {
    orderProcessing.delete(orderId);
  }
}

function loadJSON(file) {
  try {
    if (!fs.existsSync(file)) {
      if (file === datafile) return { users: [], settings: { maintenance: false } };
      return {};
    }
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (e) {
    return file === datafile ? { users: [], settings: { maintenance: false } } : {};
  }
}

function loadData() {
  return loadJSON(datafile);
}

function saveData(data) {
  return saveJSON(datafile, data);
}

function saveUser(userId) {
  const data = loadData();
  const userIdStr = String(userId);
  
  if (!data.users) data.users = [];
  
  const userExists = data.users.some(id => id === userIdStr);
  
  if (!userExists) {
    data.users.push(userIdStr);
    saveData(data);
    
    return {
      success: true,
      isNewUser: true
    };
  }
  
  return {
    success: true,
    isNewUser: false
  };
}

function loadTransactions() {
  const data = loadJSON(transactionsFile);
  return {
    nokos_orders: data.nokos_orders || [],
    rumahotp_deposits: data.rumahotp_deposits || [],
    cashify_deposits: data.cashify_deposits || [],
    otpnum_deposits: data.otpnum_deposits || [] // Add OTPNUM deposits
  };
}

function addTransaction(type, data) {
  const transactions = loadTransactions();
  transactions[type] = transactions[type] || [];
 
  if (type === 'nokos_orders') {
    const now = Date.now();
    const fifteenMinutes = 15 * 60 * 1000;
    
    transactions[type] = transactions[type].filter(order => {
      const orderTime = new Date(order.timestamp).getTime();
      
      if ((order.status === 'pending' || order.status === 'active') && 
          (now - orderTime > fifteenMinutes)) {
        return false;
      }
      return true;
    });
  }
  
  const transaction = {
    id: data.id || Math.random().toString(36).substr(2, 9),
    userId: data.userId,
    data: data,
    timestamp: new Date().toISOString(),
    status: data.status || 'pending'
  };
  
  if (type === 'nokos_orders') {
    transaction.data.originalBalance = getUserBalance(data.userId) + (data.price || 0);
  }
  
  transactions[type].push(transaction);
  saveTransactions(transactions);
  return transaction.id;
}

function saveTransactions(transactions) {
  return saveJSON(transactionsFile, transactions);
}

function updateTransactionStatus(type, transactionId, status) {
  const transactions = loadTransactions();
  if (transactions[type]) {
    const transaction = transactions[type].find(t => t.id === transactionId);
    if (transaction) {
      transaction.status = status;
      transaction.data.status = status;
      saveTransactions(transactions);
      return true;
    }
  }
  return false;
}

function addCSAdminToConfig(userId) {
  try {
    const configPath = path.join(__dirname, 'config.js');
    
    // Baca config file
    let configContent = fs.readFileSync(configPath, 'utf8');
    
    // Cek apakah cs_admins sudah ada
    if (configContent.includes('cs_admins:')) {
      // Update existing cs_admins
      const regex = /cs_admins:\s*\[([^\]]+)\]/;
      const match = configContent.match(regex);
      
      if (match) {
        const currentAdmins = match[1].split(',').map(id => id.trim().replace(/'/g, '').replace(/"/g, '')).filter(id => id);
        
        // Cek apakah user sudah ada
        if (currentAdmins.includes(userId.toString())) {
          return false; // Sudah ada
        }
        
        // Tambahkan user baru
        currentAdmins.push(userId.toString());
        const newAdminsStr = currentAdmins.map(id => `'${id}'`).join(', ');
        
        configContent = configContent.replace(regex, `cs_admins: [${newAdminsStr}]`);
      }
    } else {
      // Tambahkan cs_admins baru setelah owner_ids
      const regex = /owner_ids:\s*\[([^\]]+)\]/;
      configContent = configContent.replace(
        regex,
        `owner_ids: [$1],\n  cs_admins: ['${userId}']`
      );
    }
    
    // Tulis kembali config file
    fs.writeFileSync(configPath, configContent);
    
    // Reload config
    delete require.cache[require.resolve('./config')];
    const newConfig = require('./config');
    
    // Update global config
    Object.assign(config, newConfig);
    
    return true;
    
  } catch (error) {
    console.error('Error adding CS admin:', error);
    return false;
  }
}

function removeCSAdminFromConfig(userId) {
  try {
    const configPath = path.join(__dirname, 'config.js');
    
    // Baca config file
    let configContent = fs.readFileSync(configPath, 'utf8');
    
    // Cek apakah cs_admins ada
    if (!configContent.includes('cs_admins:')) {
      return false; // Tidak ada cs_admins
    }
    
    // Update cs_admins
    const regex = /cs_admins:\s*\[([^\]]+)\]/;
    const match = configContent.match(regex);
    
    if (match) {
      const currentAdmins = match[1].split(',').map(id => id.trim().replace(/'/g, '').replace(/"/g, '')).filter(id => id);
      
      // Cek apakah user ada
      if (!currentAdmins.includes(userId.toString())) {
        return false; // Tidak ada
      }
      
      // Hapus user
      const filteredAdmins = currentAdmins.filter(id => id !== userId.toString());
      
      if (filteredAdmins.length === 0) {
        // Hapus cs_admins jika kosong
        configContent = configContent.replace(/,\s*cs_admins:\s*\[[^\]]+\]/, '');
      } else {
        const newAdminsStr = filteredAdmins.map(id => `'${id}'`).join(', ');
        configContent = configContent.replace(regex, `cs_admins: [${newAdminsStr}]`);
      }
      
      // Tulis kembali config file
      fs.writeFileSync(configPath, configContent);
      
      // Reload config
      delete require.cache[require.resolve('./config')];
      const newConfig = require('./config');
      
      // Update global config
      Object.assign(config, newConfig);
      
      return true;
    }
    
    return false;
    
  } catch (error) {
    console.error('Error removing CS admin:', error);
    return false;
  }
}

function cleanExpiredDeposits() {
    try {
        const transactions = loadTransactions();
        const now = Date.now();
        const twentyMinutes = 20 * 60 * 1000;
        
        ['cashify_deposits', 'rumahotp_deposits', 'otpnum_deposits'].forEach(type => {
            if (transactions[type]) {
                transactions[type] = transactions[type].filter(deposit => {
                    const depositTime = new Date(deposit.timestamp).getTime();
                    
                    return (deposit.status === 'success' || deposit.status === 'paid') || 
                           (now - depositTime < twentyMinutes && (deposit.status === 'pending' || deposit.status === 'UNPAID'));
                });
            }
        });
        
        saveTransactions(transactions);
    } catch (error) {
        console.error('Error cleaning deposits:', error);
    }
}

setInterval(cleanExpiredDeposits, 5 * 60 * 1000);

setInterval(() => {
  balanceCache.clear();
  transactionCache.clear();
  voucherCache.clear();
}, 10 * 60 * 1000);

function formatCurrency(amount) {
  const numAmount = Number(amount);
  if (isNaN(numAmount) || !isFinite(numAmount)) {
    return 'Rp0';
  }
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0
  }).format(numAmount);
}

function getPaymentMethod() {
  const settings = loadSettings();
  return settings.payment_method || 'rumahotp';
}

function setPaymentMethod(method) {
  const settings = loadSettings();
  settings.payment_method = method;
  saveSettings(settings);
  return method;
}

// ========================= VOUCHER FUNCTIONS =========================

function loadVouchers() {
  try {
    if (!fs.existsSync(vouchersFile)) {
      const defaultVouchers = {
        vouchers: [],
        used_vouchers: [],
        voucher_stats: {
          total_created: 0,
          total_used: 0,
          total_discount: 0
        }
      };
      saveVouchers(defaultVouchers);
      return defaultVouchers;
    }
    
    const data = fs.readFileSync(vouchersFile, 'utf8');
    const parsed = JSON.parse(data);
    
    // Ensure all required fields exist
    return {
      vouchers: parsed.vouchers || [],
      used_vouchers: parsed.used_vouchers || [],
      voucher_stats: {
        total_created: parsed.voucher_stats?.total_created || 0,
        total_used: parsed.voucher_stats?.total_used || 0,
        total_discount: parsed.voucher_stats?.total_discount || 0
      }
    };
  } catch (e) {
    console.error('Error loading vouchers:', e);
    // Return default structure if there's any error
    return {
      vouchers: [],
      used_vouchers: [],
      voucher_stats: {
        total_created: 0,
        total_used: 0,
        total_discount: 0
      }
    };
  }
}

function saveVouchers(vouchers) {
  try {
    // Ensure the structure is complete
    const completeVouchers = {
      vouchers: vouchers.vouchers || [],
      used_vouchers: vouchers.used_vouchers || [],
      voucher_stats: {
        total_created: vouchers.voucher_stats?.total_created || 0,
        total_used: vouchers.voucher_stats?.total_used || 0,
        total_discount: vouchers.voucher_stats?.total_discount || 0
      }
    };
    
    fs.writeFileSync(vouchersFile, JSON.stringify(completeVouchers, null, 2));
    voucherCache.clear();
    return true;
  } catch (error) {
    console.error('Error saving vouchers:', error);
    return false;
  }
}

function getActiveVouchers() {
  const vouchers = loadVouchers();
  const now = Date.now();
  
  return vouchers.vouchers.filter(voucher => {
    if (voucher.expiry && new Date(voucher.expiry).getTime() < now) {
      return false;
    }
    
    if (voucher.usage_limit && voucher.used_count >= voucher.usage_limit) {
      return false;
    }
    
    if (voucher.status !== 'active') {
      return false;
    }
    
    return true;
  });
}

function generateVoucherCode() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let code = '';
  for (let i = 0; i < 8; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

function createVoucher(voucherData) {
  try {
    const vouchers = loadVouchers();
    
    const voucher = {
      id: `VOUCH${Date.now().toString().substr(-8)}${Math.random().toString(36).substr(2, 3).toUpperCase()}`,
      code: voucherData.code || generateVoucherCode(),
      type: voucherData.type || 'percentage',
      value: voucherData.value || 0,
      min_purchase: voucherData.min_purchase || 0,
      max_discount: voucherData.max_discount || null,
      usage_limit: voucherData.usage_limit || 1,
      used_count: 0,
      status: 'active',
      created_by: voucherData.created_by || 'system',
      created_at: new Date().toISOString(),
      expiry: voucherData.expiry || null,
      description: voucherData.description || '',
      services: voucherData.services || [],
      countries: voucherData.countries || []
    };
    
    vouchers.vouchers.push(voucher);
    vouchers.voucher_stats.total_created++;
    
    saveVouchers(vouchers);
    
    notifyVoucherCreated(voucher);
    
    return voucher;
  } catch (error) {
    console.error('Error creating voucher:', error);
    return null;
  }
}

function validateVoucher(code, userId, serviceId = null, countryId = null, amount = 0) {
  try {
    const vouchers = loadVouchers();
    
    const alreadyUsed = vouchers.used_vouchers.find(uv => 
      uv.voucher_code === code && uv.user_id === userId.toString()
    );
    
    if (alreadyUsed) {
      return {
        valid: false,
        error: 'Voucher sudah pernah digunakan'
      };
    }
    
    const voucher = vouchers.vouchers.find(v => 
      v.code === code && v.status === 'active'
    );
    
    if (!voucher) {
      return {
        valid: false,
        error: 'Voucher tidak valid atau sudah expired'
      };
    }
    
    if (voucher.expiry && new Date(voucher.expiry).getTime() < Date.now()) {
      return {
        valid: false,
        error: 'Voucher sudah expired'
      };
    }
    
    if (voucher.usage_limit && voucher.used_count >= voucher.usage_limit) {
      return {
        valid: false,
        error: 'Voucher sudah mencapai limit penggunaan'
      };
    }
    
    if (voucher.min_purchase > 0 && amount < voucher.min_purchase) {
      return {
        valid: false,
        error: `Minimum pembelian ${formatCurrency(voucher.min_purchase)}`
      };
    }
    
    if (voucher.services && voucher.services.length > 0 && serviceId) {
      if (!voucher.services.includes(serviceId)) {
        return {
          valid: false,
          error: 'Voucher tidak berlaku untuk layanan ini'
        };
      }
    }
    
    if (voucher.countries && voucher.countries.length > 0 && countryId) {
      if (!voucher.countries.includes(countryId)) {
        return {
          valid: false,
          error: 'Voucher tidak berlaku untuk negara ini'
        };
      }
    }
    
    let discount = 0;
    
    if (voucher.type === 'percentage') {
      discount = (amount * voucher.value) / 100;
      
      if (voucher.max_discount && discount > voucher.max_discount) {
        discount = voucher.max_discount;
      }
    } else if (voucher.type === 'fixed') {
      discount = voucher.value;
      
      if (discount > amount) {
        discount = amount;
      }
    }
    
    return {
      valid: true,
      voucher: voucher,
      discount: Math.round(discount),
      final_amount: amount - Math.round(discount)
    };
    
  } catch (error) {
    return {
      valid: false,
      error: 'Error validasi voucher'
    };
  }
}

function useVoucher(code, userId, orderId = null, amount = 0, discount = 0) {
  try {
    const vouchers = loadVouchers();
    
    const voucherIndex = vouchers.vouchers.findIndex(v => v.code === code);
    
    if (voucherIndex === -1) {
      return false;
    }
    
    vouchers.vouchers[voucherIndex].used_count++;
    
    vouchers.used_vouchers.push({
      voucher_code: code,
      user_id: userId.toString(),
      order_id: orderId,
      amount: amount,
      discount: discount,
      used_at: new Date().toISOString()
    });
    
    vouchers.voucher_stats.total_used++;
    vouchers.voucher_stats.total_discount += discount;
    
    if (vouchers.vouchers[voucherIndex].usage_limit && 
        vouchers.vouchers[voucherIndex].used_count >= vouchers.vouchers[voucherIndex].usage_limit) {
      vouchers.vouchers[voucherIndex].status = 'inactive';
    }
    
    saveVouchers(vouchers);
    
    notifyVoucherUsed(code, userId, amount, discount);
    
    return true;
    
  } catch (error) {
    console.error('Error using voucher:', error);
    return false;
  }
}

async function notifyVoucherCreated(voucher) {
  try {
    const dateStr = new Date(voucher.created_at).toLocaleString('id-ID');
    const expiryStr = voucher.expiry ? new Date(voucher.expiry).toLocaleString('id-ID') : 'Tidak ada';
    
    let message = `🎫 <b>VOUCHER BARU DIBUAT</b>\n\n`;
    message += `<b>Kode:</b> <code>${voucher.code}</code>\n`;
    message += `<b>Tipe:</b> ${voucher.type === 'percentage' ? 'Persentase' : 'Fixed Amount'}\n`;
    message += `<b>Nilai:</b> ${voucher.type === 'percentage' ? `${voucher.value}%` : formatCurrency(voucher.value)}\n`;
    
    if (voucher.max_discount) {
      message += `<b>Maks Discount:</b> ${formatCurrency(voucher.max_discount)}\n`;
    }
    
    message += `<b>Min Pembelian:</b> ${formatCurrency(voucher.min_purchase)}\n`;
    message += `<b>Limit Penggunaan:</b> ${voucher.usage_limit}x\n`;
    message += `<b>Expired:</b> ${expiryStr}\n`;
    message += `<b>Dibuat oleh:</b> ${voucher.created_by}\n`;
    message += `<b>Tanggal:</b> ${dateStr}\n\n`;
    
    if (voucher.description) {
      message += `<b>Deskripsi:</b> ${voucher.description}\n`;
    }
    
    await bot.sendMessage(channel, message, {
      parse_mode: 'HTML',
      disable_web_page_preview: true
    });
    
  } catch (error) {
    console.error('Error notifying voucher creation:', error);
  }
}

async function notifyVoucherUsed(voucherCode, userId, amount, discount) {
  try {
    const dateStr = new Date().toLocaleString('id-ID');
    
    let message = `🎫 <b>VOUCHER DIGUNAKAN</b>\n\n`;
    message += `<b>Kode:</b> <code>${voucherCode}</code>\n`;
    message += `<b>User ID:</b> ${userId}\n`;
    message += `<b>Amount:</b> ${formatCurrency(amount)}\n`;
    message += `<b>Discount:</b> ${formatCurrency(discount)}\n`;
    message += `<b>Total Bayar:</b> ${formatCurrency(amount - discount)}\n`;
    message += `<b>Tanggal:</b> ${dateStr}\n`;
    
    await bot.sendMessage(channel_otp, message, {
      parse_mode: 'HTML',
      disable_web_page_preview: true
    });
    
  } catch (error) {
    console.error('Error notifying voucher usage:', error);
  }
}

// ========================= BACKUP FUNCTIONS =========================

async function showBackupList(chatId, userId, messageId = null, callbackQueryId = null) {
    try {
        if (!owner_ids.includes(userId.toString())) {
            if (callbackQueryId) {
                await bot.answerCallbackQuery(callbackQueryId, {
                    text: '⛔ Akses Ditolak\nHanya owner yang bisa mengakses menu ini',
                    show_alert: true
                });
            }
            return;
        }

        const backupDir = path.join(__dirname, 'backup');
        
        if (!fs.existsSync(backupDir)) {
            const message = `<b>📁 RESTORE DATA</b>\n\nTidak ada backup ditemukan.\n\nDirectory backup: <code>${backupDir}</code>\n\nSilakan buat backup terlebih dahulu.`;
            
            if (messageId && callbackQueryId) {
                await editMessage(chatId, messageId, callbackQueryId, message, {
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Kembali', callback_data: 'owner_menu' }],
                            [{ text: 'Refresh', callback_data: 'restore_menu' }]
                        ]
                    }
                });
            } else {
                await sendNewMessage(chatId, message, {
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Kembali', callback_data: 'owner_menu' }],
                            [{ text: 'Refresh', callback_data: 'restore_menu' }]
                        ]
                    }
                });
            }
            return;
        }

        let backupFiles = fs.readdirSync(backupDir)
            .filter(f => f.startsWith('backup_') && f.endsWith('.zip'))
            .map(f => {
                const filePath = path.join(backupDir, f);
                const stats = fs.statSync(filePath);
                return {
                    name: f,
                    path: filePath,
                    size: (stats.size / 1024).toFixed(2),
                    date: stats.mtime,
                    timestamp: stats.mtime.getTime()
                };
            })
            .sort((a, b) => b.timestamp - a.timestamp)
            .slice(0, 20);

        if (backupFiles.length === 0) {
            const message = `<b>📁 RESTORE DATA</b>\n\nTidak ada backup ditemukan.\n\nDirectory backup: <code>${backupDir}</code>\n\nSilakan buat backup terlebih dahulu.`;
            
            if (messageId && callbackQueryId) {
                await editMessage(chatId, messageId, callbackQueryId, message, {
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Kembali', callback_data: 'owner_menu' }],
                            [{ text: 'Refresh', callback_data: 'restore_menu' }]
                        ]
                    }
                });
            } else {
                await sendNewMessage(chatId, message, {
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Kembali', callback_data: 'owner_menu' }],
                            [{ text: 'Refresh', callback_data: 'restore_menu' }]
                        ]
                    }
                });
            }
            return;
        }

        let message = `<b>📁 DAFTAR BACKUP</b>\n\n`;
        message += `<b>Total backup:</b> ${backupFiles.length}\n`;
        message += `<b>Directory:</b> <code>${backupDir}</code>\n\n`;
        message += `<b>Pilih backup untuk direstore:</b>\n\n`;

        const keyboard = [];
        const buttonsPerRow = 1;

        for (let i = 0; i < backupFiles.length; i += buttonsPerRow) {
            const rowFiles = backupFiles.slice(i, i + buttonsPerRow);
            
            for (const file of rowFiles) {
                const dateStr = file.date.toLocaleString('id-ID');
                const fileName = file.name.length > 30 ? 
                    file.name.substring(0, 27) + '...' : 
                    file.name;
                
                const buttonText = `${i + 1}. ${fileName} (${file.size} KB)`;
                const callbackData = `restore_view_${file.name}`;
                
                keyboard.push([{ 
                    text: buttonText, 
                    callback_data: callbackData 
                }]);
            }
        }

        const navButtons = [];
        if (backupFiles.length > 10) {
            navButtons.push({ text: '⬆️ Atas', callback_data: 'restore_page_top' });
            navButtons.push({ text: '⬇️ Bawah', callback_data: 'restore_page_bottom' });
            keyboard.push(navButtons);
        }

        keyboard.push([
            { text: '📥 Backup Sekarang', callback_data: 'create_backup_now' },
            { text: '🔄 Refresh', callback_data: 'restore_menu' }
        ]);
        
        keyboard.push([
            { text: 'Kembali ke Owner Menu', callback_data: 'owner_menu' },
            { text: 'Menu Utama', callback_data: 'main_menu' }
        ]);

        if (messageId && callbackQueryId) {
            await editMessage(chatId, messageId, callbackQueryId, message, {
                parse_mode: 'HTML',
                reply_markup: { inline_keyboard: keyboard },
                disable_web_page_preview: true
            });
        } else {
            await sendNewMessage(chatId, message, {
                parse_mode: 'HTML',
                reply_markup: { inline_keyboard: keyboard },
                disable_web_page_preview: true
            });
        }

    } catch (error) {
        const errorMessage = `<b>❌ ERROR</b>\n\nGagal memuat daftar backup.\n\nError: <code>${error.message}</code>`;
        
        if (messageId && callbackQueryId) {
            await editMessage(chatId, messageId, callbackQueryId, errorMessage, {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: 'Coba Lagi', callback_data: 'restore_menu' }],
                        [{ text: 'Kembali', callback_data: 'owner_menu' }]
                    ]
                }
            });
        } else {
            await sendNewMessage(chatId, errorMessage, {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: 'Coba Lagi', callback_data: 'restore_menu' }],
                        [{ text: 'Kembali', callback_data: 'owner_menu' }]
                    ]
                }
            });
        }
    }
}

async function showBackupDetail(chatId, userId, backupFileName, messageId, callbackQueryId) {
    try {
        if (!owner_ids.includes(userId.toString())) {
            await bot.answerCallbackQuery(callbackQueryId, {
                text: '⛔ Akses Ditolak\nHanya owner yang bisa mengakses menu ini',
                show_alert: true
            });
            return;
        }

        const backupDir = path.join(__dirname, 'backup');
        const backupPath = path.join(backupDir, backupFileName);
        
        if (!fs.existsSync(backupPath)) {
            await editMessage(chatId, messageId, callbackQueryId,
                `<b>❌ BACKUP TIDAK DITEMUKAN</b>\n\nFile backup tidak ditemukan:\n<code>${backupFileName}</code>\n\nFile mungkin sudah dihapus atau dipindahkan.`,
                {
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Kembali ke Daftar', callback_data: 'restore_menu' }]
                        ]
                    }
                }
            );
            return;
        }

        const stats = fs.statSync(backupPath);
        const fileSizeKB = (stats.size / 1024).toFixed(2);
        const fileSizeMB = (stats.size / (1024 * 1024)).toFixed(2);
        const modifiedDate = stats.mtime.toLocaleString('id-ID');
        const createdDate = stats.birthtime ? stats.birthtime.toLocaleString('id-ID') : 'Tidak diketahui';

        let message = `<b>📁 DETAIL BACKUP</b>\n\n`;
        message += `<b>Nama File:</b> <code>${backupFileName}</code>\n`;
        message += `<b>Ukuran:</b> ${fileSizeKB} KB (${fileSizeMB} MB)\n`;
        message += `<b>Tanggal Modifikasi:</b> ${modifiedDate}\n`;
        message += `<b>Tanggal Pembuatan:</b> ${createdDate}\n`;
        message += `<b>Path:</b> <code>${backupPath}</code>\n\n`;

        try {
            const AdmZip = require('adm-zip');
            const zip = new AdmZip(backupPath);
            const zipEntries = zip.getEntries();
            
            let databaseFiles = zipEntries.filter(entry => 
                entry.name.endsWith('.json')
            ).map(entry => entry.name);
            
            if (databaseFiles.length > 0) {
                message += `<b>File dalam backup:</b>\n`;
                databaseFiles.forEach(file => {
                    message += `• ${file}\n`;
                });
                message += `\n`;
            }
        } catch (zipError) {
            message += `<i>Tidak bisa membaca isi file zip</i>\n\n`;
        }

        message += `<b>⚠️ PERINGATAN:</b>\n`;
        message += `• Restore akan menimpa data saat ini\n`;
        message += `• Pastikan sudah backup data terbaru\n`;
        message += `• Proses tidak bisa dibatalkan\n\n`;
        message += `Pilih tindakan:`;

        const keyboard = [
            [
                { text: '🔄 Restore Data Ini', callback_data: `restore_confirm_${backupFileName}` },
                { text: '📥 Download', callback_data: `restore_download_${backupFileName}` }
            ],
            [
                { text: '🗑️ Hapus Backup', callback_data: `restore_delete_${backupFileName}` }
            ],
            [
                { text: '⬅️ Kembali ke Daftar', callback_data: 'restore_menu' },
                { text: '📋 Owner Menu', callback_data: 'owner_menu' }
            ]
        ];

        await editMessage(chatId, messageId, callbackQueryId, message, {
            parse_mode: 'HTML',
            reply_markup: { inline_keyboard: keyboard },
            disable_web_page_preview: true
        });

    } catch (error) {
        await editMessage(chatId, messageId, callbackQueryId,
            `<b>❌ ERROR</b>\n\nGagal memuat detail backup.\n\nError: <code>${error.message}</code>`,
            {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: 'Kembali ke Daftar', callback_data: 'restore_menu' }]
                    ]
                }
            }
        );
    }
}

async function confirmRestore(chatId, userId, backupFileName, messageId, callbackQueryId) {
    try {
        if (!owner_ids.includes(userId.toString())) {
            await bot.answerCallbackQuery(callbackQueryId, {
                text: '⛔ Akses Ditolak\nHanya owner yang bisa mengakses menu ini',
                show_alert: true
            });
            return;
        }

        const backupDir = path.join(__dirname, 'backup');
        const backupPath = path.join(backupDir, backupFileName);
        
        if (!fs.existsSync(backupPath)) {
            await editMessage(chatId, messageId, callbackQueryId,
                `<b>❌ BACKUP TIDAK DITEMUKAN</b>\n\nFile backup tidak ditemukan:\n<code>${backupFileName}</code>`,
                {
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Kembali ke Daftar', callback_data: 'restore_menu' }]
                        ]
                    }
                }
            );
            return;
        }

        let message = `<b>⚠️ KONFIRMASI RESTORE</b>\n\n`;
        message += `<b>File:</b> <code>${backupFileName}</code>\n\n`;
        message += `<b>PERINGATAN PENTING:</b>\n`;
        message += `• Semua data saat ini akan DITIMPA\n`;
        message += `• Proses ini TIDAK BISA DIBATALKAN\n`;
        message += `• Bot mungkin perlu restart\n`;
        message += `• Cache akan dihapus\n\n`;
        message += `<b>File yang akan direstore:</b>\n`;
        message += `• users.json\n`;
        message += `• balances.json\n`;
        message += `• transactions.json\n`;
        message += `• settings.json\n`;
        message += `• vouchers.json\n\n`;
        message += `Ketik <code>/restore ${backupFileName}</code> untuk melanjutkan`;

        const keyboard = [
            [
                { text: '✅ Ya, Restore Sekarang', callback_data: `restore_execute_${backupFileName}` },
                { text: '❌ Batalkan', callback_data: `restore_view_${backupFileName}` }
            ]
        ];

        await editMessage(chatId, messageId, callbackQueryId, message, {
            parse_mode: 'HTML',
            reply_markup: { inline_keyboard: keyboard },
            disable_web_page_preview: true
        });

    } catch (error) {
        await editMessage(chatId, messageId, callbackQueryId,
            `<b>❌ ERROR</b>\n\nGagal memproses konfirmasi.\n\nError: <code>${error.message}</code>`,
            {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: 'Kembali ke Daftar', callback_data: 'restore_menu' }]
                    ]
                }
            }
        );
    }
}

async function executeRestore(chatId, userId, backupFileName) {
    try {
        if (!owner_ids.includes(userId.toString())) {
            await bot.sendMessage(chatId,
                "⛔ Akses Ditolak\n\nHanya owner yang bisa melakukan restore data.",
                { parse_mode: 'HTML' }
            );
            return;
        }

        const backupDir = path.join(__dirname, 'backup');
        const backupPath = path.join(backupDir, backupFileName);
        
        if (!fs.existsSync(backupPath)) {
            await bot.sendMessage(chatId,
                `<b>❌ BACKUP TIDAK DITEMUKAN</b>\n\nFile backup tidak ditemukan:\n<code>${backupFileName}</code>`,
                { parse_mode: 'HTML' }
            );
            return;
        }

        const processingMsg = await bot.sendMessage(chatId,
            `<b>🔄 MULAI RESTORE DATA</b>\n\nMemproses file backup...\n\nMohon tunggu, proses mungkin memakan waktu beberapa saat.`,
            { parse_mode: 'HTML' }
        );

        const timestamp = Date.now();
        const currentBackupDir = path.join(__dirname, 'backup', 'pre_restore');
        if (!fs.existsSync(currentBackupDir)) {
            fs.mkdirSync(currentBackupDir, { recursive: true });
        }

        const currentBackupFiles = [
            { name: 'users.json', file: datafile },
            { name: 'balances.json', file: balanceFile },
            { name: 'transactions.json', file: transactionsFile },
            { name: 'settings.json', file: settingsFile },
            { name: 'vouchers.json', file: vouchersFile }
        ];

        for (const fileInfo of currentBackupFiles) {
            if (fs.existsSync(fileInfo.file)) {
                const backupDest = path.join(currentBackupDir, `pre_restore_${timestamp}_${fileInfo.name}`);
                fs.copyFileSync(fileInfo.file, backupDest);
            }
        }

        const AdmZip = require('adm-zip');
        const zip = new AdmZip(backupPath);
        const tempDir = path.join(__dirname, 'temp_restore', timestamp.toString());
        
        if (fs.existsSync(tempDir)) {
            fs.rmSync(tempDir, { recursive: true, force: true });
        }
        fs.mkdirSync(tempDir, { recursive: true });
        
        zip.extractAllTo(tempDir, true);

        let extractedFiles = fs.readdirSync(tempDir);
        const requiredFiles = ['users.json', 'balances.json', 'transactions.json', 'settings.json', 'vouchers.json'];
        let missingFiles = requiredFiles.filter(file => !extractedFiles.includes(file));

        if (missingFiles.length > 0) {
            fs.rmSync(tempDir, { recursive: true, force: true });
            
            await bot.editMessageText(
                `<b>❌ RESTORE GAGAL</b>\n\nFile backup tidak lengkap.\n\nFile yang hilang:\n${missingFiles.map(f => `• ${f}`).join('\n')}\n\nData saat ini TIDAK berubah.`,
                {
                    chat_id: chatId,
                    message_id: processingMsg.message_id,
                    parse_mode: 'HTML'
                }
            );
            return;
        }

        let restoredFiles = 0;
        let restoreResults = [];

        for (const fileName of requiredFiles) {
            try {
                const sourcePath = path.join(tempDir, fileName);
                let targetPath;
                
                switch (fileName) {
                    case 'users.json':
                        targetPath = datafile;
                        break;
                    case 'balances.json':
                        targetPath = balanceFile;
                        break;
                    case 'transactions.json':
                        targetPath = transactionsFile;
                        break;
                    case 'settings.json':
                        targetPath = settingsFile;
                        break;
                    case 'vouchers.json':
                        targetPath = vouchersFile;
                        break;
                    default:
                        continue;
                }

                const fileContent = fs.readFileSync(sourcePath, 'utf8');
                try {
                    JSON.parse(fileContent);
                    
                    if (fs.existsSync(targetPath)) {
                        const backupOldPath = targetPath + `.backup_${timestamp}`;
                        fs.copyFileSync(targetPath, backupOldPath);
                    }
                    
                    fs.copyFileSync(sourcePath, targetPath);
                    restoredFiles++;
                    restoreResults.push(`✅ ${fileName}`);
                    
                } catch (jsonError) {
                    restoreResults.push(`❌ ${fileName} (Invalid JSON)`);
                }

            } catch (fileError) {
                restoreResults.push(`❌ ${fileName} (Error: ${fileError.message})`);
            }
        }

        balanceCache.clear();
        userSelections.clear();
        userDepositMessages.clear();
        userPendingCommands.clear();
        orderProcessing.clear();
        depositProcessing.clear();
        sentNotifications.clear();
        userFirstTimeNotifications.clear();
        servicesCache.data = null;
        servicesCache.timestamp = 0;
        voucherCache.clear();

        fs.rmSync(tempDir, { recursive: true, force: true });

        let successMessage = `<b>✅ RESTORE BERHASIL</b>\n\n`;
        successMessage += `<b>File backup:</b> <code>${backupFileName}</code>\n`;
        successMessage += `<b>Waktu restore:</b> ${new Date().toLocaleString('id-ID')}\n`;
        successMessage += `<b>File yang direstore:</b> ${restoredFiles}/5\n\n`;
        successMessage += `<b>Detail:</b>\n${restoreResults.join('\n')}\n\n`;
        successMessage += `<b>Efek:</b>\n`;
        successMessage += `• Cache telah dihapus\n`;
        successMessage += `• Data telah diperbarui\n`;
        successMessage += `• Bot tetap berjalan\n\n`;
        successMessage += `<i>Data sebelum restore disimpan di:</i>\n<code>${currentBackupDir}</code>`;

        await bot.editMessageText(successMessage, {
            chat_id: chatId,
            message_id: processingMsg.message_id,
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [
                    [{ text: '🔄 Reload Data', callback_data: 'restore_reload' }],
                    [
                        { text: '📋 Owner Menu', callback_data: 'owner_menu' },
                        { text: '🏠 Menu Utama', callback_data: 'main_menu' }
                    ]
                ]
            }
        });

        for (const ownerId of owner_ids) {
            if (ownerId.toString() !== userId.toString()) {
                try {
                    await bot.sendMessage(ownerId,
                        `<b>⚠️ RESTORE DATA DILAKUKAN</b>\n\n` +
                        `<b>Oleh:</b> ${userId}\n` +
                        `<b>File:</b> ${backupFileName}\n` +
                        `<b>Waktu:</b> ${new Date().toLocaleString('id-ID')}\n\n` +
                        `<i>Data bot telah direstore</i>`,
                        { parse_mode: 'HTML' }
                    );
                } catch (error) {}
            }
        }

    } catch (error) {
        let errorMsg = error.message || 'Unknown error';
        await bot.sendMessage(chatId,
            `<b>❌ RESTORE GAGAL</b>\n\nTerjadi kesalahan saat restore:\n\n<code>${errorMsg}</code>\n\nData saat ini TIDAK berubah.`,
            { parse_mode: 'HTML' }
        );
    }
}

async function downloadBackup(chatId, userId, backupFileName, messageId, callbackQueryId) {
    try {
        if (!owner_ids.includes(userId.toString())) {
            await bot.answerCallbackQuery(callbackQueryId, {
                text: '⛔ Akses Ditolak\nHanya owner yang bisa mengakses menu ini',
                show_alert: true
            });
            return;
        }

        const backupDir = path.join(__dirname, 'backup');
        const backupPath = path.join(backupDir, backupFileName);
        
        if (!fs.existsSync(backupPath)) {
            await bot.answerCallbackQuery(callbackQueryId, {
                text: 'File backup tidak ditemukan',
                show_alert: true
            });
            return;
        }

        const stats = fs.statSync(backupPath);
        const fileSizeMB = stats.size / (1024 * 1024);

        if (fileSizeMB > 50) {
            await bot.answerCallbackQuery(callbackQueryId, {
                text: `File terlalu besar (${fileSizeMB.toFixed(2)}MB). Maksimal 50MB.`,
                show_alert: true
            });
            return;
        }

        await bot.sendDocument(chatId, backupPath, {
            caption: `<b>📥 BACKUP FILE</b>\n\n` +
                    `<b>Nama:</b> ${backupFileName}\n` +
                    `<b>Ukuran:</b> ${(stats.size / 1024).toFixed(2)} KB\n` +
                    `<b>Tanggal:</b> ${stats.mtime.toLocaleString('id-ID')}\n\n` +
                    `<i>Simpan file ini dengan aman</i>`,
            parse_mode: 'HTML'
        });

        await bot.answerCallbackQuery(callbackQueryId, {
            text: 'File sedang dikirim...',
            show_alert: false
        });

    } catch (error) {
        let errorMsg = error.message || 'Unknown error';
        await bot.answerCallbackQuery(callbackQueryId, {
            text: `Gagal mengirim file: ${errorMsg}`,
            show_alert: true
        });
    }
}

async function deleteBackup(chatId, userId, backupFileName, messageId, callbackQueryId) {
    try {
        if (!owner_ids.includes(userId.toString())) {
            await bot.answerCallbackQuery(callbackQueryId, {
                text: '⛔ Akses Ditolak\nHanya owner yang bisa mengakses menu ini',
                show_alert: true
            });
            return;
        }

        const backupDir = path.join(__dirname, 'backup');
        const backupPath = path.join(backupDir, backupFileName);
        
        if (!fs.existsSync(backupPath)) {
            await editMessage(chatId, messageId, callbackQueryId,
                `<b>❌ FILE TIDAK DITEMUKAN</b>\n\nFile backup tidak ditemukan:\n<code>${backupFileName}</code>`,
                {
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Kembali ke Daftar', callback_data: 'restore_menu' }]
                        ]
                    }
                }
            );
            return;
        }

        const stats = fs.statSync(backupPath);
        const fileSize = (stats.size / 1024).toFixed(2);
        const modifiedDate = stats.mtime.toLocaleString('id-ID');

        let message = `<b>🗑️ KONFIRMASI HAPUS</b>\n\n`;
        message += `<b>File:</b> <code>${backupFileName}</code>\n`;
        message += `<b>Ukuran:</b> ${fileSize} KB\n`;
        message += `<b>Tanggal:</b> ${modifiedDate}\n\n`;
        message += `<b>PERINGATAN:</b>\n`;
        message += `• File akan dihapus PERMANEN\n`;
        message += `• Tidak bisa dikembalikan\n`;
        message += `• Pastikan sudah didownload jika penting\n\n`;
        message += `Ketik <code>/deletebackup ${backupFileName}</code> untuk menghapus`;

        const keyboard = [
            [
                { text: '✅ Ya, Hapus Sekarang', callback_data: `delete_execute_${backupFileName}` },
                { text: '❌ Batalkan', callback_data: `restore_view_${backupFileName}` }
            ]
        ];

        await editMessage(chatId, messageId, callbackQueryId, message, {
            parse_mode: 'HTML',
            reply_markup: { inline_keyboard: keyboard },
            disable_web_page_preview: true
        });

    } catch (error) {
        let errorMsg = error.message || 'Unknown error';
        await editMessage(chatId, messageId, callbackQueryId,
            `<b>❌ ERROR</b>\n\nGagal memproses penghapusan.\n\nError: <code>${errorMsg}</code>`,
            {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: 'Kembali ke Daftar', callback_data: 'restore_menu' }]
                    ]
                }
            }
        );
    }
}

async function showActiveCSThreads(chatId, userId, messageId, callbackQueryId) {
  try {
    if (!owner_ids.includes(user.id.toString()) && !config.cs_admins?.includes(user.id.toString())) {
      await bot.answerCallbackQuery(callbackQueryId, {
        text: '⛔ Akses Ditolak\nHanya admin atau CS yang bisa mengakses',
        show_alert: true
      });
      return;
    }
    
    const activeThreads = [];
    
    if (global.csChatSessions) {
      for (const [threadId, session] of global.csChatSessions) {
        if (session.status === 'active' || session.status === 'pending') {
          activeThreads.push({
            threadId: threadId,
            ...session
          });
        }
      }
    }
    
    let message = `<b>💬 ACTIVE CS THREADS</b>\n\n`;
    
    if (activeThreads.length === 0) {
      message += `<i>Tidak ada thread aktif</i>\n`;
    } else {
      message += `<b>Total Active Threads:</b> ${activeThreads.length}\n\n`;
      
      activeThreads.forEach((thread, index) => {
        const lastMessage = thread.messages[thread.messages.length - 1];
        const timeAgo = lastMessage ? 
          formatTimeAgo(new Date(lastMessage.timestamp)) : 
          'Baru saja';
        
        message += `<b>${index + 1}. ${thread.userName}</b>\n`;
        message += `├ Thread ID: <code>${thread.threadId}</code>\n`;
        message += `├ Status: ${thread.status === 'active' ? '🟢 Active' : '🟡 Pending'}\n`;
        message += `├ Admin: ${thread.adminName || 'Belum diambil'}\n`;
        message += `├ Pesan: ${thread.messages.length}\n`;
        message += `└ Terakhir: ${timeAgo}\n\n`;
      });
    }
    
    const keyboard = [];
    
    if (activeThreads.length > 0) {
      activeThreads.forEach((thread, index) => {
        keyboard.push([
          { 
            text: `${index + 1}. ${thread.userName}`, 
            callback_data: `cs_view_thread_${thread.threadId}` 
          }
        ]);
      });
      
      keyboard.push([]);
    }
    
    keyboard.push([
      { text: '🔄 Refresh', callback_data: 'cs_active_threads' },
      { text: '📊 CS Stats', callback_data: 'cs_stats' }
    ]);
    
    keyboard.push([
      { text: '🔙 CS Menu', callback_data: 'owner_cs_menu' },
      { text: '🏠 Menu Utama', callback_data: 'main_menu' }
    ]);
    
    await editMessage(chatId, messageId, callbackQueryId, message, {
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: keyboard },
      disable_web_page_preview: true
    });
    
  } catch (error) {
    console.error('Error showActiveCSThreads:', error);
  }
}

// ========================= WITHDRAW (PENCAIRAN DANA) FUNCTIONS =========================

// Cache untuk produk withdraw
const withdrawProductsCache = {
    data: null,
    timestamp: 0,
    ttl: 5 * 60 * 1000, // 5 menit
    loading: false
};

// Fungsi untuk mendapatkan produk withdraw dari API
async function getWithdrawProducts() {
    const now = Date.now();
    
    if (withdrawProductsCache.data && (now - withdrawProductsCache.timestamp < withdrawProductsCache.ttl)) {
        return withdrawProductsCache.data;
    }
    
    if (withdrawProductsCache.loading) {
        return withdrawProductsCache.data || { success: false, data: [] };
    }
    
    withdrawProductsCache.loading = true;
    
    try {
        const options = {
            method: 'GET',
            url: 'https://www.rumahotp.com/api/v1/h2h/product',
            headers: {
                'x-apikey': x_apikey,
                'Accept': 'application/json'
            }
        };
        
        const response = await axios(options);
        
        if (response.data && response.data.success) {
            withdrawProductsCache.data = response.data;
            withdrawProductsCache.timestamp = now;
        }
        
        return response.data;
    } catch (error) {
        console.error('Error fetching withdraw products:', error);
        return { success: false, data: [] };
    } finally {
        withdrawProductsCache.loading = false;
    }
}

// Fungsi untuk filter produk e-wallet (DANA, OVO, GOPAY, dll)
function filterEwalletProducts(products) {
    if (!products || !Array.isArray(products)) return [];
    
    const ewalletBrands = ['dana', 'ovo', 'gopay', 'shopeepay', 'linkaja'];
    
    return products.filter(product => {
        const brand = (product.brand || '').toLowerCase();
        const category = (product.category || '').toLowerCase();
        const type = (product.type || '').toLowerCase();
        
        // Filter hanya e-wallet
        return ewalletBrands.includes(brand) || 
               category.includes('ewallet') || 
               type.includes('topup_saldo') ||
               type.includes('ewallet');
    });
}

// Fungsi untuk mendapatkan produk berdasarkan brand
function getProductsByBrand(products, brand) {
    if (!products || !Array.isArray(products)) return [];
    
    return products.filter(product => 
        (product.brand || '').toLowerCase() === brand.toLowerCase()
    );
}

// Fungsi untuk memformat produk
function formatProductInfo(product) {
    const priceInfo = product.price_info || {};
    const originalPrice = priceInfo.price_original || product.price || 0;
    const discountPrice = priceInfo.price_discount || product.price || 0;
    const discountPercent = priceInfo.price_discount_percent || 0;
    
    return {
        code: product.code,
        name: product.name,
        note: product.note,
        brand: product.brand,
        category: product.category,
        type: product.type,
        img_url: product.img_url,
        price: discountPrice,
        original_price: originalPrice,
        discount_percent: discountPercent
    };
}

// ========================= WITHDRAW MENU FUNCTIONS =========================

async function showWithdrawMenu(chatId, userId, messageId, callbackQueryId, page = 0) {
    try {
        if (!owner_ids.includes(userId.toString())) {
            await bot.answerCallbackQuery(callbackQueryId, {
                text: '⛔ Akses Ditolak\nHanya owner yang bisa mengakses menu ini',
                show_alert: true
            });
            return;
        }

        await editMessage(chatId, messageId, callbackQueryId,
            '⏳ Memuat produk withdraw...',
            { parse_mode: 'HTML' }
        );

        const productsData = await getWithdrawProducts();
        
        if (!productsData || !productsData.success) {
            await editMessage(chatId, messageId, callbackQueryId,
                '<b>❌ GAGAL MEMUAT PRODUK</b>\n\nTidak dapat mengambil data produk dari server.\n\nSilakan coba lagi nanti.',
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '🔄 Coba Lagi', callback_data: 'withdraw_menu' }],
                            [{ text: '🔙 Owner Menu', callback_data: 'owner_menu' }]
                        ]
                    }
                }
            );
            return;
        }

        const allProducts = productsData.data || [];
        const ewalletProducts = filterEwalletProducts(allProducts);
        
        // Group by brand
        const danaProducts = getProductsByBrand(ewalletProducts, 'dana');
        const ovoProducts = getProductsByBrand(ewalletProducts, 'ovo');
        const gopayProducts = getProductsByBrand(ewalletProducts, 'gopay');
        const shopeepayProducts = getProductsByBrand(ewalletProducts, 'shopeepay');
        const linkajaProducts = getProductsByBrand(ewalletProducts, 'linkaja');
        const otherProducts = ewalletProducts.filter(p => {
            const brand = (p.brand || '').toLowerCase();
            return !['dana', 'ovo', 'gopay', 'shopeepay', 'linkaja'].includes(brand);
        });

        const itemsPerPage = 5;
        const allBrands = [
            { name: 'DANA', data: danaProducts, emoji: '💙' },
            { name: 'OVO', data: ovoProducts, emoji: '💜' },
            { name: 'GOPAY', data: gopayProducts, emoji: '💚' },
            { name: 'SHOPEEPAY', data: shopeepayProducts, emoji: '🛒' },
            { name: 'LINKAJA', data: linkajaProducts, emoji: '🔗' },
            { name: 'LAINNYA', data: otherProducts, emoji: '📱' }
        ].filter(b => b.data.length > 0);
        
        const totalPages = Math.ceil(allBrands.length / itemsPerPage);
        if (page < 0) page = 0;
        if (page >= totalPages && totalPages > 0) page = totalPages - 1;
        
        const startIndex = page * itemsPerPage;
        const endIndex = startIndex + itemsPerPage;
        const pageBrands = allBrands.slice(startIndex, endIndex);
        
        let message = `<b>💰 WITHDRAW (PENCAIRAN DANA)</b>\n\n`;
        message += `<b>Total Produk:</b> ${ewalletProducts.length}\n`;
        message += `<b>Halaman:</b> ${page + 1}/${totalPages}\n\n`;
        
        message += `<b>Pilih E-Wallet:</b>\n\n`;
        
        pageBrands.forEach((brand, index) => {
            const num = startIndex + index + 1;
            message += `${brand.emoji} <b>${brand.name}</b> - ${brand.data.length} produk\n`;
            
            // Tampilkan beberapa produk sebagai contoh
            const sampleProducts = brand.data.slice(0, 3);
            sampleProducts.forEach(product => {
                const formatted = formatProductInfo(product);
                const price = formatted.price;
                const originalPrice = formatted.original_price;
                
                if (formatted.discount_percent > 0) {
                    message += `  • ${product.name}: <s>${formatCurrency(originalPrice)}</s> → ${formatCurrency(price)} (${formatted.discount_percent}%)\n`;
                } else {
                    message += `  • ${product.name}: ${formatCurrency(price)}\n`;
                }
            });
            
            if (brand.data.length > 3) {
                message += `  • ... dan ${brand.data.length - 3} produk lainnya\n`;
            }
            
            message += `\n`;
        });

        const keyboard = [];
        
        // Brand selection buttons
        pageBrands.forEach((brand, index) => {
            keyboard.push([
                { 
                    text: `${brand.emoji} ${brand.name} (${brand.data.length})`, 
                    callback_data: `withdraw_brand_${brand.name.toLowerCase()}_${page}` 
                }
            ]);
        });
        
        // Navigation buttons
        const navButtons = [];
        if (totalPages > 1) {
            if (page > 0) {
                navButtons.push({ 
                    text: '◀️ Sebelumnya', 
                    callback_data: `withdraw_menu_page_${page - 1}` 
                });
            }
            
            navButtons.push({ 
                text: `📄 ${page + 1}/${totalPages}`, 
                callback_data: 'no_action' 
            });
            
            if (page < totalPages - 1) {
                navButtons.push({ 
                    text: '▶️ Berikutnya', 
                    callback_data: `withdraw_menu_page_${page + 1}` 
                });
            }
            
            if (navButtons.length > 0) {
                keyboard.push(navButtons);
            }
        }
        
        // Action buttons
        keyboard.push([
            { text: '📋 Riwayat Withdraw', callback_data: 'withdraw_history' },
            { text: '🔄 Refresh', callback_data: `withdraw_menu_page_${page}` }
        ]);
        
        keyboard.push([
            { text: '🔙 Owner Menu', callback_data: 'owner_menu' },
            { text: '🏠 Menu Utama', callback_data: 'main_menu' }
        ]);

        await editMessage(chatId, messageId, callbackQueryId, message, {
            parse_mode: 'HTML',
            reply_markup: { inline_keyboard: keyboard },
            disable_web_page_preview: true
        });

    } catch (error) {
        console.error('Error in showWithdrawMenu:', error);
        await editMessage(chatId, messageId, callbackQueryId,
            `<b>❌ ERROR</b>\n\nGagal memuat menu withdraw.\n\nError: ${error.message}`,
            { 
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '🔄 Coba Lagi', callback_data: 'withdraw_menu' }],
                        [{ text: '🔙 Owner Menu', callback_data: 'owner_menu' }]
                    ]
                }
            }
        );
    }
}

async function showWithdrawBrandProducts(chatId, userId, brand, menuPage, messageId, callbackQueryId, productPage = 0) {
    try {
        if (!owner_ids.includes(userId.toString())) {
            await bot.answerCallbackQuery(callbackQueryId, {
                text: '⛔ Akses Ditolak\nHanya owner yang bisa mengakses menu ini',
                show_alert: true
            });
            return;
        }

        // Ambil data dari cache
        const productsData = await getWithdrawProducts();
        
        if (!productsData || !productsData.success) {
            await editMessage(chatId, messageId, callbackQueryId,
                '<b>❌ GAGAL MEMUAT PRODUK</b>',
                { parse_mode: 'HTML' }
            );
            return;
        }

        const allProducts = productsData.data || [];
        const ewalletProducts = filterEwalletProducts(allProducts);
        const brandProducts = getProductsByBrand(ewalletProducts, brand);
        
        // LOGGING UNTUK DEBUG
        console.log(`Brand: ${brand}, Total Products: ${brandProducts.length}, MenuPage: ${menuPage}, ProductPage: ${productPage}`);
        
        if (brandProducts.length === 0) {
            await editMessage(chatId, messageId, callbackQueryId,
                `<b>❌ TIDAK ADA PRODUK</b>\n\nTidak ada produk untuk ${brand.toUpperCase()}.`,
                { parse_mode: 'HTML' }
            );
            return;
        }

        // Sort products by price
        brandProducts.sort((a, b) => {
            const priceA = a.price_info?.price_discount || a.price || 0;
            const priceB = b.price_info?.price_discount || b.price || 0;
            return priceA - priceB;
        });

        const itemsPerPage = 8;
        const totalPages = Math.ceil(brandProducts.length / itemsPerPage);
        
        // Validasi productPage
        if (productPage < 0) productPage = 0;
        if (productPage >= totalPages) productPage = totalPages - 1;
        
        const startIndex = productPage * itemsPerPage;
        const endIndex = Math.min(startIndex + itemsPerPage, brandProducts.length);
        const pageProducts = brandProducts.slice(startIndex, endIndex);

        const brandEmoji = {
            'dana': '💙',
            'ovo': '💜',
            'gopay': '💚',
            'shopeepay': '🛒',
            'linkaja': '🔗'
        }[brand] || '💰';

        let message = `<b>${brandEmoji} ${brand.toUpperCase()} - PRODUK WITHDRAW</b>\n\n`;
        message += `<b>Total Produk:</b> ${brandProducts.length}\n`;
        message += `<b>Halaman Produk:</b> ${productPage + 1}/${totalPages}\n\n`;
        
        message += `<b>Daftar Produk (${startIndex + 1}-${endIndex} dari ${brandProducts.length}):</b>\n\n`;

        pageProducts.forEach((product, index) => {
            const num = startIndex + index + 1;
            const formatted = formatProductInfo(product);
            
            message += `<b>${num}. ${product.name}</b>\n`;
            message += `   📦 Kode: <code>${product.code}</code>\n`;
            
            if (formatted.discount_percent > 0) {
                message += `   💰 Harga: <s>${formatCurrency(formatted.original_price)}</s> → <b>${formatCurrency(formatted.price)}</b>\n`;
                message += `   🏷️ Diskon: ${formatted.discount_percent}%\n`;
            } else {
                message += `   💰 Harga: ${formatCurrency(formatted.price)}\n`;
            }
            
            if (product.note) {
                message += `   📝 Catatan: ${product.note}\n`;
            }
            
            message += `\n`;
        });

        const keyboard = [];

        // Product selection buttons
        for (let i = 0; i < pageProducts.length; i += 2) {
            const row = [];
            
            if (pageProducts[i]) {
                const product = pageProducts[i];
                const num = startIndex + i + 1;
                row.push({ 
                    text: `${num}. ${product.name.substring(0, 15)}`, 
                    callback_data: `withdraw_product_${product.code}_${brand}_${menuPage}_${productPage}` 
                });
            }
            
            if (pageProducts[i + 1]) {
                const product = pageProducts[i + 1];
                const num = startIndex + i + 2;
                row.push({ 
                    text: `${num}. ${product.name.substring(0, 15)}`, 
                    callback_data: `withdraw_product_${product.code}_${brand}_${menuPage}_${productPage}` 
                });
            }
            
            if (row.length > 0) {
                keyboard.push(row);
            }
        }

        // Product navigation buttons - PERBAIKAN UTAMA
        if (totalPages > 1) {
            const navRow = [];
            
            // Tombol Previous
            if (productPage > 0) {
                navRow.push({ 
                    text: '◀️ Prev', 
                    callback_data: `withdraw_brand_products_${brand}_${menuPage}_${productPage - 1}` 
                });
            } else {
                navRow.push({ 
                    text: '◀️', 
                    callback_data: 'no_action' 
                });
            }
            
            // Info halaman
            navRow.push({ 
                text: `📄 ${productPage + 1}/${totalPages}`, 
                callback_data: 'no_action' 
            });
            
            // Tombol Next
            if (productPage < totalPages - 1) {
                navRow.push({ 
                    text: '▶️ Next', 
                    callback_data: `withdraw_brand_products_${brand}_${menuPage}_${productPage + 1}` 
                });
            } else {
                navRow.push({ 
                    text: '▶️', 
                    callback_data: 'no_action' 
                });
            }
            
            if (navRow.length > 0) {
                keyboard.push(navRow);
            }
        }

        // Action buttons
        keyboard.push([
            { text: '🔙 Kembali ke Menu', callback_data: `withdraw_menu_page_${menuPage}` },
            { text: '📋 Riwayat', callback_data: 'withdraw_history' }
        ]);

        keyboard.push([
            { text: '🔙 Owner Menu', callback_data: 'owner_menu' },
            { text: '🏠 Menu Utama', callback_data: 'main_menu' }
        ]);

        await editMessage(chatId, messageId, callbackQueryId, message, {
            parse_mode: 'HTML',
            reply_markup: { inline_keyboard: keyboard },
            disable_web_page_preview: true
        });

    } catch (error) {
        console.error('Error in showWithdrawBrandProducts:', error);
        await editMessage(chatId, messageId, callbackQueryId,
            `<b>❌ ERROR</b>\n\nGagal memuat produk.\n\nError: ${error.message}`,
            { parse_mode: 'HTML' }
        );
    }
}

async function showWithdrawProductDetail(chatId, userId, productCode, brand, menuPage, productPage, messageId, callbackQueryId) {
    try {
        if (!owner_ids.includes(userId.toString())) {
            await bot.answerCallbackQuery(callbackQueryId, {
                text: '⛔ Akses Ditolak\nHanya owner yang bisa mengakses menu ini',
                show_alert: true
            });
            return;
        }

        await editMessage(chatId, messageId, callbackQueryId,
            '⏳ Memuat detail produk...',
            { parse_mode: 'HTML' }
        );

        const productsData = await getWithdrawProducts();
        
        if (!productsData || !productsData.success) {
            await editMessage(chatId, messageId, callbackQueryId,
                '<b>❌ GAGAL MEMUAT PRODUK</b>',
                { parse_mode: 'HTML' }
            );
            return;
        }

        const allProducts = productsData.data || [];
        const product = allProducts.find(p => p.code === productCode);
        
        if (!product) {
            await editMessage(chatId, messageId, callbackQueryId,
                `<b>❌ PRODUK TIDAK DITEMUKAN</b>\n\nKode: <code>${productCode}</code>`,
                { parse_mode: 'HTML' }
            );
            return;
        }

        const formatted = formatProductInfo(product);
        
        // Set selection untuk input nomor tujuan
        const selection = {
            step: 'awaiting_withdraw_target',
            productCode: product.code,
            productName: product.name,
            productPrice: formatted.price,
            brand: brand,
            menuPage: menuPage,
            productPage: productPage,
            timestamp: Date.now()
        };
        userSelections.set(userId, selection);

        const brandEmoji = {
            'dana': '💙',
            'ovo': '💜',
            'gopay': '💚',
            'shopeepay': '🛒',
            'linkaja': '🔗'
        }[brand] || '💰';

        let message = `<b>${brandEmoji} DETAIL PRODUK WITHDRAW</b>\n\n`;
        
        message += `<b>Produk:</b> ${product.name}\n`;
        message += `<b>Kode:</b> <code>${product.code}</code>\n`;
        message += `<b>Brand:</b> ${product.brand || '-'}\n`;
        message += `<b>Kategori:</b> ${product.category || '-'}\n`;
        message += `<b>Tipe:</b> ${product.type || '-'}\n\n`;
        
        if (formatted.discount_percent > 0) {
            message += `<b>Harga Asli:</b> <s>${formatCurrency(formatted.original_price)}</s>\n`;
            message += `<b>Harga Diskon:</b> ${formatCurrency(formatted.price)}\n`;
            message += `<b>Diskon:</b> ${formatted.discount_percent}%\n`;
        } else {
            message += `<b>Harga:</b> ${formatCurrency(formatted.price)}\n`;
        }
        
        if (product.note) {
            message += `\n<b>Catatan:</b> ${product.note}\n`;
        }
        
        message += `\n<b>📱 MASUKKAN NOMOR TUJUAN</b>\n\n`;
        message += `Silakan kirim nomor tujuan withdraw:\n`;
        message += `• Contoh: <code>08123456789</code>\n`;
        message += `• Nomor harus aktif dan terdaftar di ${brand.toUpperCase()}\n\n`;
        message += `<i>Ketik 0 untuk membatalkan</i>`;

        const keyboard = [
            [
                { text: '🔙 Kembali', callback_data: `withdraw_brand_products_${brand}_${menuPage}_${productPage}` },
                { text: '❌ Batalkan', callback_data: `withdraw_brand_${brand}_${menuPage}` }
            ]
        ];

        await editMessage(chatId, messageId, callbackQueryId, message, {
            parse_mode: 'HTML',
            reply_markup: { inline_keyboard: keyboard }
        });

    } catch (error) {
        console.error('Error in showWithdrawProductDetail:', error);
        await editMessage(chatId, messageId, callbackQueryId,
            `<b>❌ ERROR</b>\n\nGagal memuat detail produk.\n\nError: ${error.message}`,
            { parse_mode: 'HTML' }
        );
    }
}

async function processWithdrawOrder(chatId, userId, productCode, targetNumber, messageId) {
    try {
        const loadingMsg = await bot.sendMessage(chatId,
            '⏳ <b>MEMPROSES WITHDRAW...</b>\n\nMengirim permintaan ke server...',
            { parse_mode: 'HTML' }
        );

        // Bersihkan nomor tujuan (hapus spasi, tanda hubung, dll)
        const cleanTarget = targetNumber.replace(/[^\d]/g, '');
        
        if (cleanTarget.length < 10 || cleanTarget.length > 15) {
            await bot.editMessageText(
                `❌ <b>NOMOR TIDAK VALID</b>\n\n` +
                `Nomor: <code>${targetNumber}</code>\n` +
                `Panjang nomor harus 10-15 digit.\n\n` +
                `Contoh format: <code>08123456789</code>`,
                {
                    chat_id: chatId,
                    message_id: loadingMsg.message_id,
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '🔄 Coba Lagi', callback_data: 'withdraw_menu' }]
                        ]
                    }
                }
            );
            return;
        }

        // Create order
        const url = `https://www.rumahotp.com/api/v1/h2h/transaksi/create?id=${productCode}&target=${cleanTarget}`;
        
        const options = {
            method: 'GET',
            url: url,
            headers: {
                'x-apikey': x_apikey,
                'Accept': 'application/json'
            }
        };

        const response = await axios(options);
        
        if (!response.data || !response.data.success) {
            await bot.editMessageText(
                `❌ <b>WITHDRAW GAGAL</b>\n\n` +
                `Pesan: ${response.data?.message || 'Tidak diketahui'}\n\n` +
                `Kode Produk: <code>${productCode}</code>\n` +
                `Tujuan: <code>${cleanTarget}</code>`,
                {
                    chat_id: chatId,
                    message_id: loadingMsg.message_id,
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '🔄 Coba Lagi', callback_data: 'withdraw_menu' }]
                        ]
                    }
                }
            );
            return;
        }

        const orderData = response.data.data;
        const orderId = orderData.id;
        
        // Simpan ke database transaksi
        const transactionId = addTransaction('withdraw_orders', {
            userId: userId,
            orderId: orderId,
            productCode: productCode,
            targetNumber: cleanTarget,
            status: orderData.status || 'processing',
            price: orderData.sisa_balance || 0,
            productName: orderData.product || 'Unknown',
            raw_data: orderData,
            created_at: orderData.created_at
        });

        // Update loading message
        await bot.editMessageText(
            `✅ <b>WITHDRAW DIPROSES</b>\n\n` +
            `<b>ID Transaksi:</b> <code>${orderId}</code>\n` +
            `<b>Produk:</b> ${orderData.product || '-'}\n` +
            `<b>Tujuan:</b> <code>${orderData.tujuan || cleanTarget}</code>\n` +
            `<b>Status:</b> ${orderData.status || 'processing'}\n` +
            `<b>Sisa Saldo:</b> ${formatCurrency(orderData.sisa_balance || 0)}\n\n` +
            `⏳ <b>Memantau status transaksi...</b>\n\n` +
            `<i>Status akan diperbarui otomatis setiap 5 detik</i>`,
            {
                chat_id: chatId,
                message_id: loadingMsg.message_id,
                parse_mode: 'HTML'
            }
        );

        // Monitor status setiap 5 detik
        let retryCount = 0;
        const maxRetries = 120; // 10 menit
        
        const interval = setInterval(async () => {
            try {
                retryCount++;
                
                if (retryCount >= maxRetries) {
                    clearInterval(interval);
                    
                    await bot.editMessageText(
                        `⏱️ <b>WAKTU MONITORING HABIS</b>\n\n` +
                        `<b>ID Transaksi:</b> <code>${orderId}</code>\n\n` +
                        `Monitoring dihentikan setelah 10 menit.\n` +
                        `Gunakan menu Riwayat untuk cek status terbaru.`,
                        {
                            chat_id: chatId,
                            message_id: loadingMsg.message_id,
                            parse_mode: 'HTML',
                            reply_markup: {
                                inline_keyboard: [
                                    [{ text: '📋 Riwayat Withdraw', callback_data: 'withdraw_history' }],
                                    [{ text: '💰 Withdraw Lagi', callback_data: 'withdraw_menu' }]
                                ]
                            }
                        }
                    );
                    return;
                }

                const statusOptions = {
                    method: 'GET',
                    url: `https://www.rumahotp.com/api/v1/h2h/transaksi/status?transaksi_id=${orderId}`,
                    headers: {
                        'x-apikey': x_apikey,
                        'Accept': 'application/json'
                    }
                };

                const statusResponse = await axios(statusOptions);
                
                if (!statusResponse.data || !statusResponse.data.success) {
                    return;
                }

                const statusData = statusResponse.data.data;
                
                // Update status di database
                updateTransactionStatus('withdraw_orders', orderId, statusData.status);

                if (statusData.status === 'success') {
                    clearInterval(interval);
                    
                    const finishTime = statusData.finish_at ? 
                        new Date(statusData.finish_at).toLocaleString('id-ID') : 
                        new Date().toLocaleString('id-ID');
                    
                    const sn = statusData.response?.sn || '-';
                    const responseTime = statusData.response?.time || '-';
                    
                    await bot.editMessageText(
                        `✅ <b>WITHDRAW BERHASIL!</b>\n\n` +
                        `<b>ID Transaksi:</b> <code>${orderId}</code>\n` +
                        `<b>Produk:</b> ${statusData.product?.name || statusData.product || '-'}\n` +
                        `<b>Tujuan:</b> <code>${statusData.tujuan}</code>\n` +
                        `<b>Harga:</b> ${formatCurrency(statusData.price || 0)}\n` +
                        `<b>SN:</b> <code>${sn}</code>\n` +
                        `<b>Waktu Provider:</b> ${responseTime}\n` +
                        `<b>Selesai:</b> ${finishTime}\n\n` +
                        `💰 <b>Saldo Terkini:</b> ${formatCurrency(statusData.sisa_balance || 0)}`,
                        {
                            chat_id: chatId,
                            message_id: loadingMsg.message_id,
                            parse_mode: 'HTML',
                            reply_markup: {
                                inline_keyboard: [
                                    [
                                        { text: '💰 Withdraw Lagi', callback_data: 'withdraw_menu' },
                                        { text: '📋 Riwayat', callback_data: 'withdraw_history' }
                                    ],
                                    [
                                        { text: '🔙 Owner Menu', callback_data: 'owner_menu' }
                                    ]
                                ]
                            }
                        }
                    );

                    // Kirim notifikasi ke channel
                    if (channel) {
                        try {
                            await bot.sendMessage(channel,
                                `✅ <b>WITHDRAW BERHASIL</b>\n\n` +
                                `<b>ID:</b> <code>${orderId}</code>\n` +
                                `<b>Produk:</b> ${statusData.product?.name || '-'}\n` +
                                `<b>Tujuan:</b> <code>${statusData.tujuan}</code>\n` +
                                `<b>Jumlah:</b> ${formatCurrency(statusData.price || 0)}\n` +
                                `<b>SN:</b> <code>${sn}</code>\n` +
                                `<b>Waktu:</b> ${finishTime}`,
                                { parse_mode: 'HTML' }
                            );
                        } catch (error) {}
                    }

                } else if (statusData.status === 'failed' || statusData.status === 'canceled') {
                    clearInterval(interval);
                    
                    await bot.editMessageText(
                        `❌ <b>WITHDRAW GAGAL!</b>\n\n` +
                        `<b>ID Transaksi:</b> <code>${orderId}</code>\n` +
                        `<b>Produk:</b> ${statusData.product?.name || statusData.product || '-'}\n` +
                        `<b>Tujuan:</b> <code>${statusData.tujuan}</code>\n` +
                        `<b>Status:</b> ${statusData.status.toUpperCase()}\n` +
                        `<b>Pesan:</b> ${statusData.response?.status || '-'}\n` +
                        `<b>Refund:</b> ${statusData.refund ? '✅ Ya' : '❌ Tidak'}`,
                        {
                            chat_id: chatId,
                            message_id: loadingMsg.message_id,
                            parse_mode: 'HTML',
                            reply_markup: {
                                inline_keyboard: [
                                    [
                                        { text: '🔄 Coba Lagi', callback_data: 'withdraw_menu' },
                                        { text: '📋 Riwayat', callback_data: 'withdraw_history' }
                                    ]
                                ]
                            }
                        }
                    );

                    // Kirim notifikasi gagal ke channel
                    if (channel) {
                        try {
                            await bot.sendMessage(channel,
                                `❌ <b>WITHDRAW GAGAL</b>\n\n` +
                                `<b>ID:</b> <code>${orderId}</code>\n` +
                                `<b>Produk:</b> ${statusData.product?.name || '-'}\n` +
                                `<b>Tujuan:</b> <code>${statusData.tujuan}</code>\n` +
                                `<b>Status:</b> ${statusData.status.toUpperCase()}\n` +
                                `<b>Waktu:</b> ${new Date().toLocaleString('id-ID')}`,
                                { parse_mode: 'HTML' }
                            );
                        } catch (error) {}
                    }

                } else if (statusData.status === 'processing') {
                    // Update status setiap 30 detik
                    if (retryCount % 6 === 0) {
                        await bot.editMessageText(
                            `⏳ <b>WITHDRAW DIPROSES...</b>\n\n` +
                            `<b>ID Transaksi:</b> <code>${orderId}</code>\n` +
                            `<b>Produk:</b> ${statusData.product?.name || statusData.product || '-'}\n` +
                            `<b>Tujuan:</b> <code>${statusData.tujuan}</code>\n` +
                            `<b>Status:</b> processing\n` +
                            `<b>Waktu:</b> ${new Date().toLocaleString('id-ID')}\n\n` +
                            `<i>Pengecekan ke-${retryCount} / ${maxRetries}</i>`,
                            {
                                chat_id: chatId,
                                message_id: loadingMsg.message_id,
                                parse_mode: 'HTML'
                            }
                        );
                    }
                }

            } catch (error) {
                console.error('Error checking withdraw status:', error);
            }
        }, 5000);

        // Auto-clear interval after 10 minutes
        setTimeout(() => {
            clearInterval(interval);
        }, 10 * 60 * 1000);

    } catch (error) {
        console.error('Error in processWithdrawOrder:', error);
        
        let errorMessage = '❌ <b>GAGAL MEMPROSES WITHDRAW</b>\n\n';
        
        if (error.response) {
            errorMessage += `Error: ${error.response.data?.message || error.message}\n`;
        } else if (error.request) {
            errorMessage += `Error: Tidak dapat terhubung ke server\n`;
        } else {
            errorMessage += `Error: ${error.message}\n`;
        }
        
        errorMessage += `\nKode Produk: <code>${productCode}</code>\n`;
        errorMessage += `Tujuan: <code>${targetNumber}</code>`;
        
        await bot.sendMessage(chatId, errorMessage, {
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [
                    [{ text: '🔄 Coba Lagi', callback_data: 'withdraw_menu' }]
                ]
            }
        });
    }
}

async function showWithdrawHistory(chatId, userId, messageId, callbackQueryId, page = 0) {
    try {
        if (!owner_ids.includes(userId.toString())) {
            await bot.answerCallbackQuery(callbackQueryId, {
                text: '⛔ Akses Ditolak\nHanya owner yang bisa mengakses menu ini',
                show_alert: true
            });
            return;
        }

        const transactions = loadTransactions();
        const withdrawOrders = transactions.withdraw_orders || [];
        
        // Sort by timestamp descending
        withdrawOrders.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
        
        const itemsPerPage = 5;
        const totalPages = Math.ceil(withdrawOrders.length / itemsPerPage);
        if (page < 0) page = 0;
        if (page >= totalPages && totalPages > 0) page = totalPages - 1;
        
        const startIndex = page * itemsPerPage;
        const endIndex = startIndex + itemsPerPage;
        const pageOrders = withdrawOrders.slice(startIndex, endIndex);
        
        let message = `<b>📋 RIWAYAT WITHDRAW</b>\n\n`;
        
        if (withdrawOrders.length === 0) {
            message += `<i>Belum ada riwayat withdraw</i>\n`;
        } else {
            message += `<b>Total Transaksi:</b> ${withdrawOrders.length}\n`;
            message += `<b>Halaman:</b> ${page + 1}/${totalPages}\n\n`;
            
            pageOrders.forEach((order, index) => {
                const num = startIndex + index + 1;
                const orderData = order.data || {};
                const date = new Date(order.timestamp).toLocaleString('id-ID');
                
                let statusEmoji = '⏳';
                if (order.status === 'success') statusEmoji = '✅';
                else if (order.status === 'failed') statusEmoji = '❌';
                else if (order.status === 'canceled') statusEmoji = '🚫';
                
                message += `<b>${num}. ${statusEmoji} ID: <code>${orderData.orderId || order.id}</code></b>\n`;
                message += `   📦 Produk: ${orderData.productName || '-'}\n`;
                message += `   📱 Tujuan: <code>${orderData.targetNumber || '-'}</code>\n`;
                message += `   💰 Harga: ${formatCurrency(orderData.price || 0)}\n`;
                message += `   📊 Status: ${order.status}\n`;
                message += `   🕒 Waktu: ${date}\n\n`;
            });
        }

        const keyboard = [];
        
        // Navigation buttons
        if (totalPages > 1) {
            const navButtons = [];
            if (page > 0) {
                navButtons.push({ 
                    text: '◀️ Prev', 
                    callback_data: `withdraw_history_page_${page - 1}` 
                });
            } else {
                navButtons.push({ 
                    text: '◀️', 
                    callback_data: 'no_action' 
                });
            }
            
            navButtons.push({ 
                text: `📄 ${page + 1}/${totalPages}`, 
                callback_data: 'no_action' 
            });
            
            if (page < totalPages - 1) {
                navButtons.push({ 
                    text: '▶️ Next', 
                    callback_data: `withdraw_history_page_${page + 1}` 
                });
            } else {
                navButtons.push({ 
                    text: '▶️', 
                    callback_data: 'no_action' 
                });
            }
            
            if (navButtons.length > 0) {
                keyboard.push(navButtons);
            }
        }
        
        // Action buttons
        keyboard.push([
            { text: '💰 Withdraw Baru', callback_data: 'withdraw_menu' },
            { text: '🔄 Refresh', callback_data: `withdraw_history_page_${page}` }
        ]);
        
        keyboard.push([
            { text: '🔙 Owner Menu', callback_data: 'owner_menu' },
            { text: '🏠 Menu Utama', callback_data: 'main_menu' }
        ]);

        await editMessage(chatId, messageId, callbackQueryId, message, {
            parse_mode: 'HTML',
            reply_markup: { inline_keyboard: keyboard },
            disable_web_page_preview: true
        });

    } catch (error) {
        console.error('Error in showWithdrawHistory:', error);
        await editMessage(chatId, messageId, callbackQueryId,
            `<b>❌ ERROR</b>\n\nGagal memuat riwayat withdraw.\n\nError: ${error.message}`,
            { parse_mode: 'HTML' }
        );
    }
}

// Helper function untuk format waktu
function formatTimeAgo(date) {
  const now = new Date();
  const diffMs = now - date;
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);
  
  if (diffMins < 1) return 'Baru saja';
  if (diffMins < 60) return `${diffMins} menit lalu`;
  if (diffHours < 24) return `${diffHours} jam lalu`;
  return `${diffDays} hari lalu`;
}

async function executeDeleteBackup(chatId, userId, backupFileName, messageId, callbackQueryId) {
    try {
        const backupDir = path.join(__dirname, 'backup');
        const backupPath = path.join(backupDir, backupFileName);
        
        if (!fs.existsSync(backupPath)) {
            await editMessage(chatId, messageId, callbackQueryId,
                `<b>❌ FILE TIDAK DITEMUKAN</b>\n\nFile backup sudah tidak ada:\n<code>${backupFileName}</code>`,
                {
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Kembali ke Daftar', callback_data: 'restore_menu' }]
                        ]
                    }
                }
            );
            return;
        }

        const stats = fs.statSync(backupPath);
        const fileSize = (stats.size / 1024).toFixed(2);
        
        fs.unlinkSync(backupPath);

        await editMessage(chatId, messageId, callbackQueryId,
            `<b>✅ FILE TERHAPUS</b>\n\n` +
            `<b>File:</b> <code>${backupFileName}</code>\n` +
            `<b>Ukuran:</b> ${fileSize} KB\n` +
            `<b>Waktu:</b> ${new Date().toLocaleString('id-ID')}\n\n` +
            `<i>File backup telah dihapus permanen</i>`,
            {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '⬅️ Kembali ke Daftar', callback_data: 'restore_menu' }]
                    ]
                }
            }
        );

    } catch (error) {
        let errorMsg = error.message || 'Unknown error';
        await editMessage(chatId, messageId, callbackQueryId,
            `<b>❌ GAGAL MENGHAPUS</b>\n\nTerjadi kesalahan:\n\n<code>${errorMsg}</code>`,
            {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: 'Kembali ke Daftar', callback_data: 'restore_menu' }]
                    ]
                }
            }
        );
    }
}

async function createBackupNow(chatId, userId, messageId, callbackQueryId) {
    try {
        if (!owner_ids.includes(userId.toString())) {
            await bot.answerCallbackQuery(callbackQueryId, {
                text: '⛔ Akses Ditolak\nHanya owner yang bisa mengakses menu ini',
                show_alert: true
            });
            return;
        }

        await editMessage(chatId, messageId, callbackQueryId,
            `<b>🔄 MEMBUAT BACKUP</b>\n\nSedang membuat backup database...\n\nMohon tunggu sebentar.`,
            { parse_mode: 'HTML' }
        );

        await autoBackupTransactions('manual_backup', { manual: true, userId: userId });

        await editMessage(chatId, messageId, callbackQueryId,
            `<b>✅ BACKUP BERHASIL</b>\n\nBackup database telah dibuat.\n\nFile backup telah dikirim ke semua owner.`,
            {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '🔄 Refresh Daftar', callback_data: 'restore_menu' }],
                        [{ text: '⬅️ Kembali', callback_data: 'restore_menu' }]
                    ]
                }
            }
        );

    } catch (error) {
        let errorMsg = error.message || 'Unknown error';
        await editMessage(chatId, messageId, callbackQueryId,
            `<b>❌ BACKUP GAGAL</b>\n\nGagal membuat backup:\n\n<code>${errorMsg}</code>`,
            {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: 'Coba Lagi', callback_data: 'create_backup_now' }],
                        [{ text: 'Kembali', callback_data: 'restore_menu' }]
                    ]
                }
            }
        );
    }
}

async function showCSStats(chatId, userId, messageId, callbackQueryId) {
  try {
    if (!owner_ids.includes(userId.toString()) && !config.cs_admins?.includes(userId.toString())) {
      await bot.answerCallbackQuery(callbackQueryId, {
        text: '⛔ Akses Ditolak\nHanya admin atau CS yang bisa mengakses',
        show_alert: true
      });
      return;
    }
    
    const csAdmins = config.cs_admins || [];
    let totalThreads = 0;
    let activeThreads = 0;
    let pendingThreads = 0;
    let closedThreads = 0;
    let totalMessages = 0;
    
    if (global.csChatSessions) {
      totalThreads = global.csChatSessions.size;
      
      for (const session of global.csChatSessions.values()) {
        if (session.status === 'active') activeThreads++;
        if (session.status === 'pending') pendingThreads++;
        if (session.status === 'closed') closedThreads++;
        totalMessages += session.messages.length;
      }
    }
    
    const today = new Date().toISOString().split('T')[0];
    let todayThreads = 0;
    
    if (global.csChatSessions) {
      for (const session of global.csChatSessions.values()) {
        const createdDate = new Date(session.createdAt).toISOString().split('T')[0];
        if (createdDate === today) {
          todayThreads++;
        }
      }
    }
    
    let message = `<b>📊 CS STATISTICS</b>\n\n`;
    
    message += `<b>General Stats:</b>\n`;
    message += `├ Total CS Admins: ${csAdmins.length}\n`;
    message += `├ Total Threads: ${totalThreads}\n`;
    message += `├ Active Threads: ${activeThreads}\n`;
    message += `├ Pending Threads: ${pendingThreads}\n`;
    message += `├ Closed Threads: ${closedThreads}\n`;
    message += `├ Total Messages: ${totalMessages}\n`;
    message += `└ Today's Threads: ${todayThreads}\n\n`;
    
    message += `<b>CS Admins List:</b>\n`;
    if (csAdmins.length === 0) {
      message += `├ <i>Belum ada CS Admin</i>\n`;
    } else {
      csAdmins.forEach((adminId, index) => {
        // Hitung threads yang ditangani admin ini
        let adminThreads = 0;
        if (global.csChatSessions) {
          for (const session of global.csChatSessions.values()) {
            if (session.adminId === adminId) {
              adminThreads++;
            }
          }
        }
        
        message += `├ ${index + 1}. <code>${adminId}</code> (${adminThreads} threads)\n`;
      });
    }
    
    message += `\n<i>Last updated: ${new Date().toLocaleString('id-ID')}</i>`;
    
    const keyboard = [
      [
        { text: '💬 Active Threads', callback_data: 'cs_active_threads' },
        { text: '🔄 Refresh', callback_data: 'cs_stats' }
      ],
      [
        { text: '🔙 CS Menu', callback_data: 'owner_cs_menu' },
        { text: '🏠 Menu Utama', callback_data: 'main_menu' }
      ]
    ];
    
    await editMessage(chatId, messageId, callbackQueryId, message, {
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: keyboard },
      disable_web_page_preview: true
    });
    
  } catch (error) {
    console.error('Error showCSStats:', error);
  }
}

async function reloadDataAfterRestore(chatId, userId, messageId, callbackQueryId) {
    try {
        await editMessage(chatId, messageId, callbackQueryId,
            `<b>🔄 RELOAD DATA</b>\n\nMemuat ulang data dari database...`,
            { parse_mode: 'HTML' }
        );

        balanceCache.clear();
        userSelections.clear();
        userDepositMessages.clear();
        userPendingCommands.clear();
        orderProcessing.clear();
        depositProcessing.clear();
        sentNotifications.clear();
        servicesCache.data = null;
        servicesCache.timestamp = 0;
        voucherCache.clear();

        await preloadAllData();

        await editMessage(chatId, messageId, callbackQueryId,
            `<b>✅ DATA TELAH DIPERBARUI</b>\n\nSemua cache telah dihapus dan data telah dimuat ulang dari database.\n\nBot siap digunakan dengan data yang baru.`,
            {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '📊 Stats', callback_data: 'owner_stats' }],
                        [
                            { text: '📋 Owner Menu', callback_data: 'owner_menu' },
                            { text: '🏠 Menu Utama', callback_data: 'main_menu' }
                        ]
                    ]
                }
            }
        );

    } catch (error) {
        let errorMsg = error.message || 'Unknown error';
        await editMessage(chatId, messageId, callbackQueryId,
            `<b>❌ RELOAD GAGAL</b>\n\nGagal memuat ulang data:\n\n<code>${errorMsg}</code>`,
            {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: 'Coba Lagi', callback_data: 'restore_reload' }],
                        [{ text: 'Kembali', callback_data: 'owner_menu' }]
                    ]
                }
            }
        );
    }
}

async function sendNewMessage(chatId, message, options = {}) {
  try {
    const lastMsgId = userLastMessage.get(chatId);
    if (lastMsgId) {
      try {
        bot.deleteMessage(chatId, lastMsgId).catch(() => {});
      } catch (e) {}
    }
    
    const newMessage = await bot.sendMessage(chatId, message, {
      parse_mode: 'HTML',
      disable_web_page_preview: true,
      disable_notification: true,
      ...options
    });
    
    userLastMessage.set(chatId, newMessage.message_id);
    return newMessage;
  } catch (error) {
    const newMessage = await bot.sendMessage(chatId, message, {
      parse_mode: 'HTML',
      disable_web_page_preview: true,
      disable_notification: true,
      ...options
    });
    userLastMessage.set(chatId, newMessage.message_id);
    return newMessage;
  }
}

async function editMessage(chatId, messageId, callbackQueryId, message, options = {}) {
  try {
    if (callbackQueryId) {
      bot.answerCallbackQuery(callbackQueryId).catch(() => {});
    }
    
    await bot.editMessageText(message, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'HTML',
      disable_web_page_preview: true,
      ...options
    });
    return true;
  } catch (error) {
    try {
      await sendNewMessage(chatId, message, options);
      return false;
    } catch (e) {
      return false;
    }
  }
}

function isMaintenance() {
  const settings = loadSettings();
  return settings.maintenance === true;
}

function getMaintenanceInfo() {
  const settings = loadSettings();
  if (!settings.maintenance) {
    return { active: false, reason: '' };
  }
  return {
    active: true,
    reason: settings.maintenance_reason || 'Bot sedang dalam perbaikan',
    time: settings.maintenance_time || ''
  };
}

function setMaintenance(active, reason = '') {
  const settings = loadSettings();
  
  settings.maintenance = active;
  if (active) {
    settings.maintenance_reason = reason;
    settings.maintenance_time = new Date().toLocaleString('id-ID');
  } else {
    settings.maintenance_reason = '';
    settings.maintenance_time = '';
  }
  
  saveSettings(settings);
  return active;
}

async function checkMaintenance(msg) {
  const userId = msg.from.id.toString();
  const chatId = msg.chat.id;
  
  const maintenance = getMaintenanceInfo();
  
  if (maintenance.active && !owner_ids.includes(userId)) {
    await bot.sendMessage(chatId,
      `<b>⚠️ Bot Sedang Maintenance</b>

<b>Status:</b> ⛔ Bot tidak bisa digunakan
<b>Alasan:</b> ${maintenance.reason}

<b>Mohon tunggu sampai maintenance selesai.</b>
<b>Owner:</b> @andinsukaapink`,
      { 
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: '🔄 Coba Lagi', callback_data: 'refresh_maintenance' }]
          ]
        }
      }
    );
    return false;
  }
  return true;
}

async function checkChannelMembership(userId) {
  try {
    const chatMember = await bot.getChatMember(channel, userId);
    return ["member", "administrator", "creator"].includes(chatMember.status);
  } catch {
    return false;
  }
}

async function requireJoin(msg) {
  const userId = msg.from.id;
  const isMember = await checkChannelMembership(userId);

  if (!isMember) {
    const originalCommand = msg.text || "/start";
    userPendingCommands.set(userId, originalCommand);

    await sendNewMessage(msg.chat.id, 
`<b>⚠️ Join Channel Terlebih Dahulu</b>

<i>Informasi User</i>
├ Username : <code>${msg.from.first_name}</code>
├ Status   : <code>Tidak termasuk member</code>
└ Akses    : <code>⛔ Terblokir</code>

🔒 <b>Perlu pengecekan akses</b>
└─ Member terlebih dahulu untuk mengakses fitur bot

🔰 <i>Tunggu terlebih dahulu sampai terverifikasi</i>`,

    {
      reply_markup: {
        inline_keyboard: [
          [{ 
            text: "➕ Join Channel", 
            url: `https://t.me/${channel.replace('@','')}` 
          },
          {
            text: "😡 Join Channel",
            url: `https://t.me/${aboutmilaa.replace('@','')}`
             }],
          [{ 
            text: "🔄 Verifikasi Ulang", 
            callback_data: "check_join_again" 
          }]
        ]
      },
      parse_mode: 'HTML'
    });
    return false;
  }
  
  if (userPendingCommands.has(userId)) {
    userPendingCommands.delete(userId);
  }
  
  return true;
}

function withRequireJoin(handler) {
  return async (msg, match) => {
    const ok = await requireJoin(msg);
    if (!ok) return;
    return handler(msg, match);
  };
}

// ========================= VOUCHER OWNER MENU FUNCTIONS =========================

async function showVoucherOwnerMenu(chatId, userId, messageId, callbackQueryId) {
    try {
        if (!owner_ids.includes(userId.toString())) {
            await bot.answerCallbackQuery(callbackQueryId, {
                text: '⛔ Akses Ditolak\nHanya owner yang bisa mengakses menu ini',
                show_alert: true
            });
            return;
        }

        const vouchers = loadVouchers();
        const activeVouchers = getActiveVouchers();
        
        // Ensure voucher_stats exists
        const stats = vouchers.voucher_stats || {
            total_created: 0,
            total_used: 0,
            total_discount: 0
        };
        
        const message = `<b>🎫 VOUCHER MANAGEMENT</b>

<b>Statistik Voucher:</b>
Total Dibuat: ${stats.total_created || 0}
Total Digunakan: ${stats.total_used || 0}
Total Discount: ${formatCurrency(stats.total_discount || 0)}
Voucher Aktif: ${activeVouchers.length}

<b>Pilih menu:</b>`;

        const keyboard = [
            [
                { text: '➕ Buat Voucher', callback_data: 'voucher_create' },
                { text: '📋 List Voucher', callback_data: 'voucher_list' }
            ],
            [
                { text: '📊 Stats Detail', callback_data: 'voucher_stats_detail' },
                { text: '🔄 Refresh', callback_data: 'owner_voucher_menu' }
            ],
            [
                { text: '🔙 Owner Menu', callback_data: 'owner_menu' },
                { text: '🏠 Menu Utama', callback_data: 'main_menu' }
            ]
        ];

        await editMessage(chatId, messageId, callbackQueryId, message, {
            reply_markup: { inline_keyboard: keyboard },
            parse_mode: 'HTML'
        });

    } catch (error) {
        console.error('Error showVoucherOwnerMenu:', error);
        // Send error message to user
        await editMessage(chatId, messageId, callbackQueryId,
            '❌ Terjadi kesalahan saat memuat menu voucher. Silakan coba lagi.',
            { parse_mode: 'HTML' }
        );
    }
}

async function showCreateVoucherStep1(chatId, userId, messageId, callbackQueryId) {
    try {
        if (!owner_ids.includes(userId.toString())) {
            await bot.answerCallbackQuery(callbackQueryId, {
                text: '⛔ Akses Ditolak\nHanya owner yang bisa mengakses menu ini',
                show_alert: true
            });
            return;
        }

        const message = `<b>🎫 BUAT VOUCHER - STEP 1/5</b>

<b>Pilih Tipe Voucher:</b>

1️⃣ <b>Persentase</b> - Diskon berdasarkan persentase harga
   Contoh: 10% diskon dari total belanja

2️⃣ <b>Fixed Amount</b> - Diskon nominal tetap
   Contoh: Rp 5.000 diskon dari total belanja

<i>Pilih salah satu:</i>`;

        const keyboard = [
            [
                { text: '📊 Persentase', callback_data: 'create_voucher_type_percentage' },
                { text: '💰 Fixed Amount', callback_data: 'create_voucher_type_fixed' }
            ],
            [
                { text: '🔙 Kembali', callback_data: 'owner_voucher_menu' },
                { text: '🏠 Menu Utama', callback_data: 'main_menu' }
            ]
        ];

        await editMessage(chatId, messageId, callbackQueryId, message, {
            reply_markup: { inline_keyboard: keyboard },
            parse_mode: 'HTML'
        });

    } catch (error) {
        console.error('Error showCreateVoucherStep1:', error);
    }
}

async function showCreateVoucherStep2(chatId, userId, messageId, callbackQueryId) {
    try {
        const selection = userSelections.get(userId);
        if (!selection || !selection.voucherData) {
            await editMessage(chatId, messageId, callbackQueryId,
                'Sesi tidak ditemukan. Silakan mulai dari awal.',
                { parse_mode: 'HTML' }
            );
            return;
        }

        const voucherType = selection.voucherData.type;
        const typeText = voucherType === 'percentage' ? 'Persentase' : 'Fixed Amount';
        
        const message = `<b>🎫 BUAT VOUCHER - STEP 2/5</b>

<b>Tipe:</b> ${typeText}

<b>Masukkan nilai voucher:</b>

${voucherType === 'percentage' ? 
    'Contoh: <code>10</code> untuk 10% diskon\n(Maksimal 100%)' : 
    'Contoh: <code>5000</code> untuk Rp 5.000 diskon\n(Maksimal Rp 1.000.000)'}

<i>Kirim nilai dalam angka saja:</i>`;

        const keyboard = [
            [
                { text: '🔙 Step Sebelumnya', callback_data: 'voucher_create' },
                { text: '❌ Batalkan', callback_data: 'owner_voucher_menu' }
            ]
        ];

        await editMessage(chatId, messageId, callbackQueryId, message, {
            reply_markup: { inline_keyboard: keyboard },
            parse_mode: 'HTML'
        });

        selection.step = 'awaiting_voucher_value';
        userSelections.set(userId, selection);

    } catch (error) {
        console.error('Error showCreateVoucherStep2:', error);
    }
}

async function showCreateVoucherStep3(chatId, userId, messageId, callbackQueryId) {
    try {
        const selection = userSelections.get(userId);
        if (!selection || !selection.voucherData) {
            await editMessage(chatId, messageId, callbackQueryId,
                'Sesi tidak ditemukan. Silakan mulai dari awal.',
                { parse_mode: 'HTML' }
            );
            return;
        }

        const voucherType = selection.voucherData.type;
        const voucherValue = selection.voucherData.value;
        const typeText = voucherType === 'percentage' ? 'Persentase' : 'Fixed Amount';
        const valueText = voucherType === 'percentage' ? `${voucherValue}%` : formatCurrency(voucherValue);
        
        const message = `<b>🎫 BUAT VOUCHER - STEP 3/5</b>

<b>Tipe:</b> ${typeText}
<b>Nilai:</b> ${valueText}

<b>Aturan Penggunaan:</b>

1️⃣ <b>Minimum Pembelian</b>
   Voucher hanya bisa digunakan jika pembelian mencapai minimum tertentu
   Kosongkan atau 0 untuk tidak ada minimum

2️⃣ <b>Maksimal Discount</b> (Hanya untuk persentase)
   Batas maksimal discount yang diberikan
   Kosongkan untuk tidak ada batas

<i>Format: <code>min_purchase max_discount</code>
Contoh: <code>10000 5000</code> untuk min beli Rp 10.000 dan maks diskon Rp 5.000</i>`;

        const keyboard = [
            [
                { text: '🚫 Tanpa Minimum', callback_data: 'create_voucher_nomin' },
                { text: '💲 Custom', callback_data: 'create_voucher_custom_min' }
            ],
            [
                { text: '🔙 Step Sebelumnya', callback_data: `create_voucher_type_${voucherType}` },
                { text: '❌ Batalkan', callback_data: 'owner_voucher_menu' }
            ]
        ];

        await editMessage(chatId, messageId, callbackQueryId, message, {
            reply_markup: { inline_keyboard: keyboard },
            parse_mode: 'HTML'
        });

    } catch (error) {
        console.error('Error showCreateVoucherStep3:', error);
    }
}

async function showCreateVoucherStep4(chatId, userId, messageId, callbackQueryId) {
    try {
        const selection = userSelections.get(userId);
        if (!selection || !selection.voucherData) {
            await editMessage(chatId, messageId, callbackQueryId,
                'Sesi tidak ditemukan. Silakan mulai dari awal.',
                { parse_mode: 'HTML' }
            );
            return;
        }

        const voucherData = selection.voucherData;
        const typeText = voucherData.type === 'percentage' ? 'Persentase' : 'Fixed Amount';
        const valueText = voucherData.type === 'percentage' ? `${voucherData.value}%` : formatCurrency(voucherData.value);
        const minText = voucherData.min_purchase ? formatCurrency(voucherData.min_purchase) : 'Tidak ada';
        const maxText = voucherData.max_discount ? formatCurrency(voucherData.max_discount) : 'Tidak ada';
        
        const message = `<b>🎫 BUAT VOUCHER - STEP 4/5</b>

<b>Detail Voucher:</b>
├ Tipe: ${typeText}
├ Nilai: ${valueText}
├ Min Pembelian: ${minText}
└ Maks Discount: ${maxText}

<b>Pengaturan Penggunaan:</b>

1️⃣ <b>Limit Penggunaan</b>
   Berapa kali voucher bisa digunakan
   Contoh: <code>10</code> untuk 10x penggunaan

2️⃣ <b>Expiry Date</b> (Opsional)
   Tanggal kadaluarsa voucher
   Format: DD-MM-YYYY atau kosongkan

<i>Kirim dalam format: <code>limit expiry_date</code>
Contoh: <code>10 31-12-2024</code> untuk 10x penggunaan, expired 31 Des 2024</i>`;

        const keyboard = [
            [
                { text: '1x Usage', callback_data: 'create_voucher_limit_1' },
                { text: '10x Usage', callback_data: 'create_voucher_limit_10' },
                { text: '100x Usage', callback_data: 'create_voucher_limit_100' }
            ],
            [
                { text: '7 Hari', callback_data: 'create_voucher_expiry_7' },
                { text: '30 Hari', callback_data: 'create_voucher_expiry_30' },
                { text: '90 Hari', callback_data: 'create_voucher_expiry_90' }
            ],
            [
                { text: '🔙 Step Sebelumnya', callback_data: 'create_voucher_back_step3' },
                { text: '❌ Batalkan', callback_data: 'owner_voucher_menu' }
            ]
        ];

        await editMessage(chatId, messageId, callbackQueryId, message, {
            reply_markup: { inline_keyboard: keyboard },
            parse_mode: 'HTML'
        });

    } catch (error) {
        console.error('Error showCreateVoucherStep4:', error);
    }
}

async function showCreateVoucherStep5(chatId, userId, messageId, callbackQueryId) {
    try {
        const selection = userSelections.get(userId);
        if (!selection || !selection.voucherData) {
            await editMessage(chatId, messageId, callbackQueryId,
                'Sesi tidak ditemukan. Silakan mulai dari awal.',
                { parse_mode: 'HTML' }
            );
            return;
        }

        const voucherData = selection.voucherData;
        const typeText = voucherData.type === 'percentage' ? 'Persentase' : 'Fixed Amount';
        const valueText = voucherData.type === 'percentage' ? `${voucherData.value}%` : formatCurrency(voucherData.value);
        const minText = voucherData.min_purchase ? formatCurrency(voucherData.min_purchase) : 'Tidak ada';
        const maxText = voucherData.max_discount ? formatCurrency(voucherData.max_discount) : 'Tidak ada';
        const limitText = voucherData.usage_limit || '1';
        const expiryText = voucherData.expiry ? new Date(voucherData.expiry).toLocaleDateString('id-ID') : 'Tidak ada';
        
        const message = `<b>🎫 BUAT VOUCHER - STEP 5/5</b>

<b>Detail Voucher:</b>
├ Tipe: ${typeText}
├ Nilai: ${valueText}
├ Min Pembelian: ${minText}
├ Maks Discount: ${maxText}
├ Limit Penggunaan: ${limitText}x
└ Expired: ${expiryText}

<b>Pengaturan Tambahan:</b>

1️⃣ <b>Kode Voucher</b> (Opsional)
   Kode custom atau biarkan sistem generate

2️⃣ <b>Deskripsi</b> (Opsional)
   Deskripsi untuk voucher

<i>Kirim dalam format: <code>kode deskripsi</code>
Contoh: <code>DISKON50 Diskon 50% spesial</code></i>`;

        const keyboard = [
            [
                { text: '🎲 Random Code', callback_data: 'create_voucher_random_code' },
                { text: '📝 Custom Code', callback_data: 'create_voucher_custom_code' }
            ],
            [
                { text: '✅ Selesai (Tanpa Deskripsi)', callback_data: 'create_voucher_finalize' },
                { text: '📋 Tambah Deskripsi', callback_data: 'create_voucher_add_desc' }
            ],
            [
                { text: '🔙 Step Sebelumnya', callback_data: 'create_voucher_back_step4' },
                { text: '❌ Batalkan', callback_data: 'owner_voucher_menu' }
            ]
        ];

        await editMessage(chatId, messageId, callbackQueryId, message, {
            reply_markup: { inline_keyboard: keyboard },
            parse_mode: 'HTML'
        });

    } catch (error) {
        console.error('Error showCreateVoucherStep5:', error);
    }
}

async function showUserStats(chatId, userId, messageId, callbackQueryId) {
  try {
    if (!owner_ids.includes(userId.toString())) {
      await bot.answerCallbackQuery(callbackQueryId, {
        text: '⛔ Akses Ditolak\nHanya owner yang bisa mengakses menu ini',
        show_alert: true
      });
      return;
    }

    const data = loadData();
    const balances = loadBalances();
    const bannedUsers = loadBannedUsers();
    const transactions = loadTransactions();
    
    const totalUsers = data.users?.length || 0;
    const usersWithBalance = Object.keys(balances).length;
    const activeBans = bannedUsers.filter(u => u.status === 'banned').length;
    
    // Hitung total balance
    const totalBalance = Object.values(balances).reduce((sum, b) => sum + (parseInt(b) || 0), 0);
    const avgBalance = usersWithBalance > 0 ? Math.round(totalBalance / usersWithBalance) : 0;
    
    // Top 5 users by balance
    const topUsers = Object.entries(balances)
      .map(([id, balance]) => ({ 
        id, 
        balance: parseInt(balance) || 0 
      }))
      .sort((a, b) => b.balance - a.balance)
      .slice(0, 5);
    
    let message = `<b>📊 USER STATISTICS</b>\n\n`;
    
    message += `<b>Overview:</b>\n`;
    message += `├ Total Users: ${totalUsers}\n`;
    message += `├ With Balance: ${usersWithBalance}\n`;
    message += `├ Banned Users: ${activeBans}\n`;
    message += `└ Active Rate: ${totalUsers > 0 ? ((usersWithBalance / totalUsers) * 100).toFixed(1) : 0}%\n\n`;
    
    message += `<b>Balance Stats:</b>\n`;
    message += `├ Total: ${formatCurrency(totalBalance)}\n`;
    message += `├ Average: ${formatCurrency(avgBalance)}\n`;
    message += `└ Highest: ${topUsers.length > 0 ? formatCurrency(topUsers[0].balance) : '0'}\n\n`;
    
    if (topUsers.length > 0) {
      message += `<b>Top 5 by Balance:</b>\n`;
      topUsers.forEach((user, index) => {
        const medal = index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : '▫️';
        message += `${medal} <code>${user.id.substring(0, 8)}...</code>: ${formatCurrency(user.balance)}\n`;
      });
      message += `\n`;
    }
    
    message += `<i>Last updated: ${new Date().toLocaleString('id-ID')}</i>`;
    
    const keyboard = [
      [
        { text: '👥 User Manager', callback_data: 'owner_user_manager' },
        { text: '💰 Balance', callback_data: 'owner_balance_manager' }
      ],
      [
        { text: '🚫 Bans', callback_data: 'owner_ban_manager' },
        { text: '🔄 Refresh', callback_data: 'owner_user_stats' }
      ],
      [
        { text: '🔙 Settings', callback_data: 'owner_settings' },
        { text: '🏠 Main', callback_data: 'main_menu' }
      ]
    ];
    
    await editMessage(chatId, messageId, callbackQueryId, message, {
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: keyboard },
      disable_web_page_preview: true
    });

  } catch (error) {
    console.error('Error showUserStats:', error);
  }
}

async function finalizeVoucherCreation(chatId, userId, messageId, callbackQueryId) {
    try {
        const selection = userSelections.get(userId);
        if (!selection || !selection.voucherData) {
            await editMessage(chatId, messageId, callbackQueryId,
                'Sesi tidak ditemukan. Silakan mulai dari awal.',
                { parse_mode: 'HTML' }
            );
            return;
        }

        const voucherData = selection.voucherData;
        
        if (!voucherData.usage_limit) voucherData.usage_limit = 1;
        if (!voucherData.created_by) voucherData.created_by = userId.toString();
        
        const voucher = createVoucher(voucherData);
        
        if (!voucher) {
            await editMessage(chatId, messageId, callbackQueryId,
                'Gagal membuat voucher. Silakan coba lagi.',
                { parse_mode: 'HTML' }
            );
            return;
        }

        userSelections.delete(userId);
        
        const message = `<b>✅ VOUCHER BERHASIL DIBUAT</b>

<b>Detail Voucher:</b>
├ Kode: <code>${voucher.code}</code>
├ Tipe: ${voucher.type === 'percentage' ? 'Persentase' : 'Fixed Amount'}
├ Nilai: ${voucher.type === 'percentage' ? `${voucher.value}%` : formatCurrency(voucher.value)}
├ Min Pembelian: ${voucher.min_purchase ? formatCurrency(voucher.min_purchase) : 'Tidak ada'}
├ Maks Discount: ${voucher.max_discount ? formatCurrency(voucher.max_discount) : 'Tidak ada'}
├ Limit: ${voucher.usage_limit}x
├ Digunakan: 0x
└ Expired: ${voucher.expiry ? new Date(voucher.expiry).toLocaleDateString('id-ID') : 'Tidak ada'}

<b>Status:</b> ✅ Aktif
<b>Dibuat oleh:</b> ${voucher.created_by}
<b>Waktu:</b> ${new Date(voucher.created_at).toLocaleString('id-ID')}

<i>Voucher sudah aktif dan bisa digunakan user</i>`;

        const keyboard = [
            [
                { text: '📋 Lihat Voucher', callback_data: `voucher_detail_${voucher.id}` },
                { text: '➕ Buat Lagi', callback_data: 'voucher_create' }
            ],
            [
                { text: '🎫 Menu Voucher', callback_data: 'owner_voucher_menu' },
                { text: '🏠 Menu Utama', callback_data: 'main_menu' }
            ]
        ];

        await editMessage(chatId, messageId, callbackQueryId, message, {
            reply_markup: { inline_keyboard: keyboard },
            parse_mode: 'HTML'
        });

    } catch (error) {
        console.error('Error finalizeVoucherCreation:', error);
    }
}

async function showVoucherList(chatId, userId, messageId = null, callbackQueryId = null, page = 0) {
    try {
        if (!owner_ids.includes(userId.toString())) {
            if (callbackQueryId) {
                await bot.answerCallbackQuery(callbackQueryId, {
                    text: '⛔ Akses Ditolak\nHanya owner yang bisa mengakses menu ini',
                    show_alert: true
                });
            }
            return;
        }

        const vouchers = loadVouchers();
        const itemsPerPage = 10;
        const totalPages = Math.ceil(vouchers.vouchers.length / itemsPerPage);
        
        if (page < 0) page = 0;
        if (page >= totalPages && totalPages > 0) page = totalPages - 1;
        
        const startIndex = page * itemsPerPage;
        const endIndex = startIndex + itemsPerPage;
        const pageVouchers = vouchers.vouchers.slice(startIndex, endIndex);
        
        let message = `<b>📋 DAFTAR VOUCHER</b>\n\n`;
        message += `<b>Total:</b> ${vouchers.vouchers.length} voucher\n`;
        message += `<b>Aktif:</b> ${getActiveVouchers().length} voucher\n`;
        message += `<b>Halaman:</b> ${page + 1}/${totalPages}\n\n`;
        
        if (pageVouchers.length === 0) {
            message += `<i>Tidak ada voucher ditemukan.</i>`;
        } else {
            pageVouchers.forEach((voucher, index) => {
                const num = startIndex + index + 1;
                const status = voucher.status === 'active' ? '✅' : '❌';
                const value = voucher.type === 'percentage' ? `${voucher.value}%` : formatCurrency(voucher.value);
                
                message += `<b>${num}. ${status} ${voucher.code}</b>\n`;
                message += `├ Tipe: ${voucher.type === 'percentage' ? 'Persentase' : 'Fixed'}\n`;
                message += `├ Nilai: ${value}\n`;
                message += `├ Used: ${voucher.used_count}/${voucher.usage_limit || '∞'}\n`;
                message += `└ Status: ${voucher.status}\n\n`;
            });
        }
        
        const keyboard = [];
        
        pageVouchers.forEach((voucher, index) => {
            const num = startIndex + index + 1;
            keyboard.push([
                { 
                    text: `${num}. ${voucher.code}`, 
                    callback_data: `voucher_detail_${voucher.id}` 
                }
            ]);
        });
        
        const navButtons = [];
        if (totalPages > 1) {
            if (page > 0) {
                navButtons.push({ 
                    text: '◀️ Sebelumnya', 
                    callback_data: `voucher_list_page_${page - 1}` 
                });
            }
            
            navButtons.push({ 
                text: `📄 ${page + 1}/${totalPages}`, 
                callback_data: 'no_action' 
            });
            
            if (page < totalPages - 1) {
                navButtons.push({ 
                    text: '▶️ Berikutnya', 
                    callback_data: `voucher_list_page_${page + 1}` 
                });
            }
            
            if (navButtons.length > 0) {
                keyboard.push(navButtons);
            }
        }
        
        keyboard.push([
            { text: '➕ Buat Voucher', callback_data: 'voucher_create' },
            { text: '🔄 Refresh', callback_data: 'voucher_list' }
        ]);
        
        keyboard.push([
            { text: '🔙 Menu Voucher', callback_data: 'owner_voucher_menu' },
            { text: '🏠 Menu Utama', callback_data: 'main_menu' }
        ]);

        const options = {
            parse_mode: 'HTML',
            reply_markup: { inline_keyboard: keyboard },
            disable_web_page_preview: true
        };

        if (messageId && callbackQueryId) {
            await editMessage(chatId, messageId, callbackQueryId, message, options);
        } else {
            await sendNewMessage(chatId, message, options);
        }

    } catch (error) {
        console.error('Error showVoucherList:', error);
    }
}

async function showVoucherDetail(chatId, userId, voucherId, messageId, callbackQueryId) {
    try {
        if (!owner_ids.includes(userId.toString())) {
            await bot.answerCallbackQuery(callbackQueryId, {
                text: '⛔ Akses Ditolak\nHanya owner yang bisa mengakses menu ini',
                show_alert: true
            });
            return;
        }

        const vouchers = loadVouchers();
        const voucher = vouchers.vouchers.find(v => v.id === voucherId);
        
        if (!voucher) {
            await editMessage(chatId, messageId, callbackQueryId,
                '<b>❌ VOUCHER TIDAK DITEMUKAN</b>\n\nVoucher tidak ditemukan atau sudah dihapus.',
                { parse_mode: 'HTML' }
            );
            return;
        }

        const createdDate = new Date(voucher.created_at).toLocaleString('id-ID');
        const expiryDate = voucher.expiry ? new Date(voucher.expiry).toLocaleDateString('id-ID') : 'Tidak ada';
        const typeText = voucher.type === 'percentage' ? 'Persentase' : 'Fixed Amount';
        const valueText = voucher.type === 'percentage' ? `${voucher.value}%` : formatCurrency(voucher.value);
        const statusText = voucher.status === 'active' ? '✅ Aktif' : '❌ Nonaktif';
        
        let message = `<b>🎫 DETAIL VOUCHER</b>\n\n`;
        message += `<b>Kode:</b> <code>${voucher.code}</code>\n`;
        message += `<b>Tipe:</b> ${typeText}\n`;
        message += `<b>Nilai:</b> ${valueText}\n`;
        message += `<b>Status:</b> ${statusText}\n`;
        message += `<b>Min Pembelian:</b> ${formatCurrency(voucher.min_purchase)}\n`;
        
        if (voucher.max_discount) {
            message += `<b>Maks Discount:</b> ${formatCurrency(voucher.max_discount)}\n`;
        }
        
        message += `<b>Limit Penggunaan:</b> ${voucher.used_count}/${voucher.usage_limit || '∞'}\n`;
        message += `<b>Expired:</b> ${expiryDate}\n`;
        message += `<b>Dibuat oleh:</b> ${voucher.created_by}\n`;
        message += `<b>Tanggal Dibuat:</b> ${createdDate}\n`;
        
        if (voucher.description) {
            message += `<b>Deskripsi:</b> ${voucher.description}\n`;
        }

        const keyboard = [
            [
                { text: '✏️ Edit Voucher', callback_data: `voucher_edit_${voucherId}` },
                { text: '🗑️ Hapus Voucher', callback_data: `voucher_delete_${voucherId}` }
            ],
            [
                { text: '🔄 Aktif/Nonaktif', callback_data: `voucher_toggle_${voucherId}` },
                { text: '📋 List Penggunaan', callback_data: `voucher_usage_${voucherId}` }
            ],
            [
                { text: '🔙 List Voucher', callback_data: 'voucher_list' },
                { text: '🏠 Menu Utama', callback_data: 'main_menu' }
            ]
        ];

        await editMessage(chatId, messageId, callbackQueryId, message, {
            parse_mode: 'HTML',
            reply_markup: { inline_keyboard: keyboard }
        });

    } catch (error) {
        console.error('Error showVoucherDetail:', error);
    }
}

async function confirmDeleteVoucher(chatId, userId, voucherId, messageId, callbackQueryId) {
    try {
        if (!owner_ids.includes(userId.toString())) {
            await bot.answerCallbackQuery(callbackQueryId, {
                text: '⛔ Akses Ditolak\nHanya owner yang bisa mengakses menu ini',
                show_alert: true
            });
            return;
        }

        const vouchers = loadVouchers();
        const voucher = vouchers.vouchers.find(v => v.id === voucherId);
        
        if (!voucher) {
            await editMessage(chatId, messageId, callbackQueryId,
                '<b>❌ VOUCHER TIDAK DITEMUKAN</b>',
                { parse_mode: 'HTML' }
            );
            return;
        }

        // PERBAIKAN: Jangan gunakan 'const message' di sini
        let message = `<b>🗑️ KONFIRMASI HAPUS VOUCHER</b>\n\n`;
        message += `<b>Kode:</b> <code>${voucher.code}</code>\n`;
        message += `<b>Tipe:</b> ${voucher.type === 'percentage' ? 'Persentase' : 'Fixed'}\n`;
        message += `<b>Nilai:</b> ${voucher.type === 'percentage' ? `${voucher.value}%` : formatCurrency(voucher.value)}\n`;
        message += `<b>Status:</b> ${voucher.status}\n\n`;
        message += `<b>⚠️ PERINGATAN:</b>\n`;
        message += `• Voucher akan dihapus PERMANEN\n`;
        message += `• Tidak bisa dikembalikan\n`;
        message += `• History penggunaan tetap tersimpan\n\n`;
        message += `Yakin ingin menghapus voucher ini?`;

        const keyboard = [
            [
                { text: '✅ Ya, Hapus Sekarang', callback_data: `voucher_delete_confirm_${voucherId}` },
                { text: '❌ Batalkan', callback_data: `voucher_detail_${voucherId}` }
            ]
        ];

        await editMessage(chatId, messageId, callbackQueryId, message, {
            parse_mode: 'HTML',
            reply_markup: { inline_keyboard: keyboard }
        });

    } catch (error) {
        console.error('Error confirmDeleteVoucher:', error);
    }
}

async function deleteVoucher(chatId, userId, voucherId, messageId, callbackQueryId) {
    try {
        if (!owner_ids.includes(userId.toString())) {
            await bot.answerCallbackQuery(callbackQueryId, {
                text: '⛔ Akses Ditolak\nHanya owner yang bisa mengakses menu ini',
                show_alert: true
            });
            return;
        }

        const vouchers = loadVouchers();
        const voucherIndex = vouchers.vouchers.findIndex(v => v.id === voucherId);
        
        if (voucherIndex === -1) {
            await editMessage(chatId, messageId, callbackQueryId,
                '<b>❌ VOUCHER TIDAK DITEMUKAN</b>',
                { parse_mode: 'HTML' }
            );
            return;
        }

        const voucher = vouchers.vouchers[voucherIndex];
        vouchers.vouchers.splice(voucherIndex, 1);
        saveVouchers(vouchers);

        // PERBAIKAN: Jangan gunakan 'const message' di sini
        let message = `<b>✅ VOUCHER BERHASIL DIHAPUS</b>\n\n`;
        message += `<b>Kode:</b> <code>${voucher.code}</code>\n`;
        message += `<b>Tipe:</b> ${voucher.type === 'percentage' ? 'Persentase' : 'Fixed'}\n`;
        message += `<b>Nilai:</b> ${voucher.type === 'percentage' ? `${voucher.value}%` : formatCurrency(voucher.value)}\n`;
        message += `<b>Status:</b> Dihapus\n\n`;
        message += `<i>Voucher telah dihapus dari sistem</i>`;

        const keyboard = [
            [
                { text: '📋 List Voucher', callback_data: 'voucher_list' },
                { text: '🎫 Menu Voucher', callback_data: 'owner_voucher_menu' }
            ]
        ];

        await editMessage(chatId, messageId, callbackQueryId, message, {
            parse_mode: 'HTML',
            reply_markup: { inline_keyboard: keyboard }
        });

    } catch (error) {
        console.error('Error deleteVoucher:', error);
    }
}

async function showVoucherStatsDetail(chatId, userId, messageId, callbackQueryId) {
    try {
        if (!owner_ids.includes(userId.toString())) {
            await bot.answerCallbackQuery(callbackQueryId, {
                text: '⛔ Akses Ditolak\nHanya owner yang bisa mengakses menu ini',
                show_alert: true
            });
            return;
        }

        const vouchers = loadVouchers();
        const activeVouchers = getActiveVouchers();
        
        let mostUsedVoucher = null;
        let highestDiscount = 0;
        let mostUsedCount = 0;
        
        vouchers.vouchers.forEach(voucher => {
            if (voucher.used_count > mostUsedCount) {
                mostUsedCount = voucher.used_count;
                mostUsedVoucher = voucher;
            }
        });

        const today = new Date().toISOString().split('T')[0];
        const todayUsed = vouchers.used_vouchers.filter(uv => 
            uv.used_at.split('T')[0] === today
        ).length;

        let message = `<b>📊 DETAIL STATISTIK VOUCHER</b>\n\n`;
        message += `<b>📈 Statistik Umum:</b>\n`;
        message += `├ Total Dibuat: ${vouchers.voucher_stats.total_created}\n`;
        message += `├ Total Digunakan: ${vouchers.voucher_stats.total_used}\n`;
        message += `├ Total Discount: ${formatCurrency(vouchers.voucher_stats.total_discount)}\n`;
        message += `├ Voucher Aktif: ${activeVouchers.length}\n`;
        message += `└ Digunakan Hari Ini: ${todayUsed}\n\n`;
        
        message += `<b>🏆 Voucher Terpopuler:</b>\n`;
        if (mostUsedVoucher) {
            message += `├ Kode: <code>${mostUsedVoucher.code}</code>\n`;
            message += `├ Tipe: ${mostUsedVoucher.type === 'percentage' ? 'Persentase' : 'Fixed'}\n`;
            message += `├ Nilai: ${mostUsedVoucher.type === 'percentage' ? `${mostUsedVoucher.value}%` : formatCurrency(mostUsedVoucher.value)}\n`;
            message += `└ Digunakan: ${mostUsedVoucher.used_count}x\n\n`;
        } else {
            message += `├ <i>Belum ada voucher yang digunakan</i>\n\n`;
        }
        
        message += `<b>📅 Statistik 7 Hari Terakhir:</b>\n`;
        
        for (let i = 6; i >= 0; i--) {
            const date = new Date();
            date.setDate(date.getDate() - i);
            const dateStr = date.toISOString().split('T')[0];
            const dayName = date.toLocaleDateString('id-ID', { weekday: 'short' });
            
            const dayUsed = vouchers.used_vouchers.filter(uv => 
                uv.used_at.split('T')[0] === dateStr
            ).length;
            
            message += `├ ${dayName}: ${dayUsed} penggunaan\n`;
        }
        
        message += `\n<i>Update: ${new Date().toLocaleString('id-ID')}</i>`;

        const keyboard = [
            [
                { text: '🔄 Refresh', callback_data: 'voucher_stats_detail' },
                { text: '📋 Export Data', callback_data: 'voucher_export_stats' }
            ],
            [
                { text: '🔙 Menu Voucher', callback_data: 'owner_voucher_menu' },
                { text: '🏠 Menu Utama', callback_data: 'main_menu' }
            ]
        ];

        await editMessage(chatId, messageId, callbackQueryId, message, {
            parse_mode: 'HTML',
            reply_markup: { inline_keyboard: keyboard }
        });

    } catch (error) {
        console.error('Error showVoucherStatsDetail:', error);
    }
}

// ========================= VOUCHER USER FUNCTIONS =========================

async function showVoucherInput(chatId, userId, operatorId, providerId, price, messageId, callbackQueryId) {
    try {
        const userSelection = userSelections.get(userId);
        if (!userSelection) {
            console.log('User selection not found when showing voucher input');
            return;
        }
        
        const message = `
<b>🎫 Masukkan Kode Voucher</b>

Harga Order: ${formatCurrency(price)}
Layanan: ${userSelection.serviceName}
Negara: ${userSelection.countryName}

<b>Silakan kirim kode voucher:</b>
(Contoh: <code>DISKON50</code>)

<i>Kosongkan atau ketik 0 untuk membatalkan</i>`;
        
        userSelection.voucherInput = {
            operatorId: operatorId,
            providerId: providerId,
            price: price,
            step: 'awaiting_voucher'
        };
        userSelections.set(userId, userSelection);
        
        await editMessage(chatId, messageId, callbackQueryId, message, {
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: '🔙 Kembali', callback_data: `nokos_operator_${operatorId}_${providerId}_${price}` },
                        { text: '🏠 Menu Utama', callback_data: 'main_menu' }
                    ]
                ]
            }
        });
        
    } catch (error) {
        console.error('Error in showVoucherInput:', error);
        await editMessage(chatId, messageId, callbackQueryId,
            '❌ Gagal menampilkan input voucher.',
            { 
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: 'Kembali', callback_data: `nokos_operator_${operatorId}_${providerId}_${price}` }]
                    ]
                }
            }
        );
    }
}

async function resetDatabase(chatId, userId, messageId, callbackQueryId) {
  try {
    if (!owner_ids.includes(userId.toString())) {
      await bot.answerCallbackQuery(callbackQueryId, {
        text: '⛔ Akses Ditolak\nHanya owner yang bisa melakukan reset database',
        show_alert: true
      });
      return;
    }
    
    const backupResult = await autoBackupTransactions('pre_reset', { userId: userId });
    
    // Reset semua file database
    const filesToReset = [
      { name: 'users.json', file: datafile, default: { users: [] } },
      { name: 'balances.json', file: balanceFile, default: {} },
      { name: 'transactions.json', file: transactionsFile, default: { nokos_orders: [], rumahotp_deposits: [], cashify_deposits: [] } },
      { name: 'vouchers.json', file: vouchersFile, default: { vouchers: [], used_vouchers: [], voucher_stats: { total_created: 0, total_used: 0, total_discount: 0 } } },
      { name: 'banned_users.json', file: path.join(dataDir, 'banned_users.json'), default: [] }
    ];
    
    let resetCount = 0;
    for (const fileInfo of filesToReset) {
      try {
        saveJSON(fileInfo.file, fileInfo.default);
        resetCount++;
      } catch (error) {
        console.error(`Failed to reset ${fileInfo.name}:`, error);
      }
    }
    
    // Clear semua cache
    balanceCache.clear();
    userSelections.clear();
    userDepositMessages.clear();
    userPendingCommands.clear();
    orderProcessing.clear();
    depositProcessing.clear();
    sentNotifications.clear();
    userFirstTimeNotifications.clear();
    servicesCache.data = null;
    servicesCache.timestamp = 0;
    voucherCache.clear();
    
    await editMessage(chatId, messageId, callbackQueryId,
      `<b>✅ DATABASE RESET BERHASIL</b>\n\n` +
      `Reset ${resetCount} file database.\n\n` +
      `<b>File yang direset:</b>\n` +
      `• users.json\n` +
      `• balances.json\n` +
      `• transactions.json\n` +
      `• vouchers.json\n` +
      `• banned_users.json\n\n` +
      `<b>Efek:</b>\n` +
      `• Semua user data dihapus\n` +
      `• Saldo user direset ke 0\n` +
      `• Riwayat transaksi dihapus\n` +
      `• Voucher dihapus\n` +
      `• User banned dihapus\n\n` +
      `<i>Backup otomatis telah dibuat sebelum reset</i>`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: '🔄 Reload Bot', callback_data: 'main_menu' }]
          ]
        }
      }
    );
    
  } catch (error) {
    await editMessage(chatId, messageId, callbackQueryId,
      `<b>❌ RESET DATABASE GAGAL</b>\n\n` +
      `Error: ${error.message}\n\n` +
      `Database tidak berubah.`,
      { parse_mode: 'HTML' }
    );
  }
}

async function validateAndApplyVoucher(chatId, userId, operatorId, providerId, price, voucherCode, messageId, callbackQueryId) {
    try {
        const userSelection = userSelections.get(userId);
        if (!userSelection) {
            console.log('User selection not found when applying voucher');
            await editMessage(chatId, messageId, callbackQueryId,
                '❌ Sesi tidak valid. Silakan mulai order dari awal.',
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Kembali ke Menu', callback_data: 'nokos_menu' }]
                        ]
                    }
                }
            );
            return;
        }

        await editMessage(chatId, messageId, callbackQueryId,
            '⏳ Memvalidasi voucher...',
            { parse_mode: 'HTML' }
        );

        // Clean voucher code
        const cleanVoucherCode = voucherCode.trim().toUpperCase();
        
        // Validasi voucher dengan data lengkap
        const validation = validateVoucher(
            cleanVoucherCode, 
            userId, 
            userSelection.serviceId,
            userSelection.numberId,
            Number(price)
        );

        if (!validation.valid) {
            await editMessage(chatId, messageId, callbackQueryId,
                `❌ Voucher tidak valid\n\n${validation.error}\n\nSilakan coba lagi dengan kode yang berbeda.`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [
                                { text: 'Coba Lagi', callback_data: `apply_voucher_${operatorId}_${providerId}_${price}` },
                                { text: '🔙 Tanpa Voucher', callback_data: `nokos_operator_${operatorId}_${providerId}_${price}` }
                            ]
                        ]
                    }
                }
            );
            return;
        }

        // Simpan data voucher yang valid
        userSelection.appliedVoucher = validation;
        userSelections.set(userId, userSelection);

        // Tampilkan konfirmasi order dengan voucher
        await showOrderConfirmationWithVoucher(chatId, userId, operatorId, providerId, price, validation, messageId, callbackQueryId);

    } catch (error) {
        console.error('Error in validateAndApplyVoucher:', error);
        await editMessage(chatId, messageId, callbackQueryId,
            '❌ Gagal memvalidasi voucher. Silakan coba lagi.',
            { 
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: 'Coba Lagi', callback_data: `apply_voucher_${operatorId}_${providerId}_${price}` },
                            { text: '🔙 Kembali', callback_data: `nokos_operator_${operatorId}_${providerId}_${price}` }
                        ]
                    ]
                }
            }
        );
    }
}

// ========================= CS CHAT FUNCTIONS =========================

// Fungsi untuk memulai chat CS
async function startCSChat(chatId, userId, messageId, callbackQueryId) {
    try {
        // Cek apakah sudah ada thread aktif untuk user ini
        let existingThread = null;
        if (global.csChatSessions) {
            for (const [threadId, session] of global.csChatSessions) {
                if (session.userId === userId.toString() && 
                    (session.status === 'active' || session.status === 'pending')) {
                    existingThread = threadId;
                    break;
                }
            }
        }

        if (existingThread) {
            // Jika sudah ada thread aktif, lanjutkan ke thread tersebut
            await joinCSThread(chatId, userId, existingThread, messageId, callbackQueryId);
            return;
        }

        // Dapatkan informasi user
        const user = await bot.getChat(userId).catch(() => ({
            id: userId,
            first_name: 'User',
            username: 'tidak_ada'
        }));

        const threadId = `CS_${userId}_${Date.now()}`;
        
        // Buat session baru
        if (!global.csChatSessions) {
            global.csChatSessions = new Map();
        }

        global.csChatSessions.set(threadId, {
            userId: userId.toString(),
            chatId: chatId,
            userName: user.first_name || 'User',
            userUsername: user.username || 'tidak_ada',
            adminId: null,
            adminName: null,
            status: 'pending', // pending, active, closed
            messages: [],
            createdAt: new Date().toISOString(),
            lastActivity: new Date().toISOString()
        });

        // Kirim notifikasi ke semua CS Admin
        await notifyCSAdminsNewThread(threadId, user);

        // Tampilkan pesan konfirmasi ke user
        const message = `<b>💬 CHAT CS DIMULAI</b>

Halo ${user.first_name || 'User'}! Tim CS kami akan segera merespon.

<b>Status:</b> 🟡 Menunggu CS
<b>Thread ID:</b> <code>${threadId}</code>

Silakan kirim pesan Anda sekarang. CS akan merespon segera.

<i>Ketik /endcs untuk mengakhiri chat</i>`;

        const keyboard = {
            inline_keyboard: [
                [
                    { text: '❌ Batalkan Chat', callback_data: 'cs_cancel_chat' },
                    { text: '📋 Status', callback_data: `cs_status_${threadId}` }
                ],
                [
                    { text: '🏠 Menu Utama', callback_data: 'main_menu' }
                ]
            ]
        };

        await editMessage(chatId, messageId, callbackQueryId, message, {
            parse_mode: 'HTML',
            reply_markup: keyboard
        });

        // Set user session untuk menerima pesan
        const selection = {
            step: 'cs_chat_active',
            threadId: threadId,
            timestamp: Date.now()
        };
        userSelections.set(userId, selection);

    } catch (error) {
        console.error('Error starting CS chat:', error);
        await editMessage(chatId, messageId, callbackQueryId,
            '❌ Gagal memulai chat CS. Silakan coba lagi.',
            { parse_mode: 'HTML' }
        );
    }
}

// Fungsi untuk notifikasi ke CS Admin
async function notifyCSAdminsNewThread(threadId, user) {
    try {
        const csAdmins = config.cs_admins || [];
        const ownerAdmins = config.owner_ids || [];
        
        // Gabungkan semua admin (CS + Owner)
        const allAdmins = [...new Set([...csAdmins, ...ownerAdmins])];
        
        if (allAdmins.length === 0) {
            console.log('No CS admins configured');
            return;
        }

        const message = `<b>🆕 CHAT CS BARU</b>

<b>User:</b> ${user.first_name || 'User'}
<b>Username:</b> @${user.username || 'tidak_ada'}
<b>User ID:</b> <code>${user.id}</code>
<b>Thread ID:</b> <code>${threadId}</code>
<b>Waktu:</b> ${new Date().toLocaleString('id-ID')}

<b>Status:</b> 🟡 Menunggu diambil

Klik tombol di bawah untuk mengambil chat:`;

        const keyboard = {
            inline_keyboard: [
                [
                    { 
                        text: '✅ Ambil Chat', 
                        callback_data: `cs_join_${threadId}` 
                    }
                ],
                [
                    { 
                        text: '📋 Lihat Detail', 
                        callback_data: `cs_view_thread_${threadId}` 
                    }
                ]
            ]
        };

        // Kirim ke semua admin
        for (const adminId of allAdmins) {
            try {
                await bot.sendMessage(adminId, message, {
                    parse_mode: 'HTML',
                    reply_markup: keyboard
                });
            } catch (error) {
                console.error(`Failed to notify admin ${adminId}:`, error);
            }
        }

    } catch (error) {
        console.error('Error notifying CS admins:', error);
    }
}

// Fungsi untuk admin join thread
async function joinCSThread(chatId, userId, threadId, messageId, callbackQueryId) {
    try {
        if (!global.csChatSessions || !global.csChatSessions.has(threadId)) {
            await editMessage(chatId, messageId, callbackQueryId,
                'Thread CS tidak ditemukan atau sudah ditutup.',
                { parse_mode: 'HTML' }
            );
            return;
        }

        const session = global.csChatSessions.get(threadId);
        
        // Cek jika sudah ada admin lain
        if (session.adminId && session.adminId !== userId.toString()) {
            await editMessage(chatId, messageId, callbackQueryId,
                `Thread ini sudah diambil oleh ${session.adminName || 'admin lain'}.`,
                { parse_mode: 'HTML' }
            );
            return;
        }

        // Dapatkan info admin
        const admin = await bot.getChat(userId).catch(() => ({
            id: userId,
            first_name: 'Admin'
        }));

        // Update session
        session.adminId = userId.toString();
        session.adminName = admin.first_name || 'Admin';
        session.status = 'active';
        session.lastActivity = new Date().toISOString();
        global.csChatSessions.set(threadId, session);

        // Kirim notifikasi ke user
        const userMessage = `<b>💬 CS TELAH BERGABUNG</b>

Halo ${session.userName}! 

<b>CS:</b> ${session.adminName}
<b>Thread ID:</b> <code>${threadId}</code>
<b>Status:</b> 🟢 Chat Aktif

Silakan lanjutkan percakapan Anda dengan CS.

<i>Ketik /endcs untuk mengakhiri chat</i>`;

        await bot.sendMessage(session.chatId, userMessage, {
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: '❌ Akhiri Chat', callback_data: 'cs_end_chat_user' }
                    ]
                ]
            }
        });

        // Kirim history chat ke admin
        let historyMessage = `<b>📋 HISTORY CHAT</b>

<b>User:</b> ${session.userName}
<b>Username:</b> @${session.userUsername}
<b>Thread ID:</b> <code>${threadId}</code>
<b>Total Pesan:</b> ${session.messages.length}
<b>Dimulai:</b> ${new Date(session.createdAt).toLocaleString('id-ID')}

<b>Pesan:</b>\n`;

        if (session.messages.length === 0) {
            historyMessage += "\n<i>Belum ada pesan</i>\n";
        } else {
            session.messages.forEach((msg, index) => {
                const time = new Date(msg.timestamp).toLocaleTimeString('id-ID');
                const sender = msg.sender === 'user' ? '👤 User' : '👨‍💼 CS';
                historyMessage += `\n${index + 1}. ${sender} (${time}):\n`;
                
                if (msg.type === 'text') {
                    historyMessage += `   ${msg.content}\n`;
                } else if (msg.type === 'photo') {
                    historyMessage += `   📷 [Foto]\n`;
                } else if (msg.type === 'video') {
                    historyMessage += `   🎥 [Video]\n`;
                } else if (msg.type === 'document') {
                    historyMessage += `   📄 [Dokumen]\n`;
                }
            });
        }

        historyMessage += `\n<b>Anda sekarang sedang chat dengan ${session.userName}.</b>`;

        await editMessage(chatId, messageId, callbackQueryId, historyMessage, {
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: '💬 Balas Pesan', callback_data: `cs_reply_${threadId}` },
                        { text: '❌ Tutup Chat', callback_data: `cs_close_${threadId}` }
                    ]
                ]
            }
        });

        // Set admin session untuk menerima balasan
        const selection = {
            step: 'cs_admin_chat',
            threadId: threadId,
            timestamp: Date.now()
        };
        userSelections.set(userId, selection);

    } catch (error) {
        console.error('Error joining CS thread:', error);
        await editMessage(chatId, messageId, callbackQueryId,
            '❌ Gagal bergabung ke thread CS.',
            { parse_mode: 'HTML' }
        );
    }
}

// Fungsi untuk menangani pesan dari user ke CS
async function handleUserToCSMessage(msg) {
    try {
        const userId = msg.from.id;
        const chatId = msg.chat.id;
        const selection = userSelections.get(userId);

        // Cek jika user sedang dalam sesi CS chat
        if (!selection || selection.step !== 'cs_chat_active') {
            return; // Bukan pesan CS chat
        }

        const threadId = selection.threadId;
        if (!global.csChatSessions || !global.csChatSessions.has(threadId)) {
            await bot.sendMessage(chatId,
                '❌ Sesi chat CS tidak ditemukan. Silakan mulai ulang.',
                { parse_mode: 'HTML' }
            );
            userSelections.delete(userId);
            return;
        }

        const session = global.csChatSessions.get(threadId);
        
        // Update last activity
        session.lastActivity = new Date().toISOString();
        
        let messageData = {
            sender: 'user',
            userId: userId.toString(),
            timestamp: new Date().toISOString()
        };

        // Handle different message types
        if (msg.text) {
            messageData.type = 'text';
            messageData.content = msg.text;
            session.messages.push(messageData);
            
            // Forward ke admin
            await forwardMessageToAdmin(threadId, msg, 'user');

        } else if (msg.photo) {
            messageData.type = 'photo';
            messageData.content = '📷 Foto';
            messageData.file_id = msg.photo[msg.photo.length - 1].file_id;
            messageData.caption = msg.caption || '';
            session.messages.push(messageData);
            
            // Forward ke admin
            await forwardPhotoToAdmin(threadId, msg, 'user');

        } else if (msg.video) {
            messageData.type = 'video';
            messageData.content = '🎥 Video';
            messageData.file_id = msg.video.file_id;
            messageData.caption = msg.caption || '';
            session.messages.push(messageData);
            
            // Forward ke admin
            await forwardVideoToAdmin(threadId, msg, 'user');

        } else if (msg.document) {
            messageData.type = 'document';
            messageData.content = '📄 Dokumen';
            messageData.file_id = msg.document.file_id;
            messageData.file_name = msg.document.file_name;
            session.messages.push(messageData);
            
            // Forward ke admin
            await forwardDocumentToAdmin(threadId, msg, 'user');

        } else {
            // Unsupported message type
            await bot.sendMessage(chatId,
                '❌ Jenis pesan tidak didukung dalam chat CS.',
                { parse_mode: 'HTML' }
            );
            return;
        }

        // Simpan session
        global.csChatSessions.set(threadId, session);

        // Konfirmasi ke user
        await bot.sendMessage(chatId,
            '✅ Pesan telah dikirim ke CS.',
            { parse_mode: 'HTML' }
        );

    } catch (error) {
        console.error('Error handling user to CS message:', error);
        await bot.sendMessage(msg.chat.id,
            '❌ Gagal mengirim pesan ke CS.',
            { parse_mode: 'HTML' }
        );
    }
}

// Fungsi untuk menangani pesan dari CS ke user
async function handleCSToUserMessage(msg) {
    try {
        const adminId = msg.from.id;
        const selection = userSelections.get(adminId);

        // Cek jika admin sedang dalam sesi CS chat
        if (!selection || selection.step !== 'cs_admin_chat') {
            return; // Bukan pesan balasan CS
        }

        const threadId = selection.threadId;
        if (!global.csChatSessions || !global.csChatSessions.has(threadId)) {
            await bot.sendMessage(msg.chat.id,
                '❌ Thread CS tidak ditemukan.',
                { parse_mode: 'HTML' }
            );
            userSelections.delete(adminId);
            return;
        }

        const session = global.csChatSessions.get(threadId);
        
        // Cek jika admin yang sesuai
        if (session.adminId !== adminId.toString()) {
            await bot.sendMessage(msg.chat.id,
                '❌ Anda bukan admin yang menangani chat ini.',
                { parse_mode: 'HTML' }
            );
            return;
        }

        // Update last activity
        session.lastActivity = new Date().toISOString();
        
        let messageData = {
            sender: 'admin',
            userId: adminId.toString(),
            adminName: session.adminName,
            timestamp: new Date().toISOString()
        };

        // Handle different message types
        if (msg.text) {
            messageData.type = 'text';
            messageData.content = msg.text;
            session.messages.push(messageData);
            
            // Forward ke user
            await forwardMessageToUser(threadId, msg, 'admin');

        } else if (msg.photo) {
            messageData.type = 'photo';
            messageData.content = '📷 Foto dari CS';
            messageData.file_id = msg.photo[msg.photo.length - 1].file_id;
            messageData.caption = msg.caption || '';
            session.messages.push(messageData);
            
            // Forward ke user
            await forwardPhotoToUser(threadId, msg, 'admin');

        } else if (msg.video) {
            messageData.type = 'video';
            messageData.content = '🎥 Video dari CS';
            messageData.file_id = msg.video.file_id;
            messageData.caption = msg.caption || '';
            session.messages.push(messageData);
            
            // Forward ke user
            await forwardVideoToUser(threadId, msg, 'admin');

        } else if (msg.document) {
            messageData.type = 'document';
            messageData.content = '📄 Dokumen dari CS';
            messageData.file_id = msg.document.file_id;
            messageData.file_name = msg.document.file_name;
            session.messages.push(messageData);
            
            // Forward ke user
            await forwardDocumentToUser(threadId, msg, 'admin');

        } else {
            // Unsupported message type
            await bot.sendMessage(msg.chat.id,
                '❌ Jenis pesan tidak didukung.',
                { parse_mode: 'HTML' }
            );
            return;
        }

        // Simpan session
        global.csChatSessions.set(threadId, session);

        // Konfirmasi ke admin
        await bot.sendMessage(msg.chat.id,
            '✅ Pesan telah dikirim ke user.',
            { parse_mode: 'HTML' }
        );

    } catch (error) {
        console.error('Error handling CS to user message:', error);
        await bot.sendMessage(msg.chat.id,
            '❌ Gagal mengirim pesan ke user.',
            { parse_mode: 'HTML' }
        );
    }
}

// Fungsi untuk forward pesan text
async function forwardMessageToAdmin(threadId, msg, senderType) {
    const session = global.csChatSessions.get(threadId);
    if (!session || !session.adminId) return;

    const sender = senderType === 'user' ? '👤 User' : '👨‍💼 CS';
    const time = new Date().toLocaleTimeString('id-ID');
    
    const message = `<b>${sender}</b> (${time})
    
${msg.text}

<i>Thread: ${threadId}</i>`;

    await bot.sendMessage(session.adminId, message, {
        parse_mode: 'HTML',
        reply_markup: {
            inline_keyboard: [
                [
                    { text: '💬 Balas', callback_data: `cs_reply_${threadId}` },
                    { text: '❌ Tutup', callback_data: `cs_close_${threadId}` }
                ]
            ]
        }
    });
}

async function forwardMessageToUser(threadId, msg, senderType) {
    const session = global.csChatSessions.get(threadId);
    if (!session) return;

    const sender = senderType === 'admin' ? '👨‍💼 CS' : '👤 User';
    const time = new Date().toLocaleTimeString('id-ID');
    
    const message = `<b>${sender}</b> (${time})
    
${msg.text}

<i>Thread: ${threadId}</i>`;

    await bot.sendMessage(session.chatId, message, {
        parse_mode: 'HTML',
        reply_markup: {
            inline_keyboard: [
                [
                    { text: '❌ Akhiri Chat', callback_data: 'cs_end_chat_user' }
                ]
            ]
        }
    });
}

// Fungsi untuk forward foto
async function forwardPhotoToAdmin(threadId, msg, senderType) {
    const session = global.csChatSessions.get(threadId);
    if (!session || !session.adminId) return;

    const sender = senderType === 'user' ? '👤 User' : '👨‍💼 CS';
    const time = new Date().toLocaleTimeString('id-ID');
    const caption = msg.caption || '';
    
    const photoCaption = `<b>${sender}</b> (${time}) mengirim foto
    
${caption}

<i>Thread: ${threadId}</i>`;

    const photo = msg.photo[msg.photo.length - 1];
    
    await bot.sendPhoto(session.adminId, photo.file_id, {
        caption: photoCaption,
        parse_mode: 'HTML',
        reply_markup: {
            inline_keyboard: [
                [
                    { text: '💬 Balas', callback_data: `cs_reply_${threadId}` },
                    { text: '❌ Tutup', callback_data: `cs_close_${threadId}` }
                ]
            ]
        }
    });
}

async function forwardPhotoToUser(threadId, msg, senderType) {
    const session = global.csChatSessions.get(threadId);
    if (!session) return;

    const sender = senderType === 'admin' ? '👨‍💼 CS' : '👤 User';
    const time = new Date().toLocaleTimeString('id-ID');
    const caption = msg.caption || '';
    
    const photoCaption = `<b>${sender}</b> (${time}) mengirim foto
    
${caption}

<i>Thread: ${threadId}</i>`;

    const photo = msg.photo[msg.photo.length - 1];
    
    await bot.sendPhoto(session.chatId, photo.file_id, {
        caption: photoCaption,
        parse_mode: 'HTML',
        reply_markup: {
            inline_keyboard: [
                [
                    { text: '❌ Akhiri Chat', callback_data: 'cs_end_chat_user' }
                ]
            ]
        }
    });
}

// Fungsi untuk forward video
async function forwardVideoToAdmin(threadId, msg, senderType) {
    const session = global.csChatSessions.get(threadId);
    if (!session || !session.adminId) return;

    const sender = senderType === 'user' ? '👤 User' : '👨‍💼 CS';
    const time = new Date().toLocaleTimeString('id-ID');
    const caption = msg.caption || '';
    
    const videoCaption = `<b>${sender}</b> (${time}) mengirim video
    
${caption}

<i>Thread: ${threadId}</i>`;

    await bot.sendVideo(session.adminId, msg.video.file_id, {
        caption: videoCaption,
        parse_mode: 'HTML',
        reply_markup: {
            inline_keyboard: [
                [
                    { text: '💬 Balas', callback_data: `cs_reply_${threadId}` },
                    { text: '❌ Tutup', callback_data: `cs_close_${threadId}` }
                ]
            ]
        }
    });
}

async function forwardVideoToUser(threadId, msg, senderType) {
    const session = global.csChatSessions.get(threadId);
    if (!session) return;

    const sender = senderType === 'admin' ? '👨‍💼 CS' : '👤 User';
    const time = new Date().toLocaleTimeString('id-ID');
    const caption = msg.caption || '';
    
    const videoCaption = `<b>${sender}</b> (${time}) mengirim video
    
${caption}

<i>Thread: ${threadId}</i>`;

    await bot.sendVideo(session.chatId, msg.video.file_id, {
        caption: videoCaption,
        parse_mode: 'HTML',
        reply_markup: {
            inline_keyboard: [
                [
                    { text: '❌ Akhiri Chat', callback_data: 'cs_end_chat_user' }
                ]
            ]
        }
    });
}

// Fungsi untuk forward dokumen
async function forwardDocumentToAdmin(threadId, msg, senderType) {
    const session = global.csChatSessions.get(threadId);
    if (!session || !session.adminId) return;

    const sender = senderType === 'user' ? '👤 User' : '👨‍💼 CS';
    const time = new Date().toLocaleTimeString('id-ID');
    
    const docCaption = `<b>${sender}</b> (${time}) mengirim dokumen
    
${msg.document.file_name}

<i>Thread: ${threadId}</i>`;

    await bot.sendDocument(session.adminId, msg.document.file_id, {
        caption: docCaption,
        parse_mode: 'HTML',
        reply_markup: {
            inline_keyboard: [
                [
                    { text: '💬 Balas', callback_data: `cs_reply_${threadId}` },
                    { text: '❌ Tutup', callback_data: `cs_close_${threadId}` }
                ]
            ]
        }
    });
}

async function forwardDocumentToUser(threadId, msg, senderType) {
    const session = global.csChatSessions.get(threadId);
    if (!session) return;

    const sender = senderType === 'admin' ? '👨‍💼 CS' : '👤 User';
    const time = new Date().toLocaleTimeString('id-ID');
    
    const docCaption = `<b>${sender}</b> (${time}) mengirim dokumen
    
${msg.document.file_name}

<i>Thread: ${threadId}</i>`;

    await bot.sendDocument(session.chatId, msg.document.file_id, {
        caption: docCaption,
        parse_mode: 'HTML',
        reply_markup: {
            inline_keyboard: [
                [
                    { text: '❌ Akhiri Chat', callback_data: 'cs_end_chat_user' }
                ]
            ]
        }
    });
}

// Fungsi untuk mengakhiri chat
async function endCSChat(chatId, userId, messageId, callbackQueryId, forceClose = false) {
    try {
        const selection = userSelections.get(userId);
        if (!selection) {
            await editMessage(chatId, messageId, callbackQueryId,
                '❌ Tidak ada sesi chat aktif.',
                { parse_mode: 'HTML' }
            );
            return;
        }

        const threadId = selection.threadId;
        if (!global.csChatSessions || !global.csChatSessions.has(threadId)) {
            await editMessage(chatId, messageId, callbackQueryId,
                '❌ Thread chat tidak ditemukan.',
                { parse_mode: 'HTML' }
            );
            userSelections.delete(userId);
            return;
        }

        const session = global.csChatSessions.get(threadId);
        
        // Update status
        session.status = 'closed';
        session.closedAt = new Date().toISOString();
        session.closedBy = userId.toString();
        global.csChatSessions.set(threadId, session);

        // Hapus user selection
        userSelections.delete(userId);

        // Beri tahu semua pihak
        if (session.adminId) {
            // Beri tahu admin
            await bot.sendMessage(session.adminId,
                `❌ CHAT DITUTUP\n\nThread: ${threadId}\nDitutup oleh: ${forceClose ? 'Sistem' : 'User'}\nWaktu: ${new Date().toLocaleString('id-ID')}`,
                { parse_mode: 'HTML' }
            );
        }

        // Beri tahu user
        await sendNewMessage(session.chatId,
            `❌ CHAT CS DITUTUP\n\nTerima kasih telah menghubungi CS.\nThread: ${threadId}\nTotal pesan: ${session.messages.length}\nWaktu: ${new Date().toLocaleString('id-ID')}`,
            { 
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '💬 Chat CS Baru', callback_data: 'cs_chat' },
                            { text: '🏠 Menu Utama', callback_data: 'main_menu' }
                        ]
                    ]
                }
            }
        );

        // Jika ini dari callback, edit pesan
        if (messageId && callbackQueryId) {
            await editMessage(chatId, messageId, callbackQueryId,
                '✅ Chat CS telah ditutup.',
                { parse_mode: 'HTML' }
            );
        }

    } catch (error) {
        console.error('Error ending CS chat:', error);
        if (messageId && callbackQueryId) {
            await editMessage(chatId, messageId, callbackQueryId,
                '❌ Gagal menutup chat.',
                { parse_mode: 'HTML' }
            );
        }
    }
}

// Fungsi untuk menampilkan status chat
async function showCSStatus(chatId, userId, threadId, messageId, callbackQueryId) {
    try {
        if (!global.csChatSessions || !global.csChatSessions.has(threadId)) {
            await editMessage(chatId, messageId, callbackQueryId,
                '❌ Thread tidak ditemukan.',
                { parse_mode: 'HTML' }
            );
            return;
        }

        const session = global.csChatSessions.get(threadId);
        const lastActivity = new Date(session.lastActivity);
        const now = new Date();
        const diffMinutes = Math.floor((now - lastActivity) / (1000 * 60));

        let statusEmoji = '🟡';
        if (session.status === 'active') statusEmoji = '🟢';
        if (session.status === 'closed') statusEmoji = '🔴';

        const message = `<b>📊 STATUS CHAT CS</b>

<b>Thread ID:</b> <code>${threadId}</b>
<b>User:</b> ${session.userName} (@${session.userUsername})
<b>Admin:</b> ${session.adminName || 'Belum ada'}
<b>Status:</b> ${statusEmoji} ${session.status.toUpperCase()}
<b>Pesan:</b> ${session.messages.length} pesan
<b>Dimulai:</b> ${new Date(session.createdAt).toLocaleString('id-ID')}
<b>Aktivitas terakhir:</b> ${diffMinutes} menit lalu

${session.status === 'active' ? 
    '💬 Chat sedang berlangsung...' : 
    '❌ Chat sudah ditutup'}`;

        const keyboard = {
            inline_keyboard: []
        };

        if (session.status === 'active') {
            keyboard.inline_keyboard.push([
                { text: '💬 Lanjut Chat', callback_data: `cs_reply_${threadId}` },
                { text: '❌ Tutup Chat', callback_data: `cs_close_${threadId}` }
            ]);
        }

        keyboard.inline_keyboard.push([
            { text: '🔄 Refresh', callback_data: `cs_status_${threadId}` },
            { text: '🏠 Menu Utama', callback_data: 'main_menu' }
        ]);

        await editMessage(chatId, messageId, callbackQueryId, message, {
            parse_mode: 'HTML',
            reply_markup: keyboard
        });

    } catch (error) {
        console.error('Error showing CS status:', error);
        await editMessage(chatId, messageId, callbackQueryId,
            '❌ Gagal menampilkan status.',
            { parse_mode: 'HTML' }
        );
    }
}

// Fungsi untuk reply prompt
async function promptCSReply(chatId, userId, threadId, messageId, callbackQueryId) {
    try {
        if (!global.csChatSessions || !global.csChatSessions.has(threadId)) {
            await editMessage(chatId, messageId, callbackQueryId,
                '❌ Thread tidak ditemukan.',
                { parse_mode: 'HTML' }
            );
            return;
        }

        const session = global.csChatSessions.get(threadId);
        
        // Cek jika admin yang sesuai
        if (session.adminId !== userId.toString()) {
            await editMessage(chatId, messageId, callbackQueryId,
                '❌ Anda bukan admin yang menangani chat ini.',
                { parse_mode: 'HTML' }
            );
            return;
        }

        // Set session untuk menerima balasan
        const selection = {
            step: 'cs_admin_chat',
            threadId: threadId,
            timestamp: Date.now()
        };
        userSelections.set(userId, selection);

        await editMessage(chatId, messageId, callbackQueryId,
            `💬 <b>MODE BALAS PESAN</b>\n\nThread: <code>${threadId}</code>\nUser: ${session.userName}\n\nKetik pesan Anda sekarang (text, foto, atau video). Pesan akan langsung dikirim ke user.\n\nKetik /cancel untuk keluar mode balas.`,
            { parse_mode: 'HTML' }
        );

    } catch (error) {
        console.error('Error prompting CS reply:', error);
        await editMessage(chatId, messageId, callbackQueryId,
            '❌ Gagal masuk mode balas.',
            { parse_mode: 'HTML' }
        );
    }
}

// ========================= MAIN MENU FUNCTIONS =========================

async function showMainMenu(chatId, userId, user, messageId = null, callbackQueryId = null) {
  try {
  
    if (isUserBanned(userId.toString())) {
      await sendNewMessage(chatId, 
        `<b>⛔ AKSES DIBLOKIR</b>\n\n` +
        `User ID: <code>${userId}</code>\n` +
        `Status: <b>DIBANNED</b>\n\n` +
        `Akses Anda ke bot telah diblokir.\n` +
        `Hubungi admin untuk informasi lebih lanjut.`,
        { parse_mode: 'HTML' }
      );
      return;
    }
    // Clear user selections
    userSelections.delete(userId);
    
    // Clear balance cache untuk memastikan data fresh
    balanceCache.delete(userId.toString());
    
    // Load data yang diperlukan
    const userBalance = getUserBalance(userId);
    const data = loadData();
    const transactions = loadTransactions();
    
    // Hitung statistik
    const totalUsers = data.users?.length || 0;
    
    // Hitung order sukses
    const successfulOrders = transactions.nokos_orders?.filter(order => {
        if (order.status === 'completed' || order.data?.status === 'completed') {
            return true;
        }
        if (order.data?.otp_code && 
            order.data.otp_code !== '-' && 
            order.data.otp_code !== '' &&
            order.data.otp_code !== null) {
            return true;
        }
        if (order.data?.otp_received === true) {
            return true;
        }
        return false;
    }) || [];
    
    // Hitung deposit sukses
    const successfulCashifyDeposits = transactions.cashify_deposits?.filter(deposit => 
        deposit.status === 'success' || deposit.status === 'paid'
    ) || [];
    
    const successfulRumahotpDeposits = transactions.rumahotp_deposits?.filter(deposit => 
        deposit.status === 'success' || deposit.status === 'paid'
    ) || [];
    
    const totalOrders = successfulOrders.length;
    const cashifyDeposits = successfulCashifyDeposits.length; 
    const rumahotpDeposits = successfulRumahotpDeposits.length;
    const totalDeposits = cashifyDeposits + rumahotpDeposits;
    
    // User info
    const username = user.username ? `@${user.username}` : 'tidak ada';
    const firstName = user.first_name || 'User';
    
    // Cek apakah user sedang dalam chat CS
    let csStatus = '';
    if (global.csChatSessions) {
        for (const [threadId, session] of global.csChatSessions) {
            if (session.userId === userId.toString() && 
                (session.status === 'active' || session.status === 'pending')) {
                csStatus = `(ID: <code>${threadId}</code>)`;
                break;
            }
        }
    }

    // Buat pesan utama
    const message = `
<blockquote><b>🛍️ ANDIN STORE</b>

<b>Selamat Datang ${firstName}!</b>
<i>Tempat terbaik untuk layanan OTP</i>

<b>Profil Anda</b>
┌ ID: <code>${userId}</code>
├ Username: ${username}
├ Status: Aktif
└ Saldo: <b>${formatCurrency(userBalance)}</b>

<b>Statistik Bot</b>
┌ Total User: ${totalUsers}
├ Order Sukses: ${totalOrders} 
└ Deposit Sukses: ${totalDeposits}

💬 <b>Chat CS Aktif:</b> ${csStatus}

<b>Pilih menu dibawah:</b></blockquote>`;

    // Buat keyboard/menu
    const keyboard = [
        [
            { text: '📱 Beli Nokos', callback_data: 'nokos_menu' },
            { text: '💰 Topup Saldo', callback_data: 'deposit_main' }
        ],
        [
            { text: '📋 Riwayat Order', callback_data: 'order_history' },
            { text: '💳 Riwayat Deposit', callback_data: 'deposit_history' }
        ],
        [
            { 
                text: '💬 Chat CS', 
                callback_data: 'cs_chat' 
            },
            { 
                text: '📢 Channel', 
                url: `https://t.me/${channel.replace('@', '')}` 
            }
        ]
    ];

    // Tambahkan Owner Menu jika user adalah owner
    if (owner_ids.includes(userId.toString())) {
        keyboard.push([
            { 
                text: '⚙️ Owner Menu', 
                callback_data: 'owner_menu' 
            }
        ]);
    }

    // Tambahkan CS Admin Menu jika user adalah CS admin
    if (config.cs_admins?.includes(userId.toString())) {
        keyboard.push([
            { 
                text: '👨‍💼 CS Panel', 
                callback_data: 'owner_cs_menu' 
            }
        ]);
    }

    // Options untuk message
    const options = {
        reply_markup: { inline_keyboard: keyboard },
        parse_mode: 'HTML',
        disable_web_page_preview: true
    };

    // Edit message atau kirim message baru
    if (messageId && callbackQueryId) {
        await editMessage(chatId, messageId, callbackQueryId, message, options);
    } else if (messageId) {
        await editMessage(chatId, messageId, null, message, options);
    } else {
        await sendNewMessage(chatId, message, options);
    }
    
  } catch (error) {
    console.error('Error in showMainMenu:', error);
    
    // Fallback message jika error
    const errorMessage = `
<b>🛍️ ANDIN STORE</b>

Selamat Datang! Terjadi kesalahan saat memuat data.
Silakan coba lagi.

<b>Menu Utama:</b>`;
    
    const fallbackKeyboard = [
        [
            { text: '📱 Beli Nokos', callback_data: 'nokos_menu' },
            { text: '💰 Topup Saldo', callback_data: 'deposit_main' }
        ],
        [
            { text: '💬 Chat CS', callback_data: 'cs_chat' }
        ],
        [
            { text: '🔄 Refresh', callback_data: 'main_menu' }
        ]
    ];
    
    try {
        if (messageId && callbackQueryId) {
            await editMessage(chatId, messageId, callbackQueryId, errorMessage, {
                reply_markup: { inline_keyboard: fallbackKeyboard },
                parse_mode: 'HTML'
            });
        } else {
            await sendNewMessage(chatId, errorMessage, {
                reply_markup: { inline_keyboard: fallbackKeyboard },
                parse_mode: 'HTML'
            });
        }
    } catch (fallbackError) {
        console.error('Fallback error in showMainMenu:', fallbackError);
        }
    }
}

async function showOwnerSettings(chatId, userId, messageId, callbackQueryId) {
  try {
    if (!owner_ids.includes(userId.toString())) {
      await bot.answerCallbackQuery(callbackQueryId, {
        text: '⛔ Akses Ditolak\nHanya owner yang bisa mengakses menu ini',
        show_alert: true
      });
      return;
    }

    // Hitung statistik user
    const data = loadData();
    const balances = loadBalances();
    const bannedUsers = loadBannedUsers();
    
    const totalUsers = data.users?.length || 0;
    const usersWithBalance = Object.keys(balances).filter(id => {
      const balance = parseInt(balances[id]) || 0;
      return balance > 0;
    }).length;
    
    const totalBalance = Object.values(balances).reduce((sum, balance) => 
      sum + (parseInt(balance) || 0), 0
    );
    
    const activeBans = bannedUsers.filter(user => user.status === 'banned').length;

    const message = `<b>⚙️ OWNER SETTINGS</b>

<b>📊 Quick Stats:</b>
├ Total Users: ${totalUsers}
├ Active Balance: ${formatCurrency(totalBalance)}
└ Banned Users: ${activeBans}

<b>📋 User Management:</b>
• View & manage all users
• Balance operations
• Ban/Unban users
• User activity history

<b>⚡ Quick Actions:</b>
• Add/Remove admin
• CS management
• Database operations

<i>Select management menu:</i>`;

    const keyboard = [
      [
        { text: '👥 User Manager', callback_data: 'owner_user_manager' },
        { text: '💰 Balance', callback_data: 'owner_balance_manager' }
      ],
      [
        { text: '🚫 Ban Control', callback_data: 'owner_ban_manager' },
        { text: '📊 Stats', callback_data: 'owner_user_stats' }
      ],
      [
        { text: '👥 Admins', callback_data: 'owner_admin_menu' },
        { text: '💬 CS', callback_data: 'owner_cs_menu' }
      ],
      [
        { text: '💾 Database', callback_data: 'owner_database' },
        { text: '🔄 Backup', callback_data: 'restore_menu' }
      ],
      [
        { text: '🔙 Owner Menu', callback_data: 'owner_menu' },
        { text: '🏠 Main Menu', callback_data: 'main_menu' }
      ]
    ];

    await editMessage(chatId, messageId, callbackQueryId, message, {
      reply_markup: { inline_keyboard: keyboard },
      parse_mode: 'HTML'
    });

  } catch (error) {
    console.error('Error showOwnerSettings:', error);
    await editMessage(chatId, messageId, callbackQueryId,
      '❌ Gagal memuat menu settings.\n\nSilakan coba lagi.',
      { parse_mode: 'HTML' }
    );
  }
}

async function showUserManager(chatId, userId, messageId, callbackQueryId, page = 0) {
  try {
    if (!owner_ids.includes(userId.toString())) {
      await bot.answerCallbackQuery(callbackQueryId, {
        text: '⛔ Akses Ditolak\nHanya owner yang bisa mengakses menu ini',
        show_alert: true
      });
      return;
    }

    const data = loadData();
    const balances = loadBalances();
    const bannedUsers = loadBannedUsers();
    
    const users = data.users || [];
    const itemsPerPage = 8;
    const totalPages = Math.ceil(users.length / itemsPerPage);
    
    if (page < 0) page = 0;
    if (page >= totalPages && totalPages > 0) page = totalPages - 1;
    
    const startIndex = page * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const pageUsers = users.slice(startIndex, endIndex);
    
    let message = `<b>👥 USER MANAGER</b>\n\n`;
    message += `<b>Page:</b> ${page + 1}/${totalPages}\n`;
    message += `<b>Total Users:</b> ${users.length}\n\n`;
    
    if (pageUsers.length === 0) {
      message += `<i>No users found</i>\n`;
    } else {
      message += `<b>User List:</b>\n\n`;
      
      for (let i = 0; i < pageUsers.length; i++) {
        const user = pageUsers[i];
        const balance = parseInt(balances[user]) || 0;
        const isBanned = bannedUsers.some(bu => bu.userId === user && bu.status === 'banned');
        const isOwner = owner_ids.includes(user);
        
        const userNum = startIndex + i + 1;
        
        message += `<b>${userNum}. User ${user.substring(0, 6)}...</b>\n`;
        message += `├ Balance: ${formatCurrency(balance)}\n`;
        message += `└ Status: ${isBanned ? '🚫 Banned' : (isOwner ? '👑 Owner' : '✅ Active')}\n\n`;
      }
    }
    
    const keyboard = [];
    
    // User list buttons
    pageUsers.forEach((user, index) => {
      const userNum = startIndex + index + 1;
      const balance = parseInt(balances[user]) || 0;
      const isBanned = bannedUsers.some(bu => bu.userId === user && bu.status === 'banned');
      
      let buttonText = `${userNum}. `;
      if (isBanned) buttonText += '🚫 ';
      buttonText += `${user.substring(0, 6)}...`;
      if (balance > 0) buttonText += ` (${formatCurrency(balance).replace('Rp', '')})`;
      
      keyboard.push([
        { 
          text: buttonText, 
          callback_data: `user_manage_${user}` 
        }
      ]);
    });
    
    // Navigation buttons
    const navButtons = [];
    if (totalPages > 1) {
      if (page > 0) {
        navButtons.push({ 
          text: '◀️ Prev', 
          callback_data: `user_manager_page_${page - 1}` 
        });
      }
      
      navButtons.push({ 
        text: `📄 ${page + 1}/${totalPages}`, 
        callback_data: 'no_action' 
      });
      
      if (page < totalPages - 1) {
        navButtons.push({ 
          text: '▶️ Next', 
          callback_data: `user_manager_page_${page + 1}` 
        });
      }
      
      if (navButtons.length > 0) {
        keyboard.push(navButtons);
      }
    }
    
    // Quick actions row
    keyboard.push([
      { text: '🔍 Search User', callback_data: 'search_user_quick' },
      { text: '🔄 Refresh', callback_data: `user_manager_page_${page}` }
    ]);
    
    // Navigation row
    keyboard.push([
      { text: '🔙 Settings', callback_data: 'owner_settings' },
      { text: '🏠 Main', callback_data: 'main_menu' }
    ]);
    
    await editMessage(chatId, messageId, callbackQueryId, message, {
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: keyboard },
      disable_web_page_preview: true
    });

  } catch (error) {
    console.error('Error showUserManager:', error);
  }
}

async function showUserManageDetail(chatId, userId, targetUserId, messageId, callbackQueryId) {
  try {
    if (!owner_ids.includes(userId.toString())) {
      await bot.answerCallbackQuery(callbackQueryId, {
        text: '⛔ Akses Ditolak\nHanya owner yang bisa mengakses menu ini',
        show_alert: true
      });
      return;
    }
    
    // Load semua data
    const balances = loadBalances();
    const bannedUsers = loadBannedUsers();
    const transactions = loadTransactions();
    const data = loadData();
    
    const userBalance = parseInt(balances[targetUserId]) || 0;
    const isBanned = bannedUsers.some(bu => bu.userId === targetUserId && bu.status === 'banned');
    const isOwner = owner_ids.includes(targetUserId);
    const isInSystem = data.users?.includes(targetUserId) || false;
    
    // Hitung statistik user
    const userOrders = transactions.nokos_orders?.filter(order => 
      order.userId === targetUserId
    ) || [];
    
    const successfulOrders = userOrders.filter(order => 
      order.status === 'completed' || 
      order.data?.status === 'completed' ||
      order.data?.otp_received === true
    ).length;
    
    const totalOrderValue = userOrders.reduce((sum, order) => 
      sum + (parseInt(order.data?.price || order.data?.finalPrice || 0) || 0), 0
    );
    
    const userDeposits = [
      ...(transactions.cashify_deposits?.filter(deposit => 
        deposit.userId === targetUserId && 
        (deposit.status === 'success' || deposit.status === 'paid')
      ) || []),
      ...(transactions.rumahotp_deposits?.filter(deposit => 
        deposit.userId === targetUserId && 
        (deposit.status === 'success' || deposit.status === 'paid')
      ) || [])
    ];
    
    const totalDeposit = userDeposits.reduce((sum, deposit) => 
      sum + (parseInt(deposit.data?.amount || deposit.data?.total || 0) || 0), 0
    );
    
    const lastOrder = userOrders.length > 0 ? 
      new Date(userOrders[userOrders.length - 1].timestamp).toLocaleString('id-ID') : 
      'Belum pernah';
    
    const lastDeposit = userDeposits.length > 0 ? 
      new Date(userDeposits[userDeposits.length - 1].timestamp).toLocaleString('id-ID') : 
      'Belum pernah';
    
    // Coba dapatkan info user dari Telegram
    let userInfo = {};
    try {
      const chat = await bot.getChat(targetUserId);
      userInfo = {
        firstName: chat.first_name || 'Tidak diketahui',
        lastName: chat.last_name || '',
        username: chat.username ? `@${chat.username}` : 'Tidak ada',
        isBot: chat.is_bot || false,
        languageCode: chat.language_code || 'id'
      };
    } catch (error) {
      userInfo = {
        firstName: 'Tidak diketahui',
        lastName: '',
        username: 'Tidak ada',
        isBot: false,
        languageCode: 'id'
      };
    }
    
    // Format message
    let message = `<b>👤 USER MANAGEMENT</b>\n\n`;
    
    message += `<b>📋 User Information:</b>\n`;
    message += `├ ID: <code>${targetUserId}</code>\n`;
    message += `├ Name: ${userInfo.firstName} ${userInfo.lastName}\n`;
    message += `├ Username: ${userInfo.username}\n`;
    message += `├ Language: ${userInfo.languageCode.toUpperCase()}\n`;
    message += `├ Bot: ${userInfo.isBot ? '✅ Yes' : '❌ No'}\n`;
    message += `├ Status: ${isBanned ? '🚫 Banned' : (isOwner ? '👑 Owner' : '✅ Active')}\n`;
    message += `└ In System: ${isInSystem ? '✅ Yes' : '❌ No'}\n\n`;
    
    message += `<b>💰 Balance Information:</b>\n`;
    message += `├ Current Balance: ${formatCurrency(userBalance)}\n`;
    message += `├ Total Deposited: ${formatCurrency(totalDeposit)}\n`;
    message += `├ Total Spent: ${formatCurrency(totalOrderValue)}\n`;
    message += `└ Net Balance: ${formatCurrency(totalDeposit - totalOrderValue)}\n\n`;
    
    message += `<b>📊 Activity Statistics:</b>\n`;
    message += `├ Total Orders: ${userOrders.length}\n`;
    message += `├ Successful Orders: ${successfulOrders}\n`;
    message += `├ Success Rate: ${userOrders.length > 0 ? Math.round((successfulOrders / userOrders.length) * 100) : 0}%\n`;
    message += `├ Total Deposits: ${userDeposits.length}\n`;
    message += `├ Last Order: ${lastOrder}\n`;
    message += `└ Last Deposit: ${lastDeposit}\n\n`;
    
    message += `<b>⚡ Quick Actions:</b>\n`;
    message += `• Click buttons below to manage this user`;
    
    const keyboard = [];
    
    // Baris 1: Balance Management
    const balanceRow = [];
    balanceRow.push({ 
      text: '➕ Add Balance', 
      callback_data: `user_add_balance_${targetUserId}` 
    });
    balanceRow.push({ 
      text: '➖ Deduct Balance', 
      callback_data: `user_deduct_balance_${targetUserId}` 
    });
    if (userBalance > 0) {
      balanceRow.push({ 
        text: '🔄 Reset Balance', 
        callback_data: `user_reset_balance_${targetUserId}` 
      });
    }
    keyboard.push(balanceRow);
    
    // Baris 2: Ban/Status Management
    const statusRow = [];
    if (isBanned) {
      statusRow.push({ 
        text: '✅ Unban User', 
        callback_data: `user_unban_${targetUserId}` 
      });
    } else {
      statusRow.push({ 
        text: '🚫 Ban User', 
        callback_data: `user_ban_${targetUserId}` 
      });
    }
    
    if (!isOwner) {
      statusRow.push({ 
        text: isOwner ? '➖ Remove Admin' : '➕ Make Admin', 
        callback_data: isOwner ? `user_remove_admin_${targetUserId}` : `user_make_admin_${targetUserId}` 
      });
    }
    
    if (statusRow.length > 0) {
      keyboard.push(statusRow);
    }
    
    // Baris 4: Navigation
    const navRow = [
      { 
        text: '🔙 User List', 
        callback_data: 'owner_user_manager' 
      },
      { 
        text: '🔍 Find Another', 
        callback_data: 'search_user_quick' 
      },
      { 
        text: '🏠 Main', 
        callback_data: 'main_menu' 
      }
    ];
    keyboard.push(navRow);
    
    await editMessage(chatId, messageId, callbackQueryId, message, {
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: keyboard },
      disable_web_page_preview: true
    });

  } catch (error) {
    console.error('Error showUserManageDetail:', error);
    await editMessage(chatId, messageId, callbackQueryId,
      `❌ Gagal memuat detail user.\n\nError: ${error.message}`,
      { parse_mode: 'HTML' }
    );
  }
}

async function showBalanceManager(chatId, userId, messageId, callbackQueryId) {
  try {
    if (!owner_ids.includes(userId.toString())) {
      await bot.answerCallbackQuery(callbackQueryId, {
        text: '⛔ Akses Ditolak\nHanya owner yang bisa mengakses menu ini',
        show_alert: true
      });
      return;
    }

    const balances = loadBalances();
    
    // Hitung statistik
    const totalBalance = Object.values(balances).reduce((sum, b) => sum + (parseInt(b) || 0), 0);
    const totalUsers = Object.keys(balances).length;
    const avgBalance = totalUsers > 0 ? Math.round(totalBalance / totalUsers) : 0;
    
    // Top 3 users dengan balance tertinggi
    const topUsers = Object.entries(balances)
      .map(([id, balance]) => ({ id, balance: parseInt(balance) || 0 }))
      .sort((a, b) => b.balance - a.balance)
      .slice(0, 3);
    
    let message = `<b>💰 BALANCE MANAGER</b>\n\n`;
    
    message += `<b>Balance Statistics:</b>\n`;
    message += `├ Total: ${formatCurrency(totalBalance)}\n`;
    message += `├ Users: ${totalUsers}\n`;
    message += `└ Average: ${formatCurrency(avgBalance)}\n\n`;
    
    message += `<b>Top 3 Users:</b>\n`;
    if (topUsers.length === 0) {
      message += `<i>No users with balance</i>\n\n`;
    } else {
      topUsers.forEach((user, index) => {
        const medal = index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : '▫️';
        message += `${medal} <code>${user.id.substring(0, 8)}...</code>: ${formatCurrency(user.balance)}\n`;
      });
      message += `\n`;
    }
    
    message += `<b>Quick Actions:</b>\n`;
    message += `• Add balance to user\n`;
    message += `• Deduct balance\n`;
    message += `• Reset balance\n`;
    
    const keyboard = [];
    
    // Quick Balance Operations
    keyboard.push([
      { text: '➕ Add Balance', callback_data: 'balance_add_quick' },
      { text: '➖ Deduct', callback_data: 'balance_deduct_quick' },
      { text: '🔄 Reset', callback_data: 'balance_reset_quick' }
    ]);
    
    // Top Users
    const topUserButtons = [];
    topUsers.forEach((user, index) => {
      topUserButtons.push({
        text: `${index + 1}. ${formatCurrency(user.balance).replace('Rp', '')}`,
        callback_data: `user_manage_${userId}`
      });
    });
    
    // Tambahkan placeholder jika kurang dari 3
    while (topUserButtons.length < 3) {
      topUserButtons.push({
        text: '─',
        callback_data: 'no_action'
      });
    }
    
    keyboard.push(topUserButtons);
    
    // Tools
    keyboard.push([
      { text: '🔍 Find User', callback_data: 'search_user_quick' },
      { text: '📋 User List', callback_data: 'owner_user_manager' },
      { text: '🔄 Refresh', callback_data: 'owner_balance_manager' }
    ]);
    
    // Navigation
    keyboard.push([
      { text: '🔙 Settings', callback_data: 'owner_settings' },
      { text: '🏠 Main', callback_data: 'main_menu' }
    ]);
    
    await editMessage(chatId, messageId, callbackQueryId, message, {
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: keyboard },
      disable_web_page_preview: true
    });

  } catch (error) {
    console.error('Error showBalanceManager:', error);
  }
}

async function showBanManager(chatId, userId, messageId, callbackQueryId) {
  try {
    if (!owner_ids.includes(userId.toString())) {
      await bot.answerCallbackQuery(callbackQueryId, {
        text: '⛔ Akses Ditolak\nHanya owner yang bisa mengakses menu ini',
        show_alert: true
      });
      return;
    }

    const bannedUsers = loadBannedUsers();
    const data = loadData();
    
    const activeBans = bannedUsers.filter(user => user.status === 'banned');
    const totalUsers = data.users?.length || 0;
    
    let message = `<b>🚫 BAN MANAGER</b>\n\n`;
    
    message += `<b>Ban Statistics:</b>\n`;
    message += `├ Total Banned: ${activeBans.length}\n`;
    message += `├ Total Users: ${totalUsers}\n`;
    message += `└ Ban Rate: ${totalUsers > 0 ? ((activeBans.length / totalUsers) * 100).toFixed(2) : 0}%\n\n`;
    
    if (activeBans.length === 0) {
      message += `<i>No users are currently banned</i>\n\n`;
    } else {
      message += `<b>Recently Banned:</b>\n\n`;
      
      // Tampilkan 3 terbaru
      const recentBans = activeBans
        .sort((a, b) => new Date(b.bannedAt) - new Date(a.bannedAt))
        .slice(0, 3);
      
      recentBans.forEach((ban, index) => {
        const banDate = new Date(ban.bannedAt).toLocaleDateString('id-ID');
        
        message += `<b>${index + 1}. User ${ban.userId.substring(0, 8)}...</b>\n`;
        message += `├ Reason: ${ban.reason || 'No reason'}\n`;
        message += `└ Date: ${banDate}\n\n`;
      });
    }
    
    message += `<b>Actions:</b>\n`;
    message += `• Ban user by ID\n`;
    message += `• Unban specific user\n`;
    message += `• View banned list\n`;
    
    const keyboard = [];
    
    // Main Actions
    keyboard.push([
      { text: '🚫 Ban User', callback_data: 'ban_user_quick' },
      { text: '✅ Unban User', callback_data: 'unban_user_quick' },
      { text: '📋 Ban List', callback_data: 'ban_list_full' }
    ]);
    
    // Recent Bans (jika ada)
    if (activeBans.length > 0) {
      const recentBanButtons = [];
      const displayBans = activeBans.slice(0, 3);
      
      displayBans.forEach((ban, index) => {
        recentBanButtons.push({
          text: `${index + 1}. ${ban.userId.substring(0, 6)}...`,
          callback_data: `user_manage_${ban.userId}`
        });
      });
      
      keyboard.push(recentBanButtons);
    }
    
    // Tools
    keyboard.push([
      { text: '🔍 Search', callback_data: 'search_user_quick' },
      { text: '👥 User Manager', callback_data: 'owner_user_manager' },
      { text: '🔄 Refresh', callback_data: 'owner_ban_manager' }
    ]);
    
    // Navigation
    keyboard.push([
      { text: '🔙 Settings', callback_data: 'owner_settings' },
      { text: '🏠 Main', callback_data: 'main_menu' }
    ]);
    
    await editMessage(chatId, messageId, callbackQueryId, message, {
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: keyboard },
      disable_web_page_preview: true
    });

  } catch (error) {
    console.error('Error showBanManager:', error);
  }
}

// ========================= USER MANAGEMENT FUNCTIONS =========================

async function showUserDetailsMenu(chatId, userId, messageId, callbackQueryId) {
  try {
    if (!owner_ids.includes(userId.toString())) {
      await bot.answerCallbackQuery(callbackQueryId, {
        text: '⛔ Akses Ditolak\nHanya owner yang bisa mengakses menu ini',
        show_alert: true
      });
      return;
    }

    const message = `<b>👤 USER DETAILS MANAGEMENT</b>

<b>Cari user berdasarkan:</b>

1️⃣ <b>User ID</b> - Cari dengan ID Telegram
2️⃣ <b>Username</b> - Cari dengan @username
3️⃣ <b>Nama</b> - Cari dengan nama depan

<i>Pilih metode pencarian:</i>`;

    const keyboard = [
      [
        { text: '🔢 Cari by User ID', callback_data: 'search_user_by_id' },
        { text: '@ Cari by Username', callback_data: 'search_user_by_username' }
      ],
      [
        { text: '👤 Cari by Nama', callback_data: 'search_user_by_name' },
        { text: '📋 Top Users', callback_data: 'show_top_users' }
      ],
      [
        { text: '🔙 Settings Menu', callback_data: 'owner_settings' },
        { text: '🏠 Menu Utama', callback_data: 'main_menu' }
      ]
    ];

    await editMessage(chatId, messageId, callbackQueryId, message, {
      reply_markup: { inline_keyboard: keyboard },
      parse_mode: 'HTML'
    });

  } catch (error) {
    console.error('Error showUserDetailsMenu:', error);
  }
}

async function searchUserByID(chatId, userId, messageId, callbackQueryId) {
  try {
    await editMessage(chatId, messageId, callbackQueryId,
      `<b>🔢 CARI USER BY ID</b>\n\nKirim User ID yang ingin dicari:\n\nContoh: <code>123456789</code>\n\n<i>User ID harus berupa angka</i>`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: '🔙 Kembali', callback_data: 'owner_user_details' }]
          ]
        }
      }
    );

    const selection = {
      step: 'search_user_id',
      timestamp: Date.now()
    };
    userSelections.set(userId, selection);

  } catch (error) {
    console.error('Error searchUserByID:', error);
  }
}

async function showUserDetails(userId, targetUserId, chatId, messageId, callbackQueryId) {
  try {
    const balances = loadBalances();
    const transactions = loadTransactions();
    
    const userBalance = parseInt(balances[targetUserId]) || 0;
    
    // Hitung statistik user
    const userOrders = transactions.nokos_orders?.filter(order => 
      order.userId === targetUserId
    ) || [];
    
    const successfulOrders = userOrders.filter(order => 
      order.status === 'completed' || 
      order.data?.status === 'completed' ||
      order.data?.otp_received === true
    ).length;
    
    const userDeposits = [
      ...(transactions.cashify_deposits?.filter(deposit => 
        deposit.userId === targetUserId && 
        (deposit.status === 'success' || deposit.status === 'paid')
      ) || []),
      ...(transactions.rumahotp_deposits?.filter(deposit => 
        deposit.userId === targetUserId && 
        (deposit.status === 'success' || deposit.status === 'paid')
      ) || [])
    ];
    
    const totalDeposit = userDeposits.reduce((sum, deposit) => 
      sum + (parseInt(deposit.data?.amount || deposit.data?.total || 0) || 0), 0
    );
    
    const lastOrder = userOrders.length > 0 ? 
      new Date(userOrders[userOrders.length - 1].timestamp).toLocaleString('id-ID') : 
      'Belum pernah order';
    
    const lastDeposit = userDeposits.length > 0 ? 
      new Date(userDeposits[userDeposits.length - 1].timestamp).toLocaleString('id-ID') : 
      'Belum pernah deposit';
    
    // Coba dapatkan info user dari Telegram
    let userInfo = {};
    try {
      const chat = await bot.getChat(targetUserId);
      userInfo = {
        firstName: chat.first_name || 'Tidak diketahui',
        lastName: chat.last_name || '',
        username: chat.username ? `@${chat.username}` : 'Tidak ada',
        isBot: chat.is_bot || false
      };
    } catch (error) {
      userInfo = {
        firstName: 'Tidak diketahui',
        lastName: '',
        username: 'Tidak ada',
        isBot: false
      };
    }
    
    const message = `<b>👤 DETAIL USER</b>\n\n` +
      `<b>Informasi User:</b>\n` +
      `├ ID: <code>${targetUserId}</code>\n` +
      `├ Nama: ${userInfo.firstName} ${userInfo.lastName}\n` +
      `├ Username: ${userInfo.username}\n` +
      `├ Bot: ${userInfo.isBot ? '✅ Ya' : '❌ Tidak'}\n` +
      `└ Status: ${owner_ids.includes(targetUserId) ? '👑 Owner' : '👤 User'}\n\n` +
      `<b>Statistik:</b>\n` +
      `├ Saldo: ${formatCurrency(userBalance)}\n` +
      `├ Total Order: ${userOrders.length}\n` +
      `├ Order Sukses: ${successfulOrders}\n` +
      `├ Total Deposit: ${formatCurrency(totalDeposit)}\n` +
      `├ Last Order: ${lastOrder}\n` +
      `└ Last Deposit: ${lastDeposit}\n\n` +
      `<b>Aksi:</b> Pilih aksi yang ingin dilakukan`;

    const keyboard = [
      [
        { text: '💰 Tambah Saldo', callback_data: `add_balance_${targetUserId}` },
        { text: '➖ Kurang Saldo', callback_data: `deduct_balance_${targetUserId}` }
      ],
      [
        { text: '📋 Riwayat Order', callback_data: `view_orders_${targetUserId}` },
        { text: '💳 Riwayat Deposit', callback_data: `view_deposits_${targetUserId}` }
      ],
      [
        { text: userBalance > 0 ? '🔴 Reset Saldo' : '✅ Reset Saldo', callback_data: `reset_balance_${targetUserId}` },
        { text: '🚫 Ban User', callback_data: `ban_user_${targetUserId}` }
      ],
      [
        { text: '🔙 Cari User Lain', callback_data: 'owner_user_details' },
        { text: '🏠 Menu Utama', callback_data: 'main_menu' }
      ]
    ];

    await editMessage(chatId, messageId, callbackQueryId, message, {
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: keyboard }
    });

  } catch (error) {
    console.error('Error showUserDetails:', error);
    await editMessage(chatId, messageId, callbackQueryId,
      `❌ Gagal mendapatkan detail user.\n\nError: ${error.message}`,
      { parse_mode: 'HTML' }
    );
  }
}

async function showUserBalanceManagement(chatId, userId, messageId, callbackQueryId) {
  try {
    if (!owner_ids.includes(userId.toString())) {
      await bot.answerCallbackQuery(callbackQueryId, {
        text: '⛔ Akses Ditolak\nHanya owner yang bisa mengakses menu ini',
        show_alert: true
      });
      return;
    }

    const message = `<b>💰 USER BALANCE MANAGEMENT</b>

<b>Fitur:</b>

1️⃣ <b>Tambah Saldo User</b>
   Tambahkan saldo ke user tertentu

2️⃣ <b>Kurangi Saldo User</b>
   Kurangi saldo user (untuk koreksi)

3️⃣ <b>Reset Saldo User</b>
   Set saldo user menjadi 0

4️⃣ <b>Cek Saldo User</b>
   Cek saldo user tertentu

<i>Pilih aksi:</i>`;

    const keyboard = [
      [
        { text: '➕ Tambah Saldo', callback_data: 'add_user_balance' },
        { text: '➖ Kurangi Saldo', callback_data: 'deduct_user_balance' }
      ],
      [
        { text: '🔄 Reset Saldo', callback_data: 'reset_user_balance' },
        { text: '📊 Cek Saldo', callback_data: 'check_user_balance' }
      ],
      [
        { text: '🔙 Settings Menu', callback_data: 'owner_settings' },
        { text: '🏠 Menu Utama', callback_data: 'main_menu' }
      ]
    ];

    await editMessage(chatId, messageId, callbackQueryId, message, {
      reply_markup: { inline_keyboard: keyboard },
      parse_mode: 'HTML'
    });

  } catch (error) {
    console.error('Error showUserBalanceManagement:', error);
  }
}

async function showUserHistoryMenu(chatId, userId, messageId, callbackQueryId) {
  try {
    if (!owner_ids.includes(userId.toString())) {
      await bot.answerCallbackQuery(callbackQueryId, {
        text: '⛔ Akses Ditolak\nHanya owner yang bisa mengakses menu ini',
        show_alert: true
      });
      return;
    }

    const message = `<b>📋 USER HISTORY MANAGEMENT</b>

<b>Lihat riwayat user:</b>

1️⃣ <b>Riwayat Order</b>
   Lihat semua order user tertentu

2️⃣ <b>Riwayat Deposit</b>
   Lihat semua deposit user

3️⃣ <b>Riwayat Voucher</b>
   Lihat penggunaan voucher user

4️⃣ <b>Riwayat Lengkap</b>
   Lihat semua aktivitas user

<i>Pilih jenis riwayat:</i>`;

    const keyboard = [
      [
        { text: '🛒 Order History', callback_data: 'view_user_orders' },
        { text: '💰 Deposit History', callback_data: 'view_user_deposits' }
      ],
      [
        { text: '🎫 Voucher History', callback_data: 'view_user_vouchers' },
        { text: '📊 Full History', callback_data: 'view_full_history' }
      ],
      [
        { text: '🔙 Settings Menu', callback_data: 'owner_settings' },
        { text: '🏠 Menu Utama', callback_data: 'main_menu' }
      ]
    ];

    await editMessage(chatId, messageId, callbackQueryId, message, {
      reply_markup: { inline_keyboard: keyboard },
      parse_mode: 'HTML'
    });

  } catch (error) {
    console.error('Error showUserHistoryMenu:', error);
  }
}

async function showBanManagement(chatId, userId, messageId, callbackQueryId) {
  try {
    if (!owner_ids.includes(userId.toString())) {
      await bot.answerCallbackQuery(callbackQueryId, {
        text: '⛔ Akses Ditolak\nHanya owner yang bisa mengakses menu ini',
        show_alert: true
      });
      return;
    }

    const bannedUsers = loadBannedUsers();
    const activeBans = bannedUsers.filter(user => user.status === 'banned').length;

    const message = `<b>🚫 BAN/UNBAN MANAGEMENT</b>

<b>Statistik:</b>
Total User Banned: ${activeBans}

<b>Fitur:</b>
1️⃣ <b>Ban User</b> - Blokir akses user ke bot
2️⃣ <b>Unban User</b> - Buka blokir user
3️⃣ <b>List Banned</b> - Lihat daftar user banned
4️⃣ <b>Cek Status</b> - Cek status user

<i>Pilih aksi:</i>`;

    const keyboard = [
      [
        { text: '🚫 Ban User', callback_data: 'ban_user_menu' },
        { text: '✅ Unban User', callback_data: 'unban_user_menu' }
      ],
      [
        { text: '📋 List Banned', callback_data: 'list_banned_users' },
        { text: '🔍 Cek Status', callback_data: 'check_ban_status' }
      ],
      [
        { text: '🔙 Settings Menu', callback_data: 'owner_settings' },
        { text: '🏠 Menu Utama', callback_data: 'main_menu' }
      ]
    ];

    await editMessage(chatId, messageId, callbackQueryId, message, {
      reply_markup: { inline_keyboard: keyboard },
      parse_mode: 'HTML'
    });

  } catch (error) {
    console.error('Error showBanManagement:', error);
  }
}

// Load banned users function
function loadBannedUsers() {
  try {
    const bannedFile = path.join(dataDir, 'banned_users.json');
    if (!fs.existsSync(bannedFile)) {
      return [];
    }
    return JSON.parse(fs.readFileSync(bannedFile, 'utf8'));
  } catch (error) {
    return [];
  }
}

// Save banned users function
function saveBannedUsers(bannedUsers) {
  try {
    const bannedFile = path.join(dataDir, 'banned_users.json');
    fs.writeFileSync(bannedFile, JSON.stringify(bannedUsers, null, 2));
    return true;
  } catch (error) {
    return false;
  }
}

// Check if user is banned
function isUserBanned(userId) {
  const bannedUsers = loadBannedUsers();
  return bannedUsers.some(user => 
    user.userId === userId.toString() && user.status === 'banned'
  );
}

// Ban user function
function banUser(userId, reason = '', bannedBy = 'system') {
  const bannedUsers = loadBannedUsers();
  
  const existingIndex = bannedUsers.findIndex(user => user.userId === userId.toString());
  
  if (existingIndex !== -1) {
    bannedUsers[existingIndex].status = 'banned';
    bannedUsers[existingIndex].reason = reason;
    bannedUsers[existingIndex].bannedBy = bannedBy;
    bannedUsers[existingIndex].bannedAt = new Date().toISOString();
  } else {
    bannedUsers.push({
      userId: userId.toString(),
      status: 'banned',
      reason: reason,
      bannedBy: bannedBy,
      bannedAt: new Date().toISOString(),
      unbannedAt: null
    });
  }
  
  return saveBannedUsers(bannedUsers);
}

// Unban user function
function unbanUser(userId, unbannedBy = 'system') {
  const bannedUsers = loadBannedUsers();
  
  const userIndex = bannedUsers.findIndex(user => 
    user.userId === userId.toString() && user.status === 'banned'
  );
  
  if (userIndex !== -1) {
    bannedUsers[userIndex].status = 'unbanned';
    bannedUsers[userIndex].unbannedAt = new Date().toISOString();
    bannedUsers[userIndex].unbannedBy = unbannedBy;
    return saveBannedUsers(bannedUsers);
  }
  
  return false;
}

// Show list users function
async function showListUsers(chatId, userId, messageId, callbackQueryId, page = 0) {
  try {
    if (!owner_ids.includes(userId.toString())) {
      await bot.answerCallbackQuery(callbackQueryId, {
        text: '⛔ Akses Ditolak\nHanya owner yang bisa mengakses menu ini',
        show_alert: true
      });
      return;
    }

    const data = loadData();
    const balances = loadBalances();
    const bannedUsers = loadBannedUsers();
    
    const users = data.users || [];
    const itemsPerPage = 10;
    const totalPages = Math.ceil(users.length / itemsPerPage);
    
    if (page < 0) page = 0;
    if (page >= totalPages && totalPages > 0) page = totalPages - 1;
    
    const startIndex = page * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const pageUsers = users.slice(startIndex, endIndex);
    
    let message = `<b>📊 LIST ALL USERS</b>\n\n`;
    message += `<b>Total Users:</b> ${users.length}\n`;
    message += `<b>Users with Balance:</b> ${Object.keys(balances).length}\n`;
    message += `<b>Banned Users:</b> ${bannedUsers.filter(u => u.status === 'banned').length}\n`;
    message += `<b>Page:</b> ${page + 1}/${totalPages}\n\n`;
    
    if (pageUsers.length === 0) {
      message += `<i>No users found</i>`;
    } else {
      for (let i = 0; i < pageUsers.length; i++) {
        const user = pageUsers[i];
        const balance = parseInt(balances[user]) || 0;
        const isBanned = isUserBanned(user);
        const isOwner = owner_ids.includes(user);
        
        let userInfo = `ID: <code>${user}</code>\n`;
        userInfo += `Saldo: ${formatCurrency(balance)}\n`;
        userInfo += `Status: ${isBanned ? '🚫 Banned' : (isOwner ? '👑 Owner' : '✅ Active')}\n`;
        
        message += `<b>${startIndex + i + 1}. User</b>\n${userInfo}\n`;
      }
    }
    
    const keyboard = [];
    
    pageUsers.forEach((user, index) => {
      const num = startIndex + index + 1;
      keyboard.push([
        { 
          text: `${num}. User ${user.substring(0, 8)}...`, 
          callback_data: `user_detail_${user}` 
        }
      ]);
    });
    
    const navButtons = [];
    if (totalPages > 1) {
      if (page > 0) {
        navButtons.push({ 
          text: '◀️ Prev', 
          callback_data: `list_users_page_${page - 1}` 
        });
      }
      
      navButtons.push({ 
        text: `📄 ${page + 1}/${totalPages}`, 
        callback_data: 'no_action' 
      });
      
      if (page < totalPages - 1) {
        navButtons.push({ 
          text: '▶️ Next', 
          callback_data: `list_users_page_${page + 1}` 
        });
      }
      
      if (navButtons.length > 0) {
        keyboard.push(navButtons);
      }
    }
    
    keyboard.push([
      { text: '🔍 Search User', callback_data: 'owner_user_details' },
      { text: '🔄 Refresh', callback_data: `list_users_page_${page}` }
    ]);
    
    keyboard.push([
      { text: '🔙 Settings Menu', callback_data: 'owner_settings' },
      { text: '🏠 Menu Utama', callback_data: 'main_menu' }
    ]);

    await editMessage(chatId, messageId, callbackQueryId, message, {
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: keyboard },
      disable_web_page_preview: true
    });

  } catch (error) {
    console.error('Error showListUsers:', error);
  }
}

// Database management function
async function showDatabaseMenu(chatId, userId, messageId, callbackQueryId) {
  try {
    if (!owner_ids.includes(userId.toString())) {
      await bot.answerCallbackQuery(callbackQueryId, {
        text: '⛔ Akses Ditolak\nHanya owner yang bisa mengakses menu ini',
        show_alert: true
      });
      return;
    }

    const message = `<b>💾 DATABASE</b>

<b>Database Operations:</b>
• Reset database
• Manual backup
• Restore from backup

<b>Warning:</b>
Reset will delete all user data!

<i>Select operation:</i>`;

    const keyboard = [
      [
        { text: '🗑️ Reset', callback_data: 'reset_database_confirm' },
        { text: '💾 Backup', callback_data: 'create_backup_now' }
      ],
      [
        { text: '📥 Restore', callback_data: 'restore_menu' },
        { text: '🔄 Refresh', callback_data: 'owner_database' }
      ],
      [
        { text: '🔙 Settings', callback_data: 'owner_settings' },
        { text: '🏠 Main', callback_data: 'main_menu' }
      ]
    ];

    await editMessage(chatId, messageId, callbackQueryId, message, {
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: keyboard }
    });

  } catch (error) {
    console.error('Error showDatabaseMenu:', error);
  }
}

// Helper function to get file size
function getFileSize(filePath) {
  try {
    if (fs.existsSync(filePath)) {
      const stats = fs.statSync(filePath);
      const sizeInKB = (stats.size / 1024).toFixed(2);
      return `${sizeInKB} KB`;
    }
    return '0 KB';
  } catch (error) {
    return '0 KB';
  }
}

// Admin management function
async function showAdminMenu(chatId, userId, messageId, callbackQueryId) {
  try {
    if (!owner_ids.includes(userId.toString())) {
      await bot.answerCallbackQuery(callbackQueryId, {
        text: '⛔ Akses Ditolak\nHanya owner yang bisa mengakses menu ini',
        show_alert: true
      });
      return;
    }

    const message = `<b>👥 ADMIN CONTROL</b>

<b>Current Admins:</b>
${owner_ids.map((id, index) => `${index + 1}. <code>${id}</code>`).join('\n')}

<b>Actions:</b>
• Add new admin
• Remove admin
• List all admins

<i>Select action:</i>`;

    const keyboard = [
      [
        { text: '➕ Add Admin', callback_data: 'add_admin' },
        { text: '➖ Remove Admin', callback_data: 'remove_admin' }
      ],
      [
        { text: '📋 List', callback_data: 'list_admins' },
        { text: '🔄 Refresh', callback_data: 'owner_admin_menu' }
      ],
      [
        { text: '🔙 Settings', callback_data: 'owner_settings' },
        { text: '🏠 Main', callback_data: 'main_menu' }
      ]
    ];

    await editMessage(chatId, messageId, callbackQueryId, message, {
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: keyboard }
    });

  } catch (error) {
    console.error('Error showAdminMenu:', error);
  }
}

async function addCSAdminHandler(chatId, userId, messageId, callbackQueryId) {
  try {
    if (!owner_ids.includes(userId.toString())) {
      await bot.answerCallbackQuery(callbackQueryId, {
        text: '⛔ Akses Ditolak\nHanya owner yang bisa mengakses menu ini',
        show_alert: true
      });
      return;
    }

    // Set user selection untuk menunggu input user ID
    const selection = {
      step: 'awaiting_cs_admin_id',
      timestamp: Date.now()
    };
    userSelections.set(userId, selection);

    await editMessage(chatId, messageId, callbackQueryId,
      `<b>➕ ADD CS ADMIN</b>\n\n` +
      `Send User ID to add as CS Admin:\n\n` +
      `Example: <code>123456789</code>\n\n` +
      `<i>User must have started the bot before</i>`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: '🔙 Back', callback_data: 'owner_cs_menu' }]
          ]
        }
      }
    );

  } catch (error) {
    console.error('Error addCSAdminHandler:', error);
  }
}

async function removeCSAdminHandler(chatId, userId, messageId, callbackQueryId) {
  try {
    if (!owner_ids.includes(userId.toString())) {
      await bot.answerCallbackQuery(callbackQueryId, {
        text: '⛔ Akses Ditolak\nHanya owner yang bisa mengakses menu ini',
        show_alert: true
      });
      return;
    }

    const csAdmins = config.cs_admins || [];
    
    if (csAdmins.length === 0) {
      await editMessage(chatId, messageId, callbackQueryId,
        `<b>➖ REMOVE CS ADMIN</b>\n\n` +
        `No CS Admins to remove.\n\n` +
        `<i>Add CS Admins first</i>`,
        {
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [{ text: '➕ Add CS', callback_data: 'add_cs_admin' }],
              [{ text: '🔙 Back', callback_data: 'owner_cs_menu' }]
            ]
          }
        }
      );
      return;
    }

    // Set user selection untuk menunggu input user ID
    const selection = {
      step: 'awaiting_remove_cs_admin_id',
      timestamp: Date.now()
    };
    userSelections.set(userId, selection);

    let message = `<b>➖ REMOVE CS ADMIN</b>\n\n`;
    message += `<b>Current CS Admins:</b>\n`;
    csAdmins.forEach((id, index) => {
      message += `${index + 1}. <code>${id}</code>\n`;
    });
    message += `\nSend User ID to remove from CS Admins:\n\n`;
    message += `Example: <code>123456789</code>`;

    await editMessage(chatId, messageId, callbackQueryId, message, {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [{ text: '🔙 Back', callback_data: 'owner_cs_menu' }]
        ]
      }
    });

  } catch (error) {
    console.error('Error removeCSAdminHandler:', error);
  }
}

async function listCSAdminsHandler(chatId, userId, messageId, callbackQueryId) {
  try {
    if (!owner_ids.includes(userId.toString())) {
      await bot.answerCallbackQuery(callbackQueryId, {
        text: '⛔ Akses Ditolak\nHanya owner yang bisa mengakses menu ini',
        show_alert: true
      });
      return;
    }

    const csAdmins = config.cs_admins || [];
    
    let message = `<b>📋 CS ADMIN LIST</b>\n\n`;
    
    if (csAdmins.length === 0) {
      message += `<i>No CS Admins configured</i>\n\n`;
      message += `Add CS Admins to manage customer support.`;
    } else {
      message += `<b>Total CS Admins:</b> ${csAdmins.length}\n\n`;
      
      csAdmins.forEach((adminId, index) => {
        // Cek apakah admin juga merupakan owner
        const isOwner = owner_ids.includes(adminId);
        message += `<b>${index + 1}. <code>${adminId}</code></b>\n`;
        message += `├ Type: ${isOwner ? '👑 Owner + CS' : '💬 CS Only'}\n`;
        message += `└ Actions: [Manage](#)\n\n`;
      });
    }
    
    const keyboard = [];
    
    // Tambahkan tombol untuk setiap CS admin
    csAdmins.forEach((adminId, index) => {
      keyboard.push([
        { 
          text: `${index + 1}. ${adminId.substring(0, 8)}...`, 
          callback_data: `cs_admin_info_${adminId}` 
        }
      ]);
    });
    
    // Jika ada CS admins, tambahkan tombol aksi
    if (csAdmins.length > 0) {
      keyboard.push([
        { text: '➖ Remove CS', callback_data: 'remove_cs_admin' },
        { text: '➕ Add CS', callback_data: 'add_cs_admin' }
      ]);
    } else {
      keyboard.push([
        { text: '➕ Add CS Admin', callback_data: 'add_cs_admin' }
      ]);
    }
    
    keyboard.push([
      { text: '🔄 Refresh', callback_data: 'list_cs_admins' },
      { text: '🔙 Back', callback_data: 'owner_cs_menu' }
    ]);

    await editMessage(chatId, messageId, callbackQueryId, message, {
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: keyboard }
    });

  } catch (error) {
    console.error('Error listCSAdminsHandler:', error);
  }
}

async function showCSAdminInfo(chatId, userId, targetAdminId, messageId, callbackQueryId) {
  try {
    if (!owner_ids.includes(userId.toString())) {
      await bot.answerCallbackQuery(callbackQueryId, {
        text: '⛔ Akses Ditolak\nHanya owner yang bisa mengakses menu ini',
        show_alert: true
      });
      return;
    }

    const csAdmins = config.cs_admins || [];
    const isCSAdmin = csAdmins.includes(targetAdminId);
    const isOwner = owner_ids.includes(targetAdminId);
    
    // Coba dapatkan info user
    let userInfo = {};
    try {
      const chat = await bot.getChat(targetAdminId);
      userInfo = {
        firstName: chat.first_name || 'Unknown',
        lastName: chat.last_name || '',
        username: chat.username ? `@${chat.username}` : 'No username',
        isBot: chat.is_bot || false
      };
    } catch (error) {
      userInfo = {
        firstName: 'Unknown',
        lastName: '',
        username: 'No username',
        isBot: false
      };
    }
    
    let message = `<b>💬 CS ADMIN INFO</b>\n\n`;
    
    message += `<b>User Information:</b>\n`;
    message += `├ ID: <code>${targetAdminId}</code>\n`;
    message += `├ Name: ${userInfo.firstName} ${userInfo.lastName}\n`;
    message += `├ Username: ${userInfo.username}\n`;
    message += `├ Bot: ${userInfo.isBot ? '✅ Yes' : '❌ No'}\n`;
    message += `├ Owner: ${isOwner ? '✅ Yes' : '❌ No'}\n`;
    message += `└ CS Admin: ${isCSAdmin ? '✅ Yes' : '❌ No'}\n\n`;
    
    if (isCSAdmin) {
      message += `<b>CS Admin Status:</b> Active\n`;
      message += `<i>This user can access CS features</i>\n\n`;
    } else {
      message += `<b>CS Admin Status:</b> Not CS Admin\n`;
      message += `<i>This user cannot access CS features</i>\n\n`;
    }
    
    const keyboard = [];
    
    // Tombol aksi berdasarkan status
    if (isCSAdmin) {
      keyboard.push([
        { 
          text: '➖ Remove as CS', 
          callback_data: `cs_remove_confirm_${targetAdminId}` 
        }
      ]);
    } else {
      keyboard.push([
        { 
          text: '➕ Add as CS', 
          callback_data: `cs_add_confirm_${targetAdminId}` 
        }
      ]);
    }
    
    // Tombol tambahan
    keyboard.push([
      { text: '📋 All CS Admins', callback_data: 'list_cs_admins' },
      { text: '➕ Add New CS', callback_data: 'add_cs_admin' }
    ]);
    
    keyboard.push([
      { text: '🔙 Back', callback_data: 'owner_cs_menu' }
    ]);

    await editMessage(chatId, messageId, callbackQueryId, message, {
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: keyboard }
    });

  } catch (error) {
    console.error('Error showCSAdminInfo:', error);
  }
}

async function confirmAddCSAdmin(chatId, userId, targetAdminId, messageId, callbackQueryId) {
  try {
    const success = addCSAdminToConfig(targetAdminId);
    
    if (success) {
      await editMessage(chatId, messageId, callbackQueryId,
        `<b>✅ CS ADMIN ADDED</b>\n\n` +
        `User ID: <code>${targetAdminId}</code>\n` +
        `Added by: ${userId}\n` +
        `Time: ${new Date().toLocaleString('id-ID')}\n\n` +
        `<i>User is now a CS Admin</i>`,
        {
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [
                { text: '📋 View All', callback_data: 'list_cs_admins' },
                { text: '➕ Add More', callback_data: 'add_cs_admin' }
              ],
              [
                { text: '🔙 CS Menu', callback_data: 'owner_cs_menu' }
              ]
            ]
          }
        }
      );
    } else {
      await editMessage(chatId, messageId, callbackQueryId,
        `<b>❌ FAILED TO ADD CS ADMIN</b>\n\n` +
        `User may already be a CS Admin or there was an error.`,
        {
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [{ text: '🔙 Try Again', callback_data: 'owner_cs_menu' }]
            ]
          }
        }
      );
    }
    
  } catch (error) {
    console.error('Error confirmAddCSAdmin:', error);
  }
}

async function confirmRemoveCSAdmin(chatId, userId, targetAdminId, messageId, callbackQueryId) {
  try {
    const success = removeCSAdminFromConfig(targetAdminId);
    
    if (success) {
      await editMessage(chatId, messageId, callbackQueryId,
        `<b>✅ CS ADMIN REMOVED</b>\n\n` +
        `User ID: <code>${targetAdminId}</code>\n` +
        `Removed by: ${userId}\n` +
        `Time: ${new Date().toLocaleString('id-ID')}\n\n` +
        `<i>User is no longer a CS Admin</i>`,
        {
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [
                { text: '📋 View All', callback_data: 'list_cs_admins' },
                { text: '➖ Remove More', callback_data: 'remove_cs_admin' }
              ],
              [
                { text: '🔙 CS Menu', callback_data: 'owner_cs_menu' }
              ]
            ]
          }
        }
      );
    } else {
      await editMessage(chatId, messageId, callbackQueryId,
        `<b>❌ FAILED TO REMOVE CS ADMIN</b>\n\n` +
        `User may not be a CS Admin or there was an error.`,
        {
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [{ text: '🔙 Try Again', callback_data: 'owner_cs_menu' }]
            ]
          }
        }
      );
    }
    
  } catch (error) {
    console.error('Error confirmRemoveCSAdmin:', error);
  }
}

// Update showCSMenu function
async function showCSMenu(chatId, userId, messageId, callbackQueryId) {
  try {
    if (!owner_ids.includes(userId.toString())) {
      await bot.answerCallbackQuery(callbackQueryId, {
        text: '⛔ Akses Ditolak\nHanya owner yang bisa mengakses menu ini',
        show_alert: true
      });
      return;
    }

    const csAdmins = config.cs_admins || [];
    
    const message = `<b>💬 CUSTOMER SUPPORT</b>

<b>Current CS Admins:</b>
${csAdmins.length > 0 ? 
  csAdmins.map((id, index) => `${index + 1}. <code>${id}</code>`).join('\n') : 
  'No CS Admins'}

<b>Actions:</b>
• Add CS admin
• Remove CS admin
• View CS list

<i>Select action:</i>`;

    const keyboard = [
      [
        { text: '➕ Add CS', callback_data: 'add_cs_admin' },
        { text: '➖ Remove CS', callback_data: 'remove_cs_admin' }
      ],
      [
        { text: '📋 List CS', callback_data: 'list_cs_admins' },
        { text: '🔄 Refresh', callback_data: 'owner_cs_menu' }
      ],
      [
        { text: '🔙 Settings', callback_data: 'owner_settings' },
        { text: '🏠 Main', callback_data: 'main_menu' }
      ]
    ];

    await editMessage(chatId, messageId, callbackQueryId, message, {
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: keyboard }
    });

  } catch (error) {
    console.error('Error showCSMenu:', error);
  }
}

// Add CS Admin to config
function addCSAdmin(userId) {
  try {
    const configPath = path.join(__dirname, 'config.js');
    let configContent = fs.readFileSync(configPath, 'utf8');
    
    // Cek jika cs_admins sudah ada di config
    if (!configContent.includes('cs_admins')) {
      // Tambahkan cs_admins setelah owner_ids
      configContent = configContent.replace(
        /owner_ids:\s*\[([^\]]+)\]/,
        `owner_ids: [$1],\n  cs_admins: ['${userId}']`
      );
    } else {
      // Update cs_admins yang sudah ada
      configContent = configContent.replace(
        /cs_admins:\s*\[([^\]]+)\]/,
        `cs_admins: [$1, '${userId}']`
      );
    }
    
    fs.writeFileSync(configPath, configContent);
    
    // Reload config
    delete require.cache[require.resolve('./config')];
    const newConfig = require('./config');
    
    // Update global config
    Object.assign(config, newConfig);
    
    return true;
  } catch (error) {
    console.error('Error adding CS admin:', error);
    return false;
  }
}

async function showOwnerMenu(chatId, userId, messageId, callbackQueryId) {
  try {
    if (!owner_ids.includes(userId.toString())) {
      await bot.answerCallbackQuery(callbackQueryId, {
        text: '⛔ Akses Ditolak\nHanya owner yang bisa mengakses menu ini',
        show_alert: true
      });
      return;
    }

    const message = `<b>OWNER MENU</b>

<b>Commands yang tersedia:</b>
/broadcast - Kirim pesan ke semua user
/stats - Lihat statistik bot
/setpay - Atur metode pembayaran
/maintenance - Mode maintenance
/addsaldo - Tambah saldo user
/restore - Restore data dari backup
/voucher - Kelola voucher

<i>Ketik command di chat atau pilih menu:</i>`;

    const keyboard = [
      [
        { text: '📁 Restore Data', callback_data: 'restore_menu' },
        { text: '📋 Riwayat Withdraw', callback_data: 'withdraw_history' }
      ],
      [
        { text: '🎫 Kelola Voucher', callback_data: 'owner_voucher_menu' },
        { text: '💰 Withdraw', callback_data: 'withdraw_menu' }
      ],
      [
        { text: '⚙️ Settings', callback_data: 'owner_settings' },
        { text: 'Kembali', callback_data: 'main_menu' }
      ]
    ];

    await editMessage(chatId, messageId, callbackQueryId, message, {
      reply_markup: { inline_keyboard: keyboard },
      parse_mode: 'HTML'
    });

  } catch (error) {
    console.error('Error showOwnerMenu:', error);
  }
}

async function showNokosMenu(chatId, userId, messageId, callbackQueryId, page = 0) {
  try {
    const servicesData = await getServicesCached();
    
    if (!servicesData || !servicesData.success) {
      await editMessage(chatId, messageId, callbackQueryId, 
        '<b>❌ Gagal mendapatkan layanan</b>\n\nSilakan coba lagi nanti.',
        { parse_mode: 'HTML' }
      );
      return;
    }

    const services = servicesData.data;
    
    // Filter layanan populer berdasarkan screenshot
    const popularServiceNames = [
      'whatsapp', 'telegram', 'dana', 'instagram', 'indomaret', 'tiktok'
    ];
    
    const popularServices = [];
    const otherServices = [];
    
    for (const service of services) {
      const serviceNameLower = service.service_name.toLowerCase();
      
      // Cek apakah termasuk layanan populer
      let isPopular = false;
      for (const popularName of popularServiceNames) {
        if (serviceNameLower.includes(popularName)) {
          isPopular = true;
          popularServices.push(service);
          break;
        }
      }
      
      if (!isPopular) {
        otherServices.push(service);
      }
    }
    
    // Sort popular services sesuai urutan yang diinginkan
    const orderedPopular = [];
    for (const popularName of popularServiceNames) {
      const found = popularServices.find(s => 
        s.service_name.toLowerCase().includes(popularName)
      );
      if (found) {
        orderedPopular.push(found);
      }
    }
    
    // Sort other services alphabetically
    otherServices.sort((a, b) => a.service_name.localeCompare(b.service_name));

    // Pagination untuk layanan lainnya
    const itemsPerPage = 6;
    const totalOtherPages = Math.ceil(otherServices.length / itemsPerPage);
    
    // Validasi page
    if (page < 0) page = 0;
    if (page >= totalOtherPages && totalOtherPages > 0) page = totalOtherPages - 1;
    
    const startIndex = page * itemsPerPage;
    const endIndex = Math.min(startIndex + itemsPerPage, otherServices.length);
    const pageOtherServices = otherServices.slice(startIndex, endIndex);

    // Buat pesan sesuai format
    let message = `<b>📱 Layanan Nokos</b>\n\n`;
    message += `<i>Pilih layanan untuk order nomor OTP</i>\n\n`;
    message += `<b>🌟 Layanan Populer:</b>\n`;
    
    orderedPopular.forEach((service, index) => {
      message += `${index + 1}. ${service.service_name}\n`;
    });
    
    message += `\n<b>📋 Layanan Lainnya</b> (Halaman ${page + 1}/${totalOtherPages})\n\n`;
    
    pageOtherServices.forEach((service, index) => {
      const globalNumber = startIndex + index + 1;
      let displayName = service.service_name;
      if (displayName.length > 12) {
        displayName = displayName.substring(0, 10) + '..';
      }
      message += `${globalNumber}. ${displayName}\n`;
    });
    
    message += `\n`;

    const keyboard = [];
    
    // TOMBOL LAYANAN POPULER - 2 per baris
    for (let i = 0; i < orderedPopular.length; i += 2) {
      const row = [];
      
      if (orderedPopular[i]) {
        const service = orderedPopular[i];
        let buttonText = service.service_name;
        if (buttonText.length > 10) {
          buttonText = buttonText.substring(0, 8) + '..';
        }
        row.push({ 
          text: buttonText, 
          callback_data: `nokos_service_${service.service_code}` 
        });
      }
      
      if (orderedPopular[i + 1]) {
        const service = orderedPopular[i + 1];
        let buttonText = service.service_name;
        if (buttonText.length > 10) {
          buttonText = buttonText.substring(0, 8) + '..';
        }
        row.push({ 
          text: buttonText, 
          callback_data: `nokos_service_${service.service_code}` 
        });
      }
      
      if (row.length > 0) {
        keyboard.push(row);
      }
    }

    // TOMBOL LAYANAN LAINNYA - 2 per baris
    for (let i = 0; i < pageOtherServices.length; i += 2) {
      const row = [];
      
      if (pageOtherServices[i]) {
        const service = pageOtherServices[i];
        const globalNumber = startIndex + i + 1;
        let buttonText = service.service_name;
        if (buttonText.length > 10) {
          buttonText = buttonText.substring(0, 8) + '..';
        }
        row.push({ 
          text: `${globalNumber}. ${buttonText}`, 
          callback_data: `nokos_service_${service.service_code}` 
        });
      }
      
      if (pageOtherServices[i + 1]) {
        const service = pageOtherServices[i + 1];
        const globalNumber = startIndex + i + 2;
        let buttonText = service.service_name;
        if (buttonText.length > 10) {
          buttonText = buttonText.substring(0, 8) + '..';
        }
        row.push({ 
          text: `${globalNumber}. ${buttonText}`, 
          callback_data: `nokos_service_${service.service_code}` 
        });
      }
      
      if (row.length > 0) {
        keyboard.push(row);
      }
    }

    // NAVIGATION BUTTONS
    if (totalOtherPages > 1) {
      const navRow = [];
      
      // Tombol Previous (◀️) - hanya aktif jika bukan halaman pertama
      if (page > 0) {
        navRow.push({ 
          text: '◀️', 
          callback_data: `nokos_menu_prev_${page}` // Gunakan format yang berbeda
        });
      } else {
        navRow.push({ 
          text: '◀️', 
          callback_data: 'no_action' 
        });
      }
      
      // Info halaman
      navRow.push({ 
        text: `${page + 1}/${totalOtherPages}`, 
        callback_data: 'no_action' 
      });
      
      // Tombol Next (▶️) - hanya aktif jika bukan halaman terakhir
      if (page < totalOtherPages - 1) {
        navRow.push({ 
          text: '▶️', 
          callback_data: `nokos_menu_next_${page}` // Gunakan format yang berbeda
        });
      } else {
        navRow.push({ 
          text: '▶️', 
          callback_data: 'no_action' 
        });
      }
      
      keyboard.push(navRow);
    }

    // SEARCH BUTTON
    keyboard.push([
      { text: '🔍 Cari Layanan', callback_data: 'search_service' }
    ]);

    // MAIN NAVIGATION
    keyboard.push([
      { text: '🏠 Menu Utama', callback_data: 'main_menu' }
    ]);

    await editMessage(chatId, messageId, callbackQueryId, message, {
      reply_markup: { inline_keyboard: keyboard },
      parse_mode: 'HTML'
    });
    
    // Di awal fungsi showNokosMenu, tambahkan:
    console.log(`showNokosMenu called - userId: ${userId}, page: ${page}`);

  } catch (error) {
    console.error('Error in showNokosMenu:', error);
    await editMessage(chatId, messageId, callbackQueryId,
      '❌ Gagal memuat menu layanan.\n\nSilakan coba lagi.',
      { 
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: '🔄 Coba Lagi', callback_data: 'nokos_menu_page_0' }]
          ]
        }
      }
    );
  }
}

async function showDepositMenu(chatId, userId, messageId, callbackQueryId) {
  const userBalance = getUserBalance(userId);
  const activeProvider = config.active_provider || 'rumahotp';
  
  let message = `
<b>💰 Topup Saldo</b>

<i>Saldo saat ini:</i> <b>${formatCurrency(userBalance)}</b>

<b>Informasi:</b>
Minimal: Rp 2,000
Maksimal: Rp 5,000,000
Metode: QRIS

<b>Pilih nominal:</b>`;

  userSelections.set(userId, { step: 'rumahotp_deposit_amount' });
  
  await editMessage(chatId, messageId, callbackQueryId, message, {
    reply_markup: { 
      inline_keyboard: [
        [
          { text: '5K', callback_data: 'deposit_amount_5000' },
          { text: '10K', callback_data: 'deposit_amount_10000' },
          { text: '15K', callback_data: 'deposit_amount_15000' }
        ],
        [
          { text: '20K', callback_data: 'deposit_amount_20000' },
          { text: '30K', callback_data: 'deposit_amount_30000' },
          { text: '50K', callback_data: 'deposit_amount_50000' }
        ],
        [
          { text: '100K', callback_data: 'deposit_amount_100000' },
          { text: '500K', callback_data: 'deposit_amount_500000' },
          { text: '1 JT', callback_data: 'deposit_amount_1000000' }
        ],
        [
          { text: 'Custom', callback_data: 'deposit_custom' },
          { text: 'Kembali', callback_data: 'main_menu' }
        ]
      ] 
    },
    parse_mode: 'HTML'
  });
}

async function showOtherServices(chatId, userId, messageId, callbackQueryId, page = 0) {
    try {
        // Gunakan cache untuk services
        const servicesData = await getServicesCached();
        
        if (!servicesData || !servicesData.success) {
            await editMessage(chatId, messageId, callbackQueryId, 
                '<b>❌ Gagal mendapatkan layanan</b>\n\nSilakan coba lagi nanti.',
                { parse_mode: 'HTML' }
            );
            return;
        }

        const services = servicesData.data;

        // Filter layanan lainnya (tidak populer)
        const popularServiceNames = [
            'whatsapp', 'telegram', 'instagram', 'facebook', 
            'gojek', 'gopay', 'ovo', 'dana', 'tiktok', 'twitter'
        ];
        
        // Gunakan cache untuk hasil filter
        const cacheKey = 'other_services_filtered';
        let otherServices = servicesCache[cacheKey];
        
        if (!otherServices) {
            otherServices = [];
            for (const service of services) {
                const serviceNameLower = service.service_name.toLowerCase();
                let isPopular = false;
                
                for (const popularName of popularServiceNames) {
                    if (serviceNameLower.includes(popularName)) {
                        isPopular = true;
                        break;
                    }
                }
                
                if (!isPopular) {
                    otherServices.push(service);
                }
            }
            // Sort services alphabetically
            otherServices.sort((a, b) => a.service_name.localeCompare(b.service_name));
            servicesCache[cacheKey] = otherServices;
        }

        if (otherServices.length === 0) {
            await editMessage(chatId, messageId, callbackQueryId, 
                '<b>Layanan Lainnya</b>\n\nTidak ada layanan lainnya.',
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '🔙 Kembali', callback_data: 'nokos_menu' }]
                        ]
                    }
                }
            );
            return;
        }

        const itemsPerPage = 10;
        const totalPages = Math.ceil(otherServices.length / itemsPerPage);
        
        // Validasi page
        if (page < 0) page = 0;
        if (page >= totalPages) page = totalPages - 1;
        
        const startIndex = page * itemsPerPage;
        const endIndex = Math.min(startIndex + itemsPerPage, otherServices.length);
        const pageServices = otherServices.slice(startIndex, endIndex);

        let message = `<b>📱 Layanan Lainnya</b>\n\n`;
        message += `<b>Total:</b> ${otherServices.length} layanan\n`;
        message += `<b>Halaman:</b> ${page + 1}/${totalPages}\n\n`;
        
        const keyboard = [];
        
        // Tampilkan layanan dengan nomor urut
        pageServices.forEach((service, index) => {
            const serviceNumber = startIndex + index + 1;
            const buttonText = `${serviceNumber}. ${service.service_name.substring(0, 25)}`;
            
            keyboard.push([
                { 
                    text: buttonText, 
                    callback_data: `nokos_service_${service.service_code}` 
                }
            ]);
        });

        // Navigation buttons - GESER NEXT DAN PREVIOUS
        const navButtons = [];
        
        // Tombol Previous
        if (page > 0) {
            navButtons.push({ 
                text: '◀️ Sebelumnya', 
                callback_data: `other_services_page_${page - 1}` 
            });
        } else {
            navButtons.push({ 
                text: '◀️', 
                callback_data: 'no_action' 
            });
        }
        
        // Info halaman
        navButtons.push({ 
            text: `📄 ${page + 1}/${totalPages}`, 
            callback_data: 'no_action' 
        });
        
        // Tombol Next
        if (page < totalPages - 1) {
            navButtons.push({ 
                text: '▶️ Berikutnya', 
                callback_data: `other_services_page_${page + 1}` 
            });
        } else {
            navButtons.push({ 
                text: '▶️', 
                callback_data: 'no_action' 
            });
        }
        
        if (navButtons.length > 0) {
            keyboard.push(navButtons);
        }

        // Search button
        keyboard.push([
            { text: '🔍 Cari Layanan', callback_data: 'search_service' },
            { text: '🔙 Kembali', callback_data: 'nokos_menu' }
        ]);

        keyboard.push([
            { text: '🏠 Menu Utama', callback_data: 'main_menu' }
        ]);

        await editMessage(chatId, messageId, callbackQueryId, message, {
            reply_markup: { inline_keyboard: keyboard },
            parse_mode: 'HTML'
        });

    } catch (error) {
        console.error('Error in showOtherServices:', error);
        await editMessage(chatId, messageId, callbackQueryId, 
            '❌ Gagal memuat layanan.\n\nSilakan coba lagi.',
            { 
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: 'Coba Lagi', callback_data: 'nokos_menu' }]
                    ]
                }
            }
        );
    }
}

async function showCountryMenu(chatId, userId, serviceId, serviceName, messageId, callbackQueryId, page = 0) {
    try {
        const itemsPerPage = 30;
        
        let userSelection = userSelections.get(userId) || {};
        userSelection.step = 'nokos_country';
        userSelection.serviceId = serviceId;
        userSelection.serviceName = serviceName;
        userSelections.set(userId, userSelection);

        let countriesData;
        
        if (config.active_provider === 'otpnum') {
            // Get countries from OTPNUM
            const result = await otpnumService.getCountries();
            if (result && result.success) {
                countriesData = {
                    success: true,
                    data: result.data.countries || []
                };
            }
        } else {
            countriesData = await api.getCountries(serviceId);
        }
        
        if (!countriesData || !countriesData.success) {
            await editMessage(chatId, messageId, callbackQueryId, 
                '❌ Gagal mendapatkan daftar negara.\n\nSilakan coba lagi.',
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '🔙 Kembali', callback_data: `nokos_service_${serviceId}` }]
                        ]
                    }
                }
            );
            return;
        }

        const allCountries = countriesData.data || [];
        
        if (allCountries.length === 0) {
            await editMessage(chatId, messageId, callbackQueryId, 
                `❌ Tidak ada negara tersedia untuk ${serviceName}.`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '📱 Pilih Layanan Lain', callback_data: 'nokos_menu' }]
                        ]
                    }
                }
            );
            return;
        }
        
        // Sort countries: Indonesia first, then others
        const indonesiaCountries = [];
        const otherCountries = [];
        
        for (const country of allCountries) {
            const countryNameLower = country.name.toLowerCase();
            if (countryNameLower.includes('indonesia') || countryNameLower.includes('indo')) {
                indonesiaCountries.push(country);
            } else {
                otherCountries.push(country);
            }
        }
        
        otherCountries.sort((a, b) => a.name.localeCompare(b.name));
        const sortedCountries = [...indonesiaCountries, ...otherCountries];

        const totalPages = Math.ceil(sortedCountries.length / itemsPerPage);
        if (page < 0) page = 0;
        if (page >= totalPages) page = totalPages - 1;

        const startIndex = page * itemsPerPage;
        const endIndex = Math.min(startIndex + itemsPerPage, sortedCountries.length);
        const currentCountries = sortedCountries.slice(startIndex, endIndex);

        let message = `<b>🌍 Pilih Negara</b>\n`;
        message += `📱 Layanan: ${serviceName}\n`;
        message += `📄 Halaman: ${page + 1}/${totalPages}\n`;
        message += `🌐 Total: ${sortedCountries.length} negara\n\n`;
        
        const keyboard = [];
        
        // 5 tombol per baris
        for (let i = 0; i < currentCountries.length; i += 5) {
            const row = [];
            
            for (let j = 0; j < 5; j++) {
                if (currentCountries[i + j]) {
                    const country = currentCountries[i + j];
                    const flagEmoji = getFlagEmoji(country.name);
                    
                    let countryText = country.name;
                    if (countryText.length > 10) {
                        countryText = countryText.substring(0, 8) + '..';
                    }
                    
                    // For OTPNUM, store country ID
                    const callbackData = config.active_provider === 'otpnum' 
                        ? `nokos_server_list_${country.id}_${encodeURIComponent(country.name)}`
                        : `nokos_server_list_${country.number_id}_${encodeURIComponent(country.name)}`;
                    
                    row.push({ 
                        text: `${flagEmoji} ${countryText}`, 
                        callback_data: callbackData
                    });
                } else {
                    row.push({ 
                        text: '⬜', 
                        callback_data: 'no_action' 
                    });
                }
            }
            
            if (row.length > 0) {
                keyboard.push(row);
            }
        }

        // Navigation buttons
        const navButtons = [];
        if (page > 0) {
            navButtons.push({ 
                text: '◀️ Sebelumnya', 
                callback_data: `nokos_country_page_${serviceId}_${page - 1}` 
            });
        } else {
            navButtons.push({ 
                text: '◀️', 
                callback_data: 'no_action' 
            });
        }

        navButtons.push({ 
            text: `📄 ${page + 1}/${totalPages}`, 
            callback_data: 'no_action' 
        });

        if (page < totalPages - 1) {
            navButtons.push({ 
                text: '▶️ Berikutnya', 
                callback_data: `nokos_country_page_${serviceId}_${page + 1}` 
            });
        } else {
            navButtons.push({ 
                text: '▶️', 
                callback_data: 'no_action' 
            });
        }
        
        keyboard.push(navButtons);

        keyboard.push([
            { text: '🔍 Cari Negara', callback_data: `search_country_${serviceId}` },
            { text: '📱 Layanan', callback_data: 'nokos_menu' }
        ]);

        keyboard.push([
            { text: '🏠 Menu Utama', callback_data: 'main_menu' }
        ]);

        await editMessage(chatId, messageId, callbackQueryId, message, {
            reply_markup: { inline_keyboard: keyboard },
            parse_mode: 'HTML'
        });

    } catch (error) {
        console.error('Error in showCountryMenu:', error);
        await editMessage(chatId, messageId, callbackQueryId,
            '❌ Terjadi kesalahan.\n\nSilakan coba lagi.',
            { 
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '🔄 Coba Lagi', callback_data: `nokos_service_${serviceId}` }],
                        [{ text: '🏠 Menu Utama', callback_data: 'main_menu' }]
                    ]
                }
            }
        );
    }
}

async function showSearchService(chatId, userId, messageId, callbackQueryId) {
    try {
        // Set user selection untuk menunggu input pencarian
        userSelections.set(userId, {
            step: 'search_service_input',
            timestamp: Date.now()
        });

        await editMessage(chatId, messageId, callbackQueryId,
            `<b>🔍 CARI LAYANAN</b>\n\n` +
            `Masukkan nama layanan yang ingin dicari:\n\n` +
            `Contoh: <code>whatsapp</code>\n` +
            `Contoh: <code>telegram</code>\n` +
            `Contoh: <code>instagram</code>\n\n` +
            `<i>Ketik 0 untuk membatalkan</i>`,
            {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '🔙 Kembali', callback_data: 'nokos_other_services_0' }]
                    ]
                }
            }
        );

    } catch (error) {
        console.error('Error in showSearchService:', error);
        await editMessage(chatId, messageId, callbackQueryId,
            '❌ Gagal memuat pencarian.',
            { parse_mode: 'HTML' }
        );
    }
}

async function searchService(chatId, userId, searchTerm, messageId) {
    try {
        const servicesData = await getServicesCached();
        
        if (!servicesData || !servicesData.success) {
            await sendNewMessage(chatId,
                '❌ Gagal mendapatkan data layanan.',
                { parse_mode: 'HTML' }
            );
            return;
        }

        const services = servicesData.data;
        
        // Filter services yang mengandung searchTerm (case insensitive)
        const searchLower = searchTerm.toLowerCase();
        const matchedServices = services.filter(service => 
            service.service_name.toLowerCase().includes(searchLower)
        );

        if (matchedServices.length === 0) {
            await sendNewMessage(chatId,
                `<b>🔍 HASIL PENCARIAN</b>\n\n` +
                `Pencarian: <code>${searchTerm}</code>\n` +
                `Hasil: Tidak ditemukan\n\n` +
                `<i>Coba dengan kata kunci lain</i>`,
                {
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '🔍 Cari Lagi', callback_data: 'search_service' }],
                            [{ text: '📱 Semua Layanan', callback_data: 'nokos_other_services_0' }]
                        ]
                    }
                }
            );
            return;
        }

        // Sort by relevance (exact match first, then alphabetical)
        matchedServices.sort((a, b) => {
            const aName = a.service_name.toLowerCase();
            const bName = b.service_name.toLowerCase();
            
            // Exact match priority
            if (aName === searchLower) return -1;
            if (bName === searchLower) return 1;
            
            // Starts with priority
            if (aName.startsWith(searchLower) && !bName.startsWith(searchLower)) return -1;
            if (!aName.startsWith(searchLower) && bName.startsWith(searchLower)) return 1;
            
            // Alphabetical
            return aName.localeCompare(bName);
        });

        const displayServices = matchedServices.slice(0, 15); // Maksimal 15 hasil

        let message = `<b>🔍 HASIL PENCARIAN</b>\n\n`;
        message += `Pencarian: <code>${searchTerm}</code>\n`;
        message += `Ditemukan: ${matchedServices.length} layanan\n\n`;

        const keyboard = [];

        displayServices.forEach((service, index) => {
            const buttonText = `${index + 1}. ${service.service_name}`;
            keyboard.push([
                { 
                    text: buttonText, 
                    callback_data: `nokos_service_${service.service_code}` 
                }
            ]);
        });

        if (matchedServices.length > 15) {
            message += `<i>... dan ${matchedServices.length - 15} layanan lainnya</i>\n\n`;
        }

        keyboard.push([
            { text: '🔍 Cari Lagi', callback_data: 'search_service' },
            { text: '📱 Semua Layanan', callback_data: 'nokos_other_services_0' }
        ]);

        keyboard.push([
            { text: '🏠 Menu Utama', callback_data: 'main_menu' }
        ]);

        await sendNewMessage(chatId, message, {
            parse_mode: 'HTML',
            reply_markup: { inline_keyboard: keyboard }
        });

    } catch (error) {
        console.error('Error in searchService:', error);
        await sendNewMessage(chatId,
            '❌ Gagal melakukan pencarian.',
            { parse_mode: 'HTML' }
        );
    }
}

async function showSearchCountry(chatId, userId, serviceId, messageId, callbackQueryId) {
    try {
        // Set user selection untuk menunggu input pencarian negara
        userSelections.set(userId, {
            step: 'search_country_input',
            serviceId: serviceId,
            timestamp: Date.now()
        });

        await editMessage(chatId, messageId, callbackQueryId,
            `<b>🔍 CARI NEGARA</b>\n\n` +
            `Masukkan nama negara yang ingin dicari:\n\n` +
            `Contoh: <code>indonesia</code>\n` +
            `Contoh: <code>malaysia</code>\n` +
            `Contoh: <code>singapore</code>\n\n` +
            `<i>Ketik 0 untuk membatalkan</i>`,
            {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '🔙 Kembali', callback_data: `nokos_service_${serviceId}` }]
                    ]
                }
            }
        );

    } catch (error) {
        console.error('Error in showSearchCountry:', error);
        await editMessage(chatId, messageId, callbackQueryId,
            '❌ Gagal memuat pencarian.',
            { parse_mode: 'HTML' }
        );
    }
}

async function searchCountry(chatId, userId, serviceId, searchTerm, messageId) {
    try {
        const countriesData = await api.getCountries(serviceId);
        
        if (!countriesData || !countriesData.success) {
            await sendNewMessage(chatId,
                '❌ Gagal mendapatkan data negara.',
                { parse_mode: 'HTML' }
            );
            return;
        }

        const countries = countriesData.data || [];
        
        // Filter countries yang mengandung searchTerm (case insensitive)
        const searchLower = searchTerm.toLowerCase();
        const matchedCountries = countries.filter(country => 
            country.name.toLowerCase().includes(searchLower)
        );

        // Dapatkan info layanan
        const servicesData = await getServicesCached();
        const service = servicesData?.data?.find(s => s.service_code == serviceId);
        const serviceName = service?.service_name || 'Layanan';

        if (matchedCountries.length === 0) {
            await sendNewMessage(chatId,
                `<b>🔍 HASIL PENCARIAN NEGARA</b>\n\n` +
                `Layanan: ${serviceName}\n` +
                `Pencarian: <code>${searchTerm}</code>\n` +
                `Hasil: Tidak ditemukan\n\n` +
                `<i>Coba dengan kata kunci lain</i>`,
                {
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '🔍 Cari Lagi', callback_data: `search_country_${serviceId}` }],
                            [{ text: '🌍 Semua Negara', callback_data: `nokos_service_${serviceId}` }]
                        ]
                    }
                }
            );
            return;
        }

        // Sort countries alphabetically
        matchedCountries.sort((a, b) => a.name.localeCompare(b.name));

        const displayCountries = matchedCountries.slice(0, 20); // Maksimal 20 hasil

        let message = `<b>🔍 HASIL PENCARIAN NEGARA</b>\n\n`;
        message += `📱 Layanan: ${serviceName}\n`;
        message += `🔍 Pencarian: <code>${searchTerm}</code>\n`;
        message += `🌐 Ditemukan: ${matchedCountries.length} negara\n\n`;

        const keyboard = [];

        // 2 tombol per baris untuk hasil pencarian
        for (let i = 0; i < displayCountries.length; i += 2) {
            const row = [];
            
            if (displayCountries[i]) {
                const country = displayCountries[i];
                const flagEmoji = getFlagEmoji(country.iso_code);
                let countryText = country.name;
                if (countryText.length > 15) {
                    countryText = countryText.substring(0, 12) + '..';
                }
                
                row.push({ 
                    text: `${flagEmoji} ${countryText}`, 
                    callback_data: `nokos_server_list_${country.number_id}_${encodeURIComponent(country.name)}` 
                });
            }
            
            if (displayCountries[i + 1]) {
                const country = displayCountries[i + 1];
                const flagEmoji = getFlagEmoji(country.iso_code);
                let countryText = country.name;
                if (countryText.length > 15) {
                    countryText = countryText.substring(0, 12) + '..';
                }
                
                row.push({ 
                    text: `${flagEmoji} ${countryText}`, 
                    callback_data: `nokos_server_list_${country.number_id}_${encodeURIComponent(country.name)}` 
                });
            }
            
            if (row.length > 0) {
                keyboard.push(row);
            }
        }

        if (matchedCountries.length > 20) {
            message += `<i>... dan ${matchedCountries.length - 20} negara lainnya</i>\n\n`;
        }

        keyboard.push([
            { text: '🔍 Cari Lagi', callback_data: `search_country_${serviceId}` },
            { text: '🌍 Semua Negara', callback_data: `nokos_service_${serviceId}` }
        ]);

        keyboard.push([
            { text: '🏠 Menu Utama', callback_data: 'main_menu' }
        ]);

        await sendNewMessage(chatId, message, {
            parse_mode: 'HTML',
            reply_markup: { inline_keyboard: keyboard }
        });

    } catch (error) {
        console.error('Error in searchCountry:', error);
        await sendNewMessage(chatId,
            '❌ Gagal melakukan pencarian negara.',
            { parse_mode: 'HTML' }
        );
    }
}

// Modifikasi fungsi showServerList yang sudah ada
async function showServerList(chatId, userId, countryId, countryName, messageId, callbackQueryId) {
    try {
        let userSelection = userSelections.get(userId);
        
        if (!userSelection || !userSelection.serviceId) {
            await editMessage(chatId, messageId, callbackQueryId,
                '❌ Sesi Tidak Lengkap\n\nSilakan pilih layanan dari awal.',
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '📱 Mulai Dari Awal', callback_data: 'nokos_menu' }]
                        ]
                    }
                }
            );
            return;
        }
        
        let servicesData;
        
        if (config.active_provider === 'otpnum') {
            // Get services from OTPNUM
            const result = await otpnumService.getServices(parseInt(countryId));
            if (result && result.success) {
                servicesData = {
                    success: true,
                    data: result.data.services || []
                };
            }
        } else {
            // Use RumahOTP API
            const countriesData = await api.getCountries(userSelection.serviceId);
            if (countriesData && countriesData.success) {
                const countries = countriesData.data || [];
                const selectedCountry = countries.find(c => c.number_id == countryId);
                if (selectedCountry && selectedCountry.pricelist) {
                    servicesData = {
                        success: true,
                        data: selectedCountry.pricelist
                    };
                }
            }
        }
        
        if (!servicesData || !servicesData.success) {
            await editMessage(chatId, messageId, callbackQueryId,
                '❌ Gagal memuat data server.\n\nSilakan coba lagi.',
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '🔄 Coba Lagi', callback_data: `nokos_service_${userSelection.serviceId}` }]
                        ]
                    }
                }
            );
            return;
        }
        
        let servers = servicesData.data || [];
        
        if (config.active_provider === 'otpnum') {
            // Filter services that match the selected service ID
            servers = servers.filter(s => s.service_id == userSelection.serviceId);
            
            // Format for OTPNUM
            servers = servers.map(server => ({
                provider_id: server.service_id,
                price: server.price,
                rate: server.profit || 0,
                stock: server.stock || 0,
                service_name: server.service_name
            }));
        }
        
        servers.sort((a, b) => a.price - b.price);

        const serversWithProfit = servers.map(server => ({
            ...server,
            original_price: server.price,
            final_price: addProfitToPrice(server.price),
            profit: Number(config.UNTUNG_NOKOS) || 0
        }));

        userSelection.step = 'nokos_server';
        userSelection.countryId = countryId;
        userSelection.countryName = countryName;
        userSelection.servers = serversWithProfit;
        userSelections.set(userId, userSelection);
        
        const profitAmount = Number(config.UNTUNG_NOKOS) || 0;
        
        let message = `<b>🌍 ${countryName}</b>\n`;
        message += `📱 Layanan: ${userSelection.serviceName}\n`;
        message += `🖥️ Server: ${servers.length} tersedia\n`;
        
        const maxButtons = 15;
        const serversToShow = serversWithProfit.slice(0, maxButtons);
        
        message += `\n<b>💰 Harga Server (dengan profit):</b>\n`;
        for (let i = 0; i < Math.min(serversToShow.length, 15); i++) {
            const server = serversToShow[i];
            const serverNumber = i + 1;
            message += `S${serverNumber}: ${formatCurrency(server.final_price)}`;
            if (i % 3 === 2 || i === serversToShow.length - 1) {
                message += '\n';
            } else {
                message += ' | ';
            }
        }
        message += '\n';
        
        const keyboard = [];
        const buttonsPerRow = 3;
        
        for (let i = 0; i < serversToShow.length; i += buttonsPerRow) {
            const row = [];
            for (let j = 0; j < buttonsPerRow; j++) {
                if (serversToShow[i + j]) {
                    const server = serversToShow[i + j];
                    const serverNumber = i + j + 1;
                    const buttonText = `S${serverNumber}`;
                    
                    let callbackData;
                    if (config.active_provider === 'otpnum') {
                        callbackData = `nokos_server_${server.provider_id}_${server.final_price}_${server.rate}_${server.stock}`;
                    } else {
                        callbackData = `nokos_server_${server.provider_id}_${server.final_price}_${server.rate}_${server.stock}`;
                    }
                    
                    row.push({ 
                        text: buttonText, 
                        callback_data: callbackData
                    });
                }
            }
            if (row.length > 0) {
                keyboard.push(row);
            }
        }
        
        keyboard.push([
            { text: '🌍 Kembali ke Negara', callback_data: `nokos_service_${userSelection.serviceId}` },
            { text: '🏠 Menu Utama', callback_data: 'main_menu' }
        ]);
        
        await editMessage(chatId, messageId, callbackQueryId, message, {
            reply_markup: { inline_keyboard: keyboard },
            parse_mode: 'HTML'
        });
        
    } catch (error) {
        console.error('Error in showServerList:', error);
        await editMessage(chatId, messageId, callbackQueryId,
            '❌ Terjadi kesalahan.\n\nSilakan coba lagi.',
            { 
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '🔄 Coba Lagi', callback_data: `nokos_service_${userSelections.get(userId)?.serviceId || 'nokos_menu'}` }]
                    ]
                }
            }
        );
    }
}

async function showServerListEnhanced(chatId, userId, numberId, countryName, messageId, callbackQueryId, startIndex = 0) {
    try {
        let userSelection = userSelections.get(userId);
        
        if (!userSelection || !userSelection.serviceId) {
            await editMessage(chatId, messageId, callbackQueryId,
                'Sesi tidak lengkap.\n\nSilakan pilih layanan dari awal.',
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Mulai Dari Awal', callback_data: 'nokos_menu' }]
                        ]
                    }
                }
            );
            return;
        }
        
        await editMessage(chatId, messageId, callbackQueryId,
            'Memuat server...',
            { parse_mode: 'HTML' }
        );
        
        const countriesData = await api.getCountries(userSelection.serviceId);
        if (!countriesData || !countriesData.success) {
            await editMessage(chatId, messageId, callbackQueryId,
                'Gagal memuat data.\n\nSilakan coba lagi.',
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Coba Lagi', callback_data: `nokos_service_${userSelection.serviceId}` }]
                        ]
                    }
                }
            );
            return;
        }
        
        const countries = countriesData.data || [];
        const selectedCountry = countries.find(c => c.number_id == numberId);
        
        if (!selectedCountry || !selectedCountry.pricelist || selectedCountry.pricelist.length === 0) {
            await editMessage(chatId, messageId, callbackQueryId,
                `Tidak ada server tersedia untuk ${countryName}.`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Pilih Negara Lain', callback_data: `nokos_service_${userSelection.serviceId}` }]
                        ]
                    }
                }
            );
            return;
        }
        
        let servers = selectedCountry.pricelist;
        servers.sort((a, b) => a.price - b.price);

        userSelection.step = 'nokos_server';
        userSelection.numberId = numberId;
        userSelection.countryName = countryName;
        userSelection.countryData = selectedCountry;
        userSelections.set(userId, userSelection);
        
        const flagEmoji = getFlagEmoji(selectedCountry.iso_code);
        const countryCode = getCountryCode(selectedCountry.iso_code); 
        const serversPerPage = 9;
        const currentPage = Math.floor(startIndex / serversPerPage) + 1;
        const totalPages = Math.ceil(servers.length / serversPerPage);
        const displayStart = (currentPage - 1) * serversPerPage;
        const displayEnd = displayStart + serversPerPage;
        const displayServers = servers.slice(displayStart, displayEnd);
        
        let message = `<b>${flagEmoji} ${countryName}</b>\n`;
        message += `<i>Layanan:</i> ${userSelection.serviceName}\n`;
        message += `<i>Stok Total:</i> ${selectedCountry.stock_total} nomor\n`;
        message += `<i>Server Tersedia:</i> ${servers.length}\n`;
        message += `\n<b>Pilih Server:</b> Halaman ${currentPage}/${totalPages}\n\n`;

        const rowsPerGrid = 3;
        for (let row = 0; row < rowsPerGrid; row++) {
            const rowStart = row * rowsPerGrid;
            const rowServers = displayServers.slice(rowStart, rowStart + rowsPerGrid);
            
            if (rowServers.length === 0) break;
            
            message += `<b>`;
            rowServers.forEach((server, colIndex) => {
                const serverNumber = displayStart + rowStart + colIndex + 1;
                message += `S${serverNumber} `;
            });
            message += `</b>\n`;
            
            rowServers.forEach((server, colIndex) => {
                const serverNumber = displayStart + rowStart + colIndex + 1;
                message += `Rp${server.price.toLocaleString('id-ID')} `;
            });
            message += `\n`;
            
            rowServers.forEach((server, colIndex) => {
                message += `(${server.rate}%) `;
            });
            message += `\n`;
            
            message += `\n`;
        }
        
        const keyboard = [];
        
        for (let row = 0; row < rowsPerGrid; row++) {
            const rowStart = row * rowsPerGrid;
            const rowServers = displayServers.slice(rowStart, rowStart + rowsPerGrid);
            
            if (rowServers.length === 0) break;
            
            const buttonRow = [];
            rowServers.forEach((server, colIndex) => {
                const serverNumber = displayStart + rowStart + colIndex + 1;
                const buttonText = `S${serverNumber}`; 
                const callbackData = `nokos_server_${server.provider_id}_${server.price}_${server.rate}_${server.stock}`;
                
                buttonRow.push({ 
                    text: buttonText, 
                    callback_data: callbackData 
                });
            });
            
            if (buttonRow.length > 0) {
                keyboard.push(buttonRow);
            }
        }
        
        const navButtons = [];
        
        if (currentPage > 1) {
            navButtons.push({ 
                text: '◀️', 
                callback_data: `server_prev_${numberId}_${encodeURIComponent(countryName)}_${displayStart - serversPerPage}` 
            });
        } else {
            navButtons.push({ 
                text: '◀️', 
                callback_data: 'no_action' 
            });
        }
        
        navButtons.push({ 
            text: `Page ${currentPage}/${totalPages}`, 
            callback_data: 'no_action' 
        });
        
        if (currentPage < totalPages) {
            navButtons.push({ 
                text: '▶️', 
                callback_data: `server_next_${numberId}_${encodeURIComponent(countryName)}_${displayStart + serversPerPage}` 
            });
        } else {
            navButtons.push({ 
                text: '▶️', 
                callback_data: 'no_action' 
            });
        }
        
        keyboard.push(navButtons);
        
        keyboard.push([
            { text: 'Kembali', callback_data: `nokos_service_${userSelection.serviceId}` },
            { text: 'Menu Utama', callback_data: 'main_menu' }
        ]);
        
        await editMessage(chatId, messageId, callbackQueryId, message, {
            reply_markup: { inline_keyboard: keyboard },
            parse_mode: 'HTML'
        });
        
    } catch (error) {
        await editMessage(chatId, messageId, callbackQueryId,
            'Terjadi kesalahan.\n\nSilakan coba lagi.',
            { 
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: 'Coba Lagi', callback_data: `nokos_service_${userSelections.get(userId)?.serviceId || 'nokos_menu'}` }]
                    ]
                }
            }
        );
    }
}

function getCountryCode(isoCode) {
    const countryCodes = {
        'id': '+62',
        'ph': '+63',
        'us': '+1',
        'gb': '+44',
        'sg': '+65',
        'my': '+60',
        'th': '+66',
        'vn': '+84'
    };
    
    return countryCodes[isoCode?.toLowerCase()] || `+${isoCode?.toUpperCase() || '62'}`;
}

function getFlagEmoji(countryCode) {
    if (!countryCode || typeof countryCode !== 'string') return '🌐';
    const codePoints = countryCode
        .toUpperCase()
        .split('')
        .map(char => 127397 + char.charCodeAt());
    return String.fromCodePoint(...codePoints);
}

async function showOperatorMenu(chatId, userId, numberId, price, countryName, messageId, callbackQueryId) {
    try {
        const userSelection = userSelections.get(userId);
        
        if (!userSelection) {
            await editMessage(chatId, messageId, callbackQueryId,
                '❌ Sesi tidak ditemukan.\n\nSilakan mulai kembali dari menu utama.',
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Menu Utama', callback_data: 'main_menu' }]
                        ]
                    }
                }
            );
            return;
        }
        
        // Update user selection - price sudah termasuk profit
        userSelection.step = 'nokos_operator';
        userSelection.numberId = numberId;
        userSelection.price = Number(price); // Ini sudah termasuk profit
        userSelection.countryName = countryName;
        userSelections.set(userId, userSelection);

        await editMessage(chatId, messageId, callbackQueryId,
            '⏳ Mencari operator...',
            { parse_mode: 'HTML' }
        );

        const countriesData = await api.getCountries(userSelection.serviceId);
        
        if (!countriesData || !countriesData.success) {
            await editMessage(chatId, messageId, callbackQueryId,
                '❌ Gagal mendapatkan data operator.\n\nSilakan coba lagi.',
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Coba Lagi', callback_data: `nokos_server_list_${numberId}_${encodeURIComponent(countryName)}` }]
                        ]
                    }
                }
            );
            return;
        }

        const countries = countriesData.data || [];
        const selectedCountry = countries.find(c => c.number_id == numberId);
        
        if (!selectedCountry) {
            await editMessage(chatId, messageId, callbackQueryId,
                `❌ Data negara "${countryName}" tidak ditemukan.`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Kembali', callback_data: `nokos_service_${userSelection.serviceId}` }]
                        ]
                    }
                }
            );
            return;
        }

        if (!selectedCountry.pricelist || selectedCountry.pricelist.length === 0) {
            await editMessage(chatId, messageId, callbackQueryId,
                `❌ Tidak ada operator tersedia untuk ${countryName}.`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Pilih Negara Lain', callback_data: `nokos_service_${userSelection.serviceId}` }]
                        ]
                    }
                }
            );
            return;
        }

        const providerId = userSelection.providerId || selectedCountry.pricelist[0].provider_id;
        userSelection.providerId = providerId;
        userSelections.set(userId, userSelection);

        const operatorsData = await api.getOperators(selectedCountry.name, providerId);
        
        if (!operatorsData || !operatorsData.success) {
            const errorMsg = operatorsData?.message || 'Gagal terhubung ke server operator';
            await editMessage(chatId, messageId, callbackQueryId,
                `❌ ${errorMsg}`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Kembali', callback_data: `nokos_server_list_${numberId}_${encodeURIComponent(countryName)}` }]
                        ]
                    }
                }
            );
            return;
        }

        const operators = operatorsData.data || [];
        
        if (operators.length === 0) {
            await editMessage(chatId, messageId, callbackQueryId,
                `❌ Belum ada operator yang tersedia untuk ${countryName}.\n\nSilakan pilih negara lain.`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Pilih Negara Lain', callback_data: `nokos_service_${userSelection.serviceId}` }]
                        ]
                    }
                }
            );
            return;
        }

        // Hitung harga asli (tanpa profit)
        const originalPrice = removeProfitFromPrice(Number(price));
        const profit = Number(price) - originalPrice;

        let message = `<b>Pilih Operator</b>\n`;
        message += `Layanan: ${userSelection.serviceName}\n`;
        message += `Negara: ${countryName}\n`;
        message += `Harga: ${formatCurrency(Number(price))}\n`;
        
        if (userSelection.rate) {
            message += `Rate: ${userSelection.rate}%\n`;
        }
        
        message += `\n${operators.length} operator tersedia:`;

        const keyboard = [];

        const displayOperators = operators.slice(0, 6);
        
        for (let i = 0; i < displayOperators.length; i += 2) {
            const row = [];
            
            if (displayOperators[i]) {
                const op = displayOperators[i];
                const buttonText = op.name ? `${op.name.substring(0, 12)}` : `Operator ${i+1}`;
                row.push({ 
                    text: buttonText, 
                    callback_data: `nokos_operator_${op.id}_${providerId}_${price}` // price sudah termasuk profit
                });
            }
            
            if (displayOperators[i + 1]) {
                const op = displayOperators[i + 1];
                const buttonText = op.name ? `${op.name.substring(0, 12)}` : `Operator ${i+2}`;
                row.push({ 
                    text: buttonText, 
                    callback_data: `nokos_operator_${op.id}_${providerId}_${price}` 
                });
            }
            
            if (row.length > 0) {
                keyboard.push(row);
            }
        }

        if (operators.length > 6) {
            keyboard.push([
                { text: '📋 Lihat Semua Operator', callback_data: `nokos_all_operators_${numberId}_${providerId}_${price}_${encodeURIComponent(countryName)}` }
            ]);
        }

        keyboard.push([
            { 
                text: '🔙 Kembali', 
                callback_data: `nokos_server_list_${numberId}_${encodeURIComponent(countryName)}` 
            },
            { 
                text: '🏠 Menu Utama', 
                callback_data: 'main_menu' 
            }
        ]);

        await editMessage(chatId, messageId, callbackQueryId, message, {
            reply_markup: { inline_keyboard: keyboard },
            parse_mode: 'HTML'
        });

    } catch (error) {
        console.error('Error in showOperatorMenu:', error);
        await editMessage(chatId, messageId, callbackQueryId,
            '❌ Terjadi kesalahan sistem.\n\nSilakan coba lagi.',
            { 
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: 'Coba Lagi', callback_data: `nokos_server_list_${numberId}_${encodeURIComponent(countryName)}` }]
                    ]
                }
            }
        );
    }
}

async function showOrderConfirmation(chatId, userId, operatorId, providerId, price, messageId, callbackQueryId) {
    try {
        const userSelection = userSelections.get(userId);
        
        if (!userSelection) {
            console.log(`User selection not found for user ${userId}`);
            await editMessage(chatId, messageId, callbackQueryId,
                '❌ Sesi tidak ditemukan. Silakan mulai order dari awal.',
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Kembali ke Menu', callback_data: 'nokos_menu' }]
                        ]
                    }
                }
            );
            return;
        }
        
        if (!userSelection.serviceName || !userSelection.countryName) {
            console.log('Missing required data in userSelection:', userSelection);
            await editMessage(chatId, messageId, callbackQueryId,
                '❌ Data order tidak lengkap. Silakan mulai order dari awal.',
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Kembali ke Menu', callback_data: 'nokos_menu' }]
                        ]
                    }
                }
            );
            return;
        }

        const userBalance = getUserBalance(userId);
        const finalPrice = Number(price); // Sudah termasuk profit
        
        // Hitung harga asli
        const originalPrice = removeProfitFromPrice(finalPrice);
        const profit = finalPrice - originalPrice;
        
        let canOrder = userBalance >= finalPrice;      
        
        const appliedVoucher = userSelection.appliedVoucher;
        
        let discount = 0;
        let finalPriceWithVoucher = finalPrice;
        let voucherMessage = '';
        
        if (appliedVoucher && appliedVoucher.valid) {
            discount = appliedVoucher.discount;
            finalPriceWithVoucher = appliedVoucher.final_amount;
            voucherMessage = `\nVoucher: ${appliedVoucher.voucher.code}\nDiskon: ${formatCurrency(discount)}\n`;
            
            if (userBalance >= finalPriceWithVoucher) {
                canOrder = true;
            }
        }
        
        const message = `
<b>Konfirmasi Order</b>

<b>Detail Order:</b>
Layanan: ${userSelection.serviceName}
Negara: ${userSelection.countryName}
Harga: ${formatCurrency(finalPrice)} ${voucherMessage} ${discount > 0 ? `
<b>Total Setelah Diskon: ${formatCurrency(finalPriceWithVoucher)}</b>` : ''}
Saldo Anda: ${formatCurrency(userBalance)}

<b>Status:</b> ${canOrder ? '✅ Saldo Cukup' : '❌ Saldo Tidak Cukup'}

${canOrder ? 
    'Klik Lanjutkan untuk melanjutkan pembelian.' : 
    'Saldo Anda tidak cukup. Silakan deposit terlebih dahulu.'}
        `.trim();

        userSelection.operatorId = operatorId;
        userSelection.providerId = providerId;
        userSelection.price = originalPrice; // Simpan harga asli untuk keperluan internal
        userSelection.finalPrice = finalPrice; // Simpan harga final
        userSelection.profit = profit; // Simpan profit
        userSelection.discount = discount;
        userSelections.set(userId, userSelection);

        const keyboard = [];
        
        if (!appliedVoucher) {
            keyboard.push([
                { 
                    text: '🎫 Pakai Voucher', 
                    callback_data: `apply_voucher_${operatorId}_${providerId}_${finalPrice}`
                }
            ]);
        } else {
            keyboard.push([
                { 
                    text: '✏️ Ganti Voucher', 
                    callback_data: `change_voucher_${operatorId}_${providerId}_${finalPrice}`
                },
                { 
                    text: '❌ Hapus Voucher', 
                    callback_data: `remove_voucher_${operatorId}_${providerId}_${finalPrice}`
                }
            ]);
        }
        
        keyboard.push([
            { 
                text: canOrder ? '🚀 Lanjutkan' : '💰 Deposit', 
                callback_data: canOrder ? 
                    `nokos_confirm_${userSelection.numberId}_${providerId}_${operatorId}_${finalPriceWithVoucher}_${appliedVoucher ? appliedVoucher.voucher.code : 'no'}` : 
                    'deposit_main' 
            }
        ]);
        
        keyboard.push([
            { 
                text: '🔙 Kembali', 
                callback_data: `nokos_server_list_${userSelection.numberId}_${encodeURIComponent(userSelection.countryName)}` 
            },
            { 
                text: '🏠 Menu Utama', 
                callback_data: 'main_menu' 
            }
        ]);

        await editMessage(chatId, messageId, callbackQueryId, message, {
            reply_markup: { inline_keyboard: keyboard },
            parse_mode: 'HTML'
        });
    } catch (error) {
        console.error('Error in showOrderConfirmation:', error);
        await editMessage(chatId, messageId, callbackQueryId,
            '❌ Gagal menampilkan konfirmasi order.\n\nSilakan coba lagi atau hubungi admin.',
            { 
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: 'Kembali ke Menu', callback_data: 'nokos_menu' }]
                    ]
                }
            }
        );
    }
}

async function showOrderConfirmationWithVoucher(chatId, userId, operatorId, providerId, price, voucherValidation, messageId, callbackQueryId) {
    try {
        const userSelection = userSelections.get(userId);
        
        if (!userSelection) {
            await editMessage(chatId, messageId, callbackQueryId,
                '❌ Sesi tidak ditemukan.',
                { parse_mode: 'HTML' }
            );
            return;
        }

        const userBalance = getUserBalance(userId);
        const discount = voucherValidation.discount || 0;
        const finalPrice = voucherValidation.final_amount || Number(price);
        const canOrder = userBalance >= finalPrice;

        const message = `
<b>Konfirmasi Order</b>

Detail Order:
Layanan: ${userSelection.serviceName}
Negara: ${userSelection.countryName}
Harga: ${formatCurrency(price)}
Voucher: ${voucherValidation.voucher.code}
Diskon: ${formatCurrency(discount)}
<b>Total Bayar: ${formatCurrency(finalPrice)}</b>
Saldo Anda: ${formatCurrency(userBalance)}

Status: ${canOrder ? '✅ Saldo Cukup' : '❌ Saldo Tidak Cukup'}

${canOrder ? 
    'Klik Lanjutkan untuk melanjutkan pembelian.' : 
    'Saldo Anda tidak cukup. Silakan deposit terlebih dahulu.'}
        `.trim();

        // Update user selection dengan data voucher
        userSelection.operatorId = operatorId;
        userSelection.providerId = providerId;
        userSelection.price = price;
        userSelection.finalPrice = finalPrice;
        userSelection.discount = discount;
        userSelection.appliedVoucher = voucherValidation;
        userSelections.set(userId, userSelection);

        const keyboard = [
            [
                { 
                    text: '✏️ Ganti Voucher', 
                    callback_data: `change_voucher_${operatorId}_${providerId}_${price}`
                },
                { 
                    text: '❌ Hapus Voucher', 
                    callback_data: `remove_voucher_${operatorId}_${providerId}_${price}`
                }
            ],
            [
                { 
                    text: canOrder ? '🚀 Lanjutkan' : '💰 Deposit', 
                    callback_data: canOrder ? 
                        `nokos_confirm_${userSelection.numberId}_${providerId}_${operatorId}_${finalPrice}_${voucherValidation.voucher.code}` : 
                        'deposit_main' 
                }
            ],
            [
                { 
                    text: '🔙 Kembali', 
                    callback_data: `nokos_server_list_${userSelection.numberId}_${encodeURIComponent(userSelection.countryName)}` 
                },
                { 
                    text: '🏠 Menu Utama', 
                    callback_data: 'main_menu' 
                }
            ]
        ];

        await editMessage(chatId, messageId, callbackQueryId, message, {
            reply_markup: { inline_keyboard: keyboard },
            parse_mode: 'HTML'
        });

    } catch (error) {
        console.error('Error in showOrderConfirmationWithVoucher:', error);
        await editMessage(chatId, messageId, callbackQueryId,
            '❌ Gagal menampilkan konfirmasi.',
            { parse_mode: 'HTML' }
        );
    }
}

async function checkAndAutoRefund(chatId, userId, orderId, amount) {
    try {
        const transactions = loadTransactions();
        const order = transactions.nokos_orders?.find(o => 
            o.id === orderId || o.data?.orderId === orderId
        );
        
        if (!order) {
            console.log(`Order ${orderId} not found for auto-refund`);
            return;
        }

        // Cek jika OTP sudah diterima
        const otpReceived = order.data?.otpReceived === true || 
                           order.data?.otp_received === true ||
                           (order.data?.otp_code && order.data.otp_code !== '-' && order.data.otp_code !== '');
        
        // Cek jika sudah direfund
        const alreadyRefunded = order.data?.refunded === true;
        
        // Cek jika order sudah completed
        const isCompleted = order.status === 'completed' || order.data?.status === 'completed';
        
        if (otpReceived || alreadyRefunded || isCompleted) {
            console.log(`Order ${orderId} tidak memenuhi syarat auto-refund:`, {
                otpReceived,
                alreadyRefunded,
                isCompleted
            });
            return;
        }

        console.log(`Processing auto-refund for order ${orderId}`);
        
        // Update status transaksi
        updateTransactionStatus('nokos_orders', orderId, 'auto_refunded');
        
        // Refund saldo - gunakan final_price yang dibayar user
        const refundAmount = Number(order.data?.final_price || amount || 0);
        if (refundAmount > 0) {
            const refundSuccess = addUserBalance(userId, refundAmount);
            if (refundSuccess) {
                // Update transaction data
                if (transactions.nokos_orders) {
                    const orderIndex = transactions.nokos_orders.findIndex(o => 
                        o.id === orderId || o.data?.orderId === orderId
                    );
                    if (orderIndex !== -1) {
                        transactions.nokos_orders[orderIndex].data.refunded = true;
                        transactions.nokos_orders[orderIndex].data.refundedAt = new Date().toISOString();
                        transactions.nokos_orders[orderIndex].data.refundType = 'auto_5min';
                        saveTransactions(transactions);
                    }
                }
                
                // Kirim notifikasi ke user
                await sendNewMessage(chatId,
                    `💰 <b>AUTO REFUND BERHASIL</b>\n\n` +
                    `Order ID: <code>#${orderId}</code>\n` +
                    `Alasan: OTP tidak diterima dalam 5 menit\n` +
                    `Jumlah: ${formatCurrency(refundAmount)}\n` +
                    `Saldo telah dikembalikan ke akun Anda.\n\n` +
                    `Saldo sekarang: ${formatCurrency(getUserBalance(userId))}`,
                    { 
                        parse_mode: 'HTML',
                        reply_markup: {
                            inline_keyboard: [
                                [
                                    { text: '🔄 Order Baru', callback_data: 'nokos_menu' },
                                    { text: '🏠 Menu Utama', callback_data: 'main_menu' }
                                ]
                            ]
                        }
                    }
                );
                
                console.log(`Auto-refund successful for order ${orderId}: ${refundAmount}`);
            }
        }
        
    } catch (error) {
        console.error(`Error in checkAndAutoRefund for order ${orderId}:`, error);
    }
}

// Fungsi untuk mengirim OTP ke channel dengan auto-delete 5 menit
async function sendOTPToChannelWithAutoDelete(orderData, user, price, formattedOTP, voucherInfo = '') {
    try {
        const maskedPhone = maskPhoneNumber(orderData.phone_number);
        const formattedPrice = formatCurrency(price);
        const dateStr = new Date().toLocaleString('id-ID', { 
            day: 'numeric', 
            month: 'short', 
            year: 'numeric', 
            hour: '2-digit', 
            minute: '2-digit' 
        });
        
        const channelMessage = `<blockquote>✅ ORDER SUKSES - OTP DITERIMA
━━━━━━━━━━━━━━━━━
${voucherInfo}
<b>ID:</b> ${orderData.order_id}
<b>Users:</b> ${user.first_name || 'User'}
<b>Number:</b> ${maskedPhone}
<b>SMS code:</b> ${formattedOTP}
<b>Harga:</b> ${formattedPrice}
<b>Tanggal:</b> ${dateStr}

${orderData.service || 'Layanan'}: kode verifikasi anda ${formattedOTP}, Jangan diberikan pada siapapun</blockquote>`;
        
        const keyboard = {
            inline_keyboard: [
                [
                    { 
                        text: '🛒 Orders', 
                        url: 'https://t.me/andinnstorebot'
                    },
                    { 
                        text: '💬 Support', 
                        url: `https://t.me/${channel.replace('@', '')}`
                    }
                ]
            ]
        };
        
        // Kirim pesan ke channel
        const sentMessage = await bot.sendMessage(channel, channelMessage, {
            parse_mode: 'HTML',
            disable_web_page_preview: true,
            reply_markup: keyboard
        });
        
        // Simpan informasi pesan untuk auto-delete
        const messageId = sentMessage.message_id;
        
        // Set timeout untuk menghapus pesan setelah 5 menit
        const deleteTimeout = setTimeout(async () => {
            try {
                await bot.deleteMessage(channel, messageId);
                channelOTPMessages.delete(messageId);
                console.log(`OTP message ${messageId} auto-deleted after 10 minutes`);
            } catch (error) {
                console.error(`Failed to auto-delete OTP message ${messageId}:`, error);
            }
        }, 10 * 60 * 1000); // 10 menit
        
        channelOTPMessages.set(messageId, {
            orderId: orderData.order_id,
            deleteTimeout,
            timestamp: Date.now()
        });
        
        return sentMessage;
        
    } catch (error) {
        console.error('Error sending OTP to channel with auto-delete:', error);
    }
}

// Fungsi untuk menghapus pesan OTP secara manual (jika diperlukan)
async function deleteOTPMessageManually(messageId) {
    try {
        if (channelOTPMessages.has(messageId)) {
            const messageData = channelOTPMessages.get(messageId);
            clearTimeout(messageData.deleteTimeout);
            
            await bot.deleteMessage(channel, messageId);
            channelOTPMessages.delete(messageId);
            
            return true;
        }
        return false;
    } catch (error) {
        console.error('Error manually deleting OTP message:', error);
        return false;
    }
}

// Fungsi untuk membersihkan timeout yang kadaluarsa
function cleanupChannelOTPMessages() {
    const now = Date.now();
    const maxAge = 10 * 60 * 1000; // 10 menit (cadangan)
    
    for (const [messageId, data] of channelOTPMessages.entries()) {
        if (now - data.timestamp > maxAge) {
            clearTimeout(data.deleteTimeout);
            channelOTPMessages.delete(messageId);
        }
    }
}

// Jadwalkan cleanup setiap 5 menit
setInterval(cleanupChannelOTPMessages, 5 * 60 * 1000);
        
async function processNokosOrder(chatId, userId, countryId, providerId, operatorId, price, messageId, callbackQueryId, callbackData = null) {
    let orderKey = `${userId}_${Date.now()}`;

    try {
        if (isOrderProcessing(orderKey)) {
            await editMessage(chatId, messageId, callbackQueryId,
                'Order sedang diproses, mohon tunggu...',
                { parse_mode: 'HTML' }
            );
            return;
        }
        
        setOrderProcessing(orderKey, true);
        
        const userSelection = userSelections.get(userId);
        let appliedVoucher = userSelection?.appliedVoucher;
        let finalPrice = Number(price);
        let discount = 0;
        
        const originalPrice = removeProfitFromPrice(finalPrice);
        const profit = finalPrice - originalPrice;
        
        const userBalance = getUserBalance(userId);
        
        if (userBalance < finalPrice || isNaN(finalPrice)) {
            await editMessage(chatId, messageId, callbackQueryId,
                'Saldo tidak cukup untuk melakukan order ini.',
                { parse_mode: 'HTML' }
            );
            setOrderProcessing(orderKey, false);
            return;
        }

        const deductionSuccess = deductUserBalance(userId, finalPrice);
        
        if (!deductionSuccess) {
            await editMessage(chatId, messageId, callbackQueryId,
                'Gagal memotong saldo. Silakan hubungi admin.',
                { parse_mode: 'HTML' }
            );
            setOrderProcessing(orderKey, false);
            return;
        }
        
        let orderResult;
        
        if (config.active_provider === 'otpnum') {
            // Use OTPNUM API to place order
            // For OTPNUM, we need service_id, operator, and country_id
            const serviceId = providerId; // providerId is service_id
            const operator = operatorId; // operatorId is operator name
            const countryIdNum = parseInt(countryId);
            
            orderResult = await otpnumService.placeOrder(serviceId, operator, countryIdNum);
        } else {
            // Use RumahOTP API
            orderResult = await api.createOrder(countryId, providerId, operatorId);
        }
        
        if (!orderResult || !orderResult.success) {
            const errorMsg = orderResult?.message || 'Error dari API';
            
            addUserBalance(userId, finalPrice);
            
            await editMessage(chatId, messageId, callbackQueryId,
                `Gagal membuat order.\n\n${errorMsg}\n\nSaldo telah dikembalikan.`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ 
                                text: 'Coba Lagi', 
                                callback_data: `nokos_confirm_${countryId}_${providerId}_${operatorId}_${price}` 
                            }],
                            [{ 
                                text: 'Menu Utama', 
                                callback_data: 'main_menu' 
                            }]
                        ]
                    }
                }
            );
            setOrderProcessing(orderKey, false);
            return;
        }

        const orderData = orderResult.data;
        const expiresInMinutes = 15;
        const expiresAt = Date.now() + (expiresInMinutes * 60 * 1000);
        
        if (appliedVoucher && appliedVoucher.valid) {
            useVoucher(appliedVoucher.voucher.code, userId, orderData.order_id, finalPrice, discount);
        }
        
        const transactionId = addTransaction('nokos_orders', {
            userId: userId,
            orderId: orderData.order_id,
            phoneNumber: orderData.number,
            service: orderData.service_name || userSelection.serviceName,
            country: userSelection.countryName,
            operator: orderData.operator_name || operatorId,
            original_price: originalPrice,
            profit: profit,
            final_price: finalPrice,
            api_price: orderData.price || originalPrice,
            voucher_code: appliedVoucher ? appliedVoucher.voucher.code : null,
            discount: discount,
            status: 'active',
            expiresAt: expiresAt,
            expiresInMinutes: expiresInMinutes,
            autoRefundAt: Date.now() + (5 * 60 * 1000),
            deductedAmount: finalPrice,
            refunded: false,
            otpReceived: false,
            provider: config.active_provider
        });

        try {
            const user = await bot.getChat(userId).catch(() => ({ 
                id: userId, 
                first_name: 'User' 
            }));
            await notifyOrderSuccess(user, orderData, finalPrice, false);
        } catch (error) {}

        let voucherInfo = '';
        if (appliedVoucher && appliedVoucher.valid) {
            voucherInfo = `\nVoucher: ${appliedVoucher.voucher.code}\nDiskon: ${formatCurrency(discount)}`;
        }
        
        const message = `
<b>✅ ORDER BERHASIL</b>${voucherInfo}

<u>Detail Order:</u>
ID Order: <code>${orderData.order_id}</code>
Nomor: <code>${orderData.number}</code>
Layanan: ${orderData.service_name || userSelection.serviceName}
Negara: ${userSelection.countryName}
Operator: ${orderData.operator_name || operatorId}
Harga: ${formatCurrency(finalPrice)}
<b>Total Bayar: ${formatCurrency(finalPrice)}</b>
${discount > 0 ? `Diskon: ${formatCurrency(discount)}\n` : ''}
Durasi: ${expiresInMinutes} menit

<u>Instruksi:</u>
1. Gunakan nomor untuk registrasi
2. Tunggu SMS OTP masuk
3. Klik tombol <b>Cek OTP</b> untuk melihat kode

<u>Perhatian:</u>
⚠️ <b>Auto Refund dalam 5 menit</b> jika OTP tidak diterima
⚠️ Order otomatis expired dalam ${expiresInMinutes} menit
💰 Saldo terpotong: ${formatCurrency(finalPrice)}
💰 Saldo sekarang: ${formatCurrency(getUserBalance(userId))}`;

        const keyboard = [
            [
                { 
                    text: '🔄 Cek OTP', 
                    callback_data: `nokos_check_${orderData.order_id}` 
                }
            ],
            [
                { 
                    text: '📱 Order Baru', 
                    callback_data: 'nokos_menu' 
                },
                { 
                    text: '🏠 Menu Utama', 
                    callback_data: 'main_menu' 
                }
            ]
        ];

        await editMessage(chatId, messageId, callbackQueryId, message, {
            reply_markup: { inline_keyboard: keyboard },
            parse_mode: 'HTML'
        });

        // Start monitoring OTP
        setTimeout(() => {
            monitorOTP(chatId, userId, orderData.order_id, finalPrice, expiresInMinutes);
        }, 5000);

        // Schedule auto-refund after 5 minutes
        setTimeout(() => {
            checkAndAutoRefund(chatId, userId, orderData.order_id, finalPrice);
        }, 5 * 60 * 1000);

        setOrderProcessing(orderKey, false);

    } catch (error) {
        console.error('Error in processNokosOrder:', error);
        
        try {
            const refundAmount = Number(price) || 0;
            if (refundAmount > 0) {
                addUserBalance(userId, refundAmount);
            }
        } catch (refundError) {
            console.error('Error refunding balance:', error);
        }
        
        let errorMessage = 'Terjadi kesalahan sistem.\n\n';
        errorMessage += `Pesan Error: ${error.message || 'Unknown error'}\n`;
        errorMessage += `Waktu: ${new Date().toLocaleTimeString('id-ID')}\n\n`;
        errorMessage += `Silakan coba lagi atau hubungi admin`;
        
        await editMessage(chatId, messageId, callbackQueryId, errorMessage,
            { 
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ 
                            text: 'Coba Lagi', 
                            callback_data: `nokos_confirm_${countryId}_${providerId}_${operatorId}_${price}` 
                        }],
                        [{ 
                            text: 'Menu Utama', 
                            callback_data: 'main_menu' 
                        }]
                    ]
                }
            }
        );
        
        if (orderKey) {
            setOrderProcessing(orderKey, false);
        }
    }
}

async function monitorOTP(chatId, userId, orderId, price, expiresInMinutes = 15) {
    const maxRetries = Math.floor(expiresInMinutes * 6);
    let retryCount = 0;
    let errorCount = 0;
    const maxErrors = 3;
    
    const monitorInterval = setInterval(async () => {
        retryCount++;
        
        if (retryCount >= maxRetries) {
            clearInterval(monitorInterval);
            return;
        }

        try {
            const statusResult = await api.getOrderStatus(orderId);
            
            if (!statusResult || !statusResult.success) {
                errorCount++;
                if (errorCount >= maxErrors) {
                    clearInterval(monitorInterval);
                }
                return;
            }

            const orderData = statusResult.data;
            
            if (!orderData) {
                return;
            }
            
            const transactions = loadTransactions();
            const order = transactions.nokos_orders?.find(o => 
                o.id === orderId || o.data?.orderId === orderId
            );
            
            // Cek jika sudah direfund (auto refund 5 menit)
            const alreadyRefunded = order?.data?.refunded === true;
            if (alreadyRefunded) {
                clearInterval(monitorInterval);
                return;
            }
            
            if (orderData.otp_code && orderData.otp_code !== '-') {
                clearInterval(monitorInterval);
                
                updateTransactionStatus('nokos_orders', orderId, 'completed');
                
                if (transactions.nokos_orders) {
                    const orderIndex = transactions.nokos_orders?.findIndex(o => 
                        o.id === orderId || o.data?.orderId === orderId
                    );
                    if (orderIndex !== -1) {
                        transactions.nokos_orders[orderIndex].data.otp_received = true;
                        transactions.nokos_orders[orderIndex].data.otpReceived = true;
                        transactions.nokos_orders[orderIndex].data.otp_code = orderData.otp_code;
                        saveTransactions(transactions);
                    }
                }
                
                await sendNewMessage(chatId,
                    `✅ <b>OTP DITERIMA!</b>\n\n` +
                    `Order ID: <code>#${orderId}</code>\n` +
                    `Nomor: <code>${orderData.phone_number}</code>\n` +
                    `Kode OTP: <code>${orderData.otp_code}</code>\n\n` +
                    `Status: Order selesai ✅\n` +
                    `Saldo sudah terpakai.`,
                    { 
                        parse_mode: 'HTML',
                        reply_markup: {
                            inline_keyboard: [
                                [
                                    { text: '🔄 Order Baru', callback_data: 'nokos_menu' },
                                    { text: '🏠 Menu Utama', callback_data: 'main_menu' }
                                ]
                            ]
                        }
                    }
                );
                
                try {
                    const user = await bot.getChat(userId).catch(() => ({ 
                        id: userId, 
                        first_name: 'User' 
                    }));
                    await notifyOrderSuccess(user, orderData, price, true);
                } catch {}
                
            } else if (orderData.status === 'completed' || orderData.status === 'canceled' || orderData.status === 'expired') {
                clearInterval(monitorInterval);
                
                updateTransactionStatus('nokos_orders', orderId, orderData.status);
                
                const transactions = loadTransactions();
                const order = transactions.nokos_orders?.find(o => 
                    o.id === orderId || o.data?.orderId === orderId
                );
                
                const otpReceived = order?.data?.otp_received === true || order?.data?.otpReceived === true;
                
                // JANGAN refund otomatis di sini - biarkan auto-refund 5 menit yang handle
                if (orderData.status === 'completed' && !otpReceived) {
                    // Mark as completed but OTP not received
                    if (transactions.nokos_orders) {
                        const orderIndex = transactions.nokos_orders.findIndex(o => 
                            o.id === orderId || o.data?.orderId === orderId
                        );
                        if (orderIndex !== -1) {
                            transactions.nokos_orders[orderIndex].data.otp_received = false;
                            saveTransactions(transactions);
                        }
                    }
                }
            }
            
            errorCount = 0;
            
        } catch {
            errorCount++;
            if (errorCount >= maxErrors) {
                clearInterval(monitorInterval);
            }
        }
    }, 10000);
}

async function checkOTP(chatId, orderId, messageId, callbackQueryId) {
    try {
        await editMessage(chatId, messageId, callbackQueryId,
            '⏳ Mengecek OTP...',
            { parse_mode: 'HTML' }
        );

        let statusResult;
        
        if (config.active_provider === 'otpnum') {
            statusResult = await otpnumService.getOrderStatus(orderId);
        } else {
            statusResult = await api.getOrderStatus(orderId);
        }
        
        if (!statusResult || !statusResult.success) {
            await editMessage(chatId, messageId, callbackQueryId,
                '❌ Gagal mengecek OTP.\n\nSilakan coba lagi nanti.',
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '🔄 Coba Lagi', callback_data: `nokos_check_${orderId}` }],
                            [{ text: '🏠 Menu Utama', callback_data: 'main_menu' }]
                        ]
                    }
                }
            );
            return;
        }

        const orderData = statusResult.data;
        const transactions = loadTransactions();
        const orderIndex = transactions.nokos_orders?.findIndex(o => 
            o.id === orderId || o.data?.orderId === orderId
        );
        
        const alreadyRefunded = orderIndex !== -1 && 
                               transactions.nokos_orders[orderIndex]?.data?.refunded === true;
        
        if (alreadyRefunded) {
            await editMessage(chatId, messageId, callbackQueryId,
                `❌ ORDER SUDAH DIREFUND\n\n` +
                `Order ID: <code>#${orderId}</code>\n` +
                `Status: Sudah direfund (OTP tidak diterima dalam 5 menit)\n` +
                `Saldo sudah dikembalikan ke akun Anda.`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [
                                { text: '🔄 Order Baru', callback_data: 'nokos_menu' },
                                { text: '🏠 Menu Utama', callback_data: 'main_menu' }
                            ]
                        ]
                    }
                }
            );
            return;
        }
        
        // Get OTP code from response (different field names for different APIs)
        let otpCode = null;
        if (config.active_provider === 'otpnum') {
            otpCode = orderData.sms;
            if (otpCode === 'waiting' || otpCode === '') {
                otpCode = null;
            }
        } else {
            otpCode = orderData.otp_code;
            if (otpCode === '-' || otpCode === '') {
                otpCode = null;
            }
        }
        
        if (otpCode && otpCode !== 'waiting') {
            if (orderIndex !== -1) {
                transactions.nokos_orders[orderIndex].data.otp_received = true;
                transactions.nokos_orders[orderIndex].data.otpReceived = true;
                transactions.nokos_orders[orderIndex].data.otp_code = otpCode;
                transactions.nokos_orders[orderIndex].data.status = 'completed';
                saveTransactions(transactions);
                
                try {
                    const user = await bot.getChat(chatId).catch(() => ({ 
                        id: chatId, 
                        first_name: 'User' 
                    }));
                    const orderPrice = transactions.nokos_orders[orderIndex].data.price || 0;
                    await notifyOrderSuccess(user, orderData, orderPrice, true);
                } catch (error) {}
            }
            
            await editMessage(chatId, messageId, callbackQueryId,
                `✅ <b>OTP DITEMUKAN!</b>\n\n` +
                `Order ID: <code>#${orderId}</code>\n` +
                `Nomor: ${orderData.number || orderData.phone_number}\n` +
                `Kode OTP: <code>${otpCode}</code>\n\n` +
                `<b>Status:</b> Order selesai ✅\n` +
                `<b>Saldo sudah terpakai.</b>`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [
                                { text: '🔄 Order Baru', callback_data: 'nokos_menu' },
                                { text: '🏠 Menu Utama', callback_data: 'main_menu' }
                            ]
                        ]
                    }
                }
            );
            
            updateTransactionStatus('nokos_orders', orderId, 'completed');
            
        } else {
            await editMessage(chatId, messageId, callbackQueryId,
                `⏳ <b>MENUNGGU OTP</b>\n\n` +
                `Order ID: <code>#${orderId}</code>\n` +
                `Nomor: ${orderData.number || orderData.phone_number}\n` +
                `Status: ${orderData.status || 'waiting'}\n\n` +
                `OTP belum diterima. Silakan coba lagi nanti.\n\n` +
                `⚠️ <i>Auto refund dalam 5 menit jika OTP tidak diterima</i>`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [
                                { text: '🔄 Cek Lagi', callback_data: `nokos_check_${orderId}` }
                            ],
                            [
                                { text: '🏠 Menu Utama', callback_data: 'main_menu' }
                            ]
                        ]
                    }
                }
            );
        }
    } catch (error) {
        console.error('Error in checkOTP:', error);
        await editMessage(chatId, messageId, callbackQueryId,
            '❌ Gagal mengecek OTP.',
            { parse_mode: 'HTML' }
        );
    }
}

function formatTimeRemaining(minutes) {
    if (minutes >= 60) {
        const hours = Math.floor(minutes / 60);
        const mins = minutes % 60;
        return `${hours} jam ${mins} menit`;
    }
    return `${minutes} menit`;
}

function hasOTPBeenReceived(orderId) {
    try {
        const transactions = loadTransactions();
        const order = transactions.nokos_orders?.find(o => 
            o.id === orderId || o.data?.orderId === orderId
        );
        
        const dbCheck = order?.data?.otp_received === true;
        const otpCheck = order?.data?.otp_code && 
                       order.data.otp_code !== '-' && 
                       order.data.otp_code !== '';
        
        return dbCheck || otpCheck;
    } catch (error) {
        return false;
    }
}

/*async function cancelOrder(chatId, userId, orderId, messageId, callbackQueryId) {
  try {
    const transactions = loadTransactions();
    const order = transactions.nokos_orders?.find(o => o.id === orderId || o.data?.orderId === orderId);
    
    if (!order) {
      if (callbackQueryId) {
        await bot.answerCallbackQuery(callbackQueryId, {
          text: 'Order tidak ditemukan',
          show_alert: true
        });
      }
      return;
    }

    let orderTime;
    try {
        if (order.timestamp instanceof Date) {
            orderTime = order.timestamp.getTime();
        } else if (typeof order.timestamp === 'string') {
            orderTime = new Date(order.timestamp).getTime();
        } else if (order.timestamp && typeof order.timestamp === 'number') {
            orderTime = order.timestamp;
        } else {
            orderTime = Date.now();
        }
        
        if (isNaN(orderTime)) {
            orderTime = Date.now();
        }
    } catch (error) {
        orderTime = Date.now();
    }

    const now = Date.now();
    const threeMinutes = 3 * 60 * 1000;
    
    if (now - orderTime < threeMinutes) {
      const timeLeft = Math.ceil((threeMinutes - (now - orderTime)) / 1000);
      const minutesLeft = Math.floor(timeLeft / 60);
      const secondsLeft = timeLeft % 60;
      
      if (callbackQueryId) {
        await bot.answerCallbackQuery(callbackQueryId, {
          text: `Tunggu ${minutesLeft}m ${secondsLeft}s sebelum membatalkan`,
          show_alert: true
        });
      }
      return;
    }

    await editMessage(chatId, messageId, callbackQueryId,
      'Membatalkan order...',
      { parse_mode: 'HTML' }
    );

    const statusResult = await api.getOrderStatus(orderId);
    
    let otpReceived = false;
    if (statusResult && statusResult.success && statusResult.data) {
      const orderData = statusResult.data;
      otpReceived = orderData.otp_code && orderData.otp_code !== '-' && orderData.otp_code !== '';
    }

    const dbOtpReceived = order?.data?.otp_received === true;
    
    if (otpReceived || dbOtpReceived) {
        await editMessage(chatId, messageId, callbackQueryId,
            `Order tidak dapat dibatalkan!\n\nOrder ID: #${orderId}\n\nAlasan: OTP sudah diterima.\nStatus: Order selesai\nSaldo tidak dapat dikembalikan.`,
            { 
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: 'Order Baru', callback_data: 'nokos_menu' },
                            { text: 'Menu Utama', callback_data: 'main_menu' }
                        ]
                    ]
                }
            }
        );
        return;
    }
    
    if (order?.status === 'cancelled' || order?.status === 'expired' || order?.status === 'completed') {
      await editMessage(chatId, messageId, callbackQueryId,
        `Order sudah dalam status: ${order.status}\n\nOrder ID: #${orderId}\n\nTidak bisa dibatalkan lagi.`,
        { 
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [
                { text: 'Order Baru', callback_data: 'nokos_menu' },
                { text: 'Menu Utama', callback_data: 'main_menu' }
              ]
            ]
          }
        }
      );
      return;
    }

    const alreadyRefunded = order?.data?.refunded === true;
    
    if (alreadyRefunded) {
      await editMessage(chatId, messageId, callbackQueryId,
        `Refund sudah diberikan.\n\nSaldo untuk order ini sudah dikembalikan sebelumnya.`,
        { parse_mode: 'HTML' }
      );
      return;
    }

    const cancelResult = await api.setOrderStatus(orderId, 'cancel');
    
    if (!cancelResult || !cancelResult.success) {
      const errorMsg = cancelResult?.message || 'Provider menolak pembatalan';
      
      if (errorMsg.includes('wait') || errorMsg.includes('tunggu') || errorMsg.includes('minute')) {
        await editMessage(chatId, messageId, callbackQueryId,
          `Provider sedang memproses order.\n\nSilakan tunggu beberapa saat lagi sebelum membatalkan.`,
          { 
            parse_mode: 'HTML',
            reply_markup: {
              inline_keyboard: [
                [
                  { text: 'Coba Lagi', callback_data: `nokos_cancel_${orderId}` },
                  { text: 'Menu Utama', callback_data: 'main_menu' }
                ]
              ]
            }
          }
        );
      } else {
        await editMessage(chatId, messageId, callbackQueryId,
          `Gagal membatalkan order.\n\n${errorMsg}`,
          { 
            parse_mode: 'HTML',
            reply_markup: {
              inline_keyboard: [
                [
                  { text: 'Coba Lagi', callback_data: `nokos_cancel_${orderId}` },
                  { text: 'Menu Utama', callback_data: 'main_menu' }
                ]
              ]
            }
          }
        );
      }
      return;
    }

    updateTransactionStatus('nokos_orders', orderId, 'cancelled');

    if (transactions.nokos_orders) {
      const orderIndex = transactions.nokos_orders.findIndex(o => o.id === orderId || o.data?.orderId === orderId);
      if (orderIndex !== -1) {
        transactions.nokos_orders[orderIndex].data.refunded = true;
        transactions.nokos_orders[orderIndex].data.manually_cancelled = true;
        saveTransactions(transactions);
      }
    }
    
    let refundMessage = '';
    const orderPrice = order.data?.price || 0;
    const refundAmount = Number(orderPrice);
    
    if (!isNaN(refundAmount) && refundAmount > 0) {
      const success = addUserBalance(userId, refundAmount);
      
      if (success) {
        balanceCache.delete(userId.toString());
        
        const currentBalance = getUserBalance(userId);
        refundMessage = `\n\nRefund: ${formatCurrency(refundAmount)}\nSaldo sekarang: ${formatCurrency(currentBalance)}`;
      }
    }

    await editMessage(chatId, messageId, callbackQueryId,
      `Order Dibatalkan\n\nOrder ID: #${orderId}${refundMessage}`,
      { 
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: 'Order Baru', callback_data: 'nokos_menu' },
              { text: 'Menu Utama', callback_data: 'main_menu' }
            ]
          ]
        }
      }
    );
  } catch (error) {
    await editMessage(chatId, messageId, callbackQueryId,
      `Gagal membatalkan order.\n\n${error.message || 'Error sistem'}`,
      { 
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: 'Coba Lagi', callback_data: `nokos_cancel_${orderId}` },
              { text: 'Menu Utama', callback_data: 'main_menu' }
            ]
          ]
        }
      }
    );
  }
}

async function autoCancelOrder(chatId, userId, orderId, price) {
  try {
    const transactions = loadTransactions();
    const order = transactions.nokos_orders?.find(o => 
        o.id === orderId || o.data?.orderId === orderId
    );
    
    if (!order) return;

    const manuallyCancelled = order?.data?.manually_cancelled === true;
    const alreadyRefunded = order?.data?.refunded === true;
    
    if (manuallyCancelled || alreadyRefunded) {
      return;
    }

    const cancelResult = await api.setOrderStatus(orderId, 'cancel');
    
    if (cancelResult && cancelResult.success) {
      updateTransactionStatus('nokos_orders', orderId, 'expired');
      
      if (transactions.nokos_orders) {
        const orderIndex = transactions.nokos_orders.findIndex(o => 
            o.id === orderId || o.data?.orderId === orderId
        );
        if (orderIndex !== -1) {
          transactions.nokos_orders[orderIndex].data.refunded = true;
          saveTransactions(transactions);
        }
      }
      
      const refundAmount = Number(price);
      
      if (!isNaN(refundAmount) && refundAmount > 0) {
        addUserBalance(userId, refundAmount);
        balanceCache.delete(userId.toString());
      }
      
      await sendNewMessage(chatId,
        `Order Expired\n\nOrder ID: #${orderId}\n\nOTP tidak diterima dalam waktu yang ditentukan.\nSaldo sebesar ${formatCurrency(price)} telah dikembalikan.`,
        { parse_mode: 'HTML' }
      );
    }
  } catch (error) {}
}*/

async function handleOTPNUMDeposit(chatId, userId, amount, method = 'QRISREALTIME') {
    try {
        const depositKey = `${userId}_deposit`;

        if (depositProcessing.has(depositKey)) {
            await sendNewMessage(chatId,
                'Deposit sedang diproses, mohon tunggu...',
                { parse_mode: 'HTML' }
            );
            return;
        }
        
        depositProcessing.set(depositKey, Date.now());
        
        const amountValidation = validateAmount(amount);
        if (!amountValidation.valid) {
            await sendNewMessage(chatId,
                `Jumlah tidak valid: ${amountValidation.error}`,
                { parse_mode: 'HTML' }
            );
            depositProcessing.delete(depositKey);
            return;
        }
        
        const depositAmount = amountValidation.amount;
        
        if (depositAmount < 2000) {
            await sendNewMessage(chatId,
                'Minimal deposit adalah Rp 2,000',
                { parse_mode: 'HTML' }
            );
            depositProcessing.delete(depositKey);
            return;
        }
        
        if (depositAmount > 5000000) {
            await sendNewMessage(chatId,
                'Maksimal deposit adalah Rp 5,000,000',
                { parse_mode: 'HTML' }
            );
            depositProcessing.delete(depositKey);
            return;
        }

        const loadingMessage = await sendNewMessage(chatId, 'Memproses deposit...', { parse_mode: 'HTML' });

        // Use OTPNUM API for deposit
        const depositResult = await otpnumService.createDeposit(method, depositAmount);
        
        if (!depositResult || !depositResult.success) {
            const errorMsg = depositResult?.message || 'Terjadi kesalahan sistem';
            
            await editMessage(chatId, loadingMessage.message_id, null,
                `Gagal membuat deposit.\n\n${errorMsg}`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: { 
                        inline_keyboard: [
                            [{ text: 'Coba Lagi', callback_data: 'deposit_main' }],
                            [{ text: 'Menu Utama', callback_data: 'main_menu' }]
                        ] 
                    } 
                }
            );
            depositProcessing.delete(depositKey);
            return;
        }

        const depositData = depositResult.data;
        const depositId = depositData.no_inv;
        
        addTransaction('otpnum_deposits', {
            userId: userId,
            id: depositId,
            amount: depositAmount,
            total: depositData.amount,
            method: depositData.method,
            payment_code: depositData.payment_code,
            status: depositData.status,
            raw_data: depositResult
        });

        try {
            await notifyOwnerDepositCreated(depositData, userId, depositAmount, 'OTPNUM');
        } catch (error) {}

        const message = `
<b>💰 Deposit Diproses</b>

<b>Informasi Deposit:</b>
ID: #${depositId}
Jumlah: ${formatCurrency(depositAmount)}
Metode: QRIS
Status: ${depositData.status}

<b>Silakan scan QR untuk pembayaran</b>
Batas waktu: 20 menit`;

        const keyboard = {
            inline_keyboard: [
                [
                    { text: 'Periksa Status', callback_data: `deposit_status_${depositId}` },
                    { text: 'Batalkan', callback_data: `deposit_cancel_${depositId}` }
                ],
                [
                    { text: 'Deposit Lagi', callback_data: 'deposit_main' },
                    { text: 'Menu Utama', callback_data: 'main_menu' }
                ]
            ]
        };

        await bot.deleteMessage(chatId, loadingMessage.message_id).catch(() => {});
        
        if (depositData.payment_code) {
            try {
                const qrBuffer = await QRCode.toBuffer(depositData.payment_code, {
                    errorCorrectionLevel: 'H',
                    margin: 1,
                    width: 300
                });
                
                const qrMessage = await bot.sendPhoto(chatId, qrBuffer, {
                    caption: message,
                    parse_mode: 'HTML',
                    reply_markup: keyboard
                });
                userDepositMessages.set(`${userId}_${depositId}`, qrMessage.message_id);
            } catch (qrError) {
                const textMessage = await sendNewMessage(chatId, 
                    `${message}\n\nQR URL:\n<code>${depositData.payment_code}</code>`,
                    { 
                        parse_mode: 'HTML',
                        reply_markup: keyboard 
                    }
                );
                userDepositMessages.set(`${userId}_${depositId}`, textMessage.message_id);
            }
        } else {
            const textMessage = await sendNewMessage(chatId, message, { 
                parse_mode: 'HTML',
                reply_markup: keyboard 
            });
            userDepositMessages.set(`${userId}_${depositId}`, textMessage.message_id);
        }

        depositProcessing.delete(depositKey);
        
        setTimeout(() => checkOTPNUMDepositStatus(chatId, depositId, userId), 10000);
        
    } catch (error) {
        depositProcessing.delete(`${userId}_deposit`);
        
        await sendNewMessage(chatId,
            `Gagal memproses deposit.\n\n${error.message || 'Terjadi kesalahan sistem.'}`,
            { parse_mode: 'HTML' }
        );
    }
}

async function checkOTPNUMDepositStatus(chatId, depositId, userId, messageId = null, retryCount = 0) {
    const maxRetries = 120;
    
    if (retryCount >= maxRetries) {
        if (messageId) {
            await editMessage(chatId, messageId, null, 
                'Pemeriksaan status deposit dibatalkan.\n\nWaktu pemeriksaan status deposit telah habis.\nSilakan ulangi transaksi lagi.',
                { 
                    parse_mode: 'HTML',
                    reply_markup: { 
                        inline_keyboard: [
                            [{ text: 'Menu Utama', callback_data: 'main_menu' }]
                        ] 
                    } 
                }
            );
        }
        return;
    }

    const statusResult = await otpnumService.checkDepositStatus(depositId);
    
    if (!statusResult || !statusResult.success) {
        setTimeout(() => {
            checkOTPNUMDepositStatus(chatId, depositId, userId, messageId, retryCount + 1);
        }, 10000);
        return;
    }

    const deposit = statusResult.data;
    
    if (deposit.status === 'PAID') {
        const amountToAdd = deposit.amount || 0;
        
        const transactions = loadTransactions();
        const existingDeposit = transactions.otpnum_deposits?.find(d => d.data.id === depositId);
        
        if (!existingDeposit || existingDeposit.status !== 'success') {
            if (amountToAdd > 0) {
                addUserBalance(userId, amountToAdd);
                updateTransactionStatus('otpnum_deposits', depositId, 'success');

                try {
                    const user = await bot.getChat(userId).catch(() => ({ 
                        id: userId, 
                        first_name: 'User' 
                    }));
                    await notifyDepositSuccess(user, amountToAdd, depositId, getUserBalance(userId));
                } catch (error) {}

                const depositKey = `${userId}_${depositId}`;
                const qrMessageId = userDepositMessages.get(depositKey);
                if (qrMessageId) {
                    try {
                        await bot.deleteMessage(chatId, qrMessageId);
                    } catch (deleteError) {}
                    userDepositMessages.delete(depositKey);
                }
                
                const successMessage = `
<b>✅ Deposit Berhasil</b>

${formatCurrency(amountToAdd)} telah ditambahkan ke saldo Anda
Saldo sekarang: ${formatCurrency(getUserBalance(userId))}

Terima kasih telah melakukan deposit`;
                
                const keyboard = {
                    inline_keyboard: [
                        [
                            { text: 'Deposit Lagi', callback_data: 'deposit_main' },
                            { text: 'Menu Utama', callback_data: 'main_menu' }
                        ]
                    ]
                };
                
                if (messageId) {
                    await editMessage(chatId, messageId, null, successMessage, {
                        parse_mode: 'HTML',
                        reply_markup: keyboard
                    });
                } else {
                    await sendNewMessage(chatId, successMessage, {
                        parse_mode: 'HTML',
                        reply_markup: keyboard
                    });
                }
            }
        }
        return;
        
    } else if (deposit.status === 'UNPAID' && messageId) {
        const updateMessage = `
<b>💰 Status Deposit</b>

ID: #${depositId}
Jumlah: ${formatCurrency(deposit.amount)}
Status: Menunggu pembayaran`;
        
        await editMessage(chatId, messageId, null, updateMessage, {
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: 'Periksa Status', callback_data: `deposit_status_${depositId}` },
                        { text: 'Batalkan', callback_data: `deposit_cancel_${depositId}` }
                    ],
                    [
                        { text: 'Menu Utama', callback_data: 'main_menu' }
                    ]
                ]
            }
        });
        
        setTimeout(() => {
            checkOTPNUMDepositStatus(chatId, depositId, userId, messageId, retryCount + 1);
        }, 10000);
        
    } else if (deposit.status === 'CANCELLED') {
        updateTransactionStatus('otpnum_deposits', depositId, 'cancelled');

        const failedMessage = `
<b>❌ Deposit ${deposit.status}</b>

ID: #${depositId}
Jumlah: ${formatCurrency(deposit.amount)}
Status: ${deposit.status}

Silakan ulangi deposit lagi.`;
    
        if (messageId) {
            await editMessage(chatId, messageId, null, failedMessage, {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: 'Ulangi Deposit', callback_data: 'deposit_main' },
                            { text: 'Menu Utama', callback_data: 'main_menu' }
                        ]
                    ]
                }
            });
        }
    } else {
        setTimeout(() => {
            checkOTPNUMDepositStatus(chatId, depositId, userId, messageId, retryCount + 1);
        }, 10000);
    }
}

async function handleRumahOTPDeposit(chatId, userId, amount) {
    try {
        const depositKey = `${userId}_deposit`;

        if (depositProcessing.has(depositKey)) {
            await sendNewMessage(chatId,
                'Deposit sedang diproses, mohon tunggu...',
                { parse_mode: 'HTML' }
            );
            return;
        }
        
        depositProcessing.set(depositKey, Date.now());
        
        const amountValidation = validateAmount(amount);
        if (!amountValidation.valid) {
            await sendNewMessage(chatId,
                `Jumlah tidak valid: ${amountValidation.error}`,
                { parse_mode: 'HTML' }
            );
            depositProcessing.delete(depositKey);
            return;
        }
        
        const depositAmount = amountValidation.amount;
        
        if (depositAmount < 2000) {
            await sendNewMessage(chatId,
                'Minimal deposit adalah Rp 2,000',
                { parse_mode: 'HTML' }
            );
            depositProcessing.delete(depositKey);
            return;
        }
        
        if (depositAmount > 5000000) {
            await sendNewMessage(chatId,
                'Maksimal deposit adalah Rp 5,000,000',
                { parse_mode: 'HTML' }
            );
            depositProcessing.delete(depositKey);
            return;
        }

        const loadingMessage = await sendNewMessage(chatId, 'Memproses deposit...', { parse_mode: 'HTML' });

        const paymentMethod = getPaymentMethod();
        let depositResult;
        
        try {
            if (paymentMethod === 'cashify') {
                depositResult = await cashifyService.createDeposit(userId.toString(), depositAmount);
            } else {
                depositResult = await api.createRumahOTPDeposit(depositAmount);
            }
        } catch (apiError) {
            depositProcessing.delete(depositKey);
            await editMessage(chatId, loadingMessage.message_id, null,
                `Gagal membuat deposit: ${apiError.message || 'Koneksi error'}`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: { 
                        inline_keyboard: [
                            [{ text: 'Coba Lagi', callback_data: 'deposit_main' }],
                            [{ text: 'Menu Utama', callback_data: 'main_menu' }]
                        ] 
                    } 
                }
            );
            return;
        }
        
        const isCashify = paymentMethod === 'cashify';
        const successCheck = isCashify ? 
            depositResult?.success : 
            depositResult?.success;
        
        if (!successCheck) {
            const errorMsg = depositResult?.message || 
                           depositResult?.error?.message || 
                           depositResult?.error || 
                           'Terjadi kesalahan sistem';
            
            await editMessage(chatId, loadingMessage.message_id, null,
                `Gagal membuat deposit.\n\n${errorMsg}`,
                { 
                    parse_mode: 'HTML',
                    reply_markup: { 
                        inline_keyboard: [
                            [{ text: 'Coba Lagi', callback_data: 'deposit_main' }],
                            [{ text: 'Menu Utama', callback_data: 'main_menu' }]
                        ] 
                    } 
                }
            );
            depositProcessing.delete(depositKey);
            return;
        }

        let depositData;
        let depositId;
        const transactionType = isCashify ? 'cashify_deposits' : 'rumahotp_deposits';
        
        if (isCashify) {
            depositData = depositResult.data;
            depositId = depositData.id;
            
            depositData = {
                id: depositId,
                method: 'QRIS',
                qr_string: depositData.qr_string || depositData.qr_code || '',
                total: depositAmount,
                diterima: depositData.diterima || depositAmount,
                fee: depositData.fee || 0,
                status: 'pending'
            };
        } else {
            depositData = depositResult.data;
            depositId = depositData.id || depositData.no_inv;
        }

        if (!depositId) {
            await editMessage(chatId, loadingMessage.message_id, null,
                'Gagal mendapatkan ID deposit dari provider',
                { 
                    parse_mode: 'HTML',
                    reply_markup: { 
                        inline_keyboard: [
                            [{ text: 'Coba Lagi', callback_data: 'deposit_main' }],
                            [{ text: 'Menu Utama', callback_data: 'main_menu' }]
                        ] 
                    } 
                }
            );
            depositProcessing.delete(depositKey);
            return;
        }
        
        addTransaction(transactionType, {
            userId: userId,
            id: depositId,
            amount: depositAmount,
            total: depositData.total || depositAmount,
            fee: depositData.fee || 0,
            diterima: depositData.diterima || depositAmount,
            method: 'QRIS', 
            status: 'pending',
            raw_data: depositResult
        });

        try {
            await notifyOwnerDepositCreated(depositData, userId, depositAmount, paymentMethod);
        } catch (error) {}

        const message = `
Deposit Diproses

Informasi Deposit:
ID: #${depositId}
Jumlah: ${formatCurrency(depositAmount)}
Metode: QRIS
Fee: ${formatCurrency(depositData.fee || 0)}
Diterima: ${formatCurrency(depositData.diterima || depositAmount)}
Status: Menunggu Pembayaran

Silakan scan QR untuk pembayaran
Batas waktu: 20 menit`;

        const keyboard = {
            inline_keyboard: [
                [
                    { text: 'Periksa Status', callback_data: `deposit_status_${depositId}` },
                    { text: 'Batalkan', callback_data: `deposit_cancel_${depositId}` }
                ],
                [
                    { text: 'Deposit Lagi', callback_data: 'deposit_main' },
                    { text: 'Menu Utama', callback_data: 'main_menu' }
                ]
            ]
        };

        await bot.deleteMessage(chatId, loadingMessage.message_id).catch(() => {});
        
        if (isCashify && depositData.qr_string && depositData.qr_string.trim() !== '') {
            try {
                const qrBuffer = await QRCode.toBuffer(depositData.qr_string, {
                    errorCorrectionLevel: 'H',
                    margin: 1,
                    width: 300
                });
                
                const qrMessage = await bot.sendPhoto(chatId, qrBuffer, {
                    caption: message,
                    parse_mode: 'HTML',
                    reply_markup: keyboard
                });
                userDepositMessages.set(`${userId}_${depositId}`, qrMessage.message_id);
            } catch (qrError) {
                const textMessage = await sendNewMessage(chatId, 
                    `${message}\n\nQR Text:\n<code>${depositData.qr_string.substring(0, 100)}...</code>`,
                    { 
                        parse_mode: 'HTML',
                        reply_markup: keyboard 
                    }
                );
                userDepositMessages.set(`${userId}_${depositId}`, textMessage.message_id);
            }
        } else if (depositData.qr_string && depositData.qr_string.trim() !== '') {
            try {
                const qrBuffer = await QRCode.toBuffer(depositData.qr_string, {
                    errorCorrectionLevel: 'H',
                    margin: 1,
                    width: 300
                });
                
                const qrMessage = await bot.sendPhoto(chatId, qrBuffer, {
                    caption: message,
                    parse_mode: 'HTML',
                    reply_markup: keyboard
                });
                userDepositMessages.set(`${userId}_${depositId}`, qrMessage.message_id);
            } catch (qrError) {
                const textMessage = await sendNewMessage(chatId, 
                    `${message}\n\nQR Text:\n<code>${depositData.qr_string.substring(0, 100)}...</code>`,
                    { 
                        parse_mode: 'HTML',
                        reply_markup: keyboard 
                    }
                );
                userDepositMessages.set(`${userId}_${depositId}`, textMessage.message_id);
            }
        } else {
            const textMessage = await sendNewMessage(chatId, message, { 
                parse_mode: 'HTML',
                reply_markup: keyboard 
            });
            userDepositMessages.set(`${userId}_${depositId}`, textMessage.message_id);
        }

        depositProcessing.delete(depositKey);
        
        setTimeout(() => checkDepositStatus(chatId, depositId, userId), 10000);
    } catch (error) {
        depositProcessing.delete(`${userId}_deposit`);
        
        await sendNewMessage(chatId,
            `Gagal memproses deposit.\n\n${error.message || 'Terjadi kesalahan sistem.'}`,
            { parse_mode: 'HTML' }
        );
    }
}

async function checkDepositStatus(chatId, depositId, userId, messageId = null, retryCount = 0) {
    const maxRetries = 120;
    
    if (retryCount >= maxRetries) {
        if (messageId) {
            await editMessage(chatId, messageId, null, 
                'Pemeriksaan status deposit dibatalkan.\n\nWaktu pemeriksaan status deposit telah habis.\nSilakan ulangi transaksi lagi.',
                { 
                    parse_mode: 'HTML',
                    reply_markup: { 
                        inline_keyboard: [
                            [{ text: 'Menu Utama', callback_data: 'main_menu' }]
                        ] 
                    } 
                }
            );
        }
        return;
    }

    const paymentMethod = getPaymentMethod();
    let statusResult;
    
    if (paymentMethod === 'cashify') {
        statusResult = await cashifyService.checkDepositStatus(depositId);
    } else {
        statusResult = await api.checkRumahOTPDepositStatus(depositId);
    }
    
    const isCashify = paymentMethod === 'cashify';
    const successCheck = isCashify ? 
        statusResult?.success : 
        statusResult?.success;
    
    if (!successCheck) {
        setTimeout(() => {
            checkDepositStatus(chatId, depositId, userId, messageId, retryCount + 1);
        }, 10000);
        return;
    }

    let deposit;
    if (isCashify) {
        deposit = statusResult.data;

        if (deposit.status === 'paid') {
            deposit.status = 'success';
            
            const transactions = loadTransactions();
            const transactionType = 'cashify_deposits';
            const existingDeposit = transactions[transactionType]?.find(d => d.data.id === depositId);
            
            if (!existingDeposit || existingDeposit.status !== 'success') {
                const amountToAdd = deposit.diterima || deposit.total || 0;
                
                if (amountToAdd > 0) {
                    addUserBalance(userId, amountToAdd);
                    updateTransactionStatus(transactionType, depositId, 'success');

                    try {
                        const user = await bot.getChat(userId).catch(() => ({ 
                            id: userId, 
                            first_name: 'User' 
                        }));
                        await notifyDepositSuccess(user, amountToAdd, depositId, getUserBalance(userId));
                    } catch (error) {}

                    const depositKey = `${userId}_${depositId}`;
                    const qrMessageId = userDepositMessages.get(depositKey);
                    if (qrMessageId) {
                        try {
                            await bot.deleteMessage(chatId, qrMessageId);
                        } catch (deleteError) {}
                        userDepositMessages.delete(depositKey);
                    }
                    
                    const successMessage = `
Deposit Berhasil

${formatCurrency(amountToAdd)} telah ditambahkan ke saldo Anda
Saldo sekarang: ${formatCurrency(getUserBalance(userId))}

Terima kasih telah melakukan deposit`;
                    
                    const keyboard = {
                        inline_keyboard: [
                            [
                                { text: 'Deposit Lagi', callback_data: 'deposit_main' },
                                { text: 'Menu Utama', callback_data: 'main_menu' }
                            ]
                        ]
                    };
                    
                    if (messageId) {
                        await editMessage(chatId, messageId, null, successMessage, {
                            parse_mode: 'HTML',
                            reply_markup: keyboard
                        });
                    } else {
                        await sendNewMessage(chatId, successMessage, {
                            parse_mode: 'HTML',
                            reply_markup: keyboard
                        });
                    }
                }
            }
            return; 
        }
    } else {
        deposit = statusResult.data;
    }
    
    if (deposit.status === 'success' || deposit.status === 'paid') {
        const amountToAdd = deposit.diterima || deposit.total || depositAmount;
        
        const transactions = loadTransactions();
        const transactionType = isCashify ? 'cashify_deposits' : 'rumahotp_deposits';
        const existingDeposit = transactions[transactionType]?.find(d => d.data.id === depositId);
        
        if (!existingDeposit || existingDeposit.status !== 'success') {
            addUserBalance(userId, amountToAdd);
            updateTransactionStatus(transactionType, depositId, 'success');

            try {
                const user = await bot.getChat(userId).catch(() => ({ 
                    id: userId, 
                    first_name: 'User' 
                }));
                await notifyDepositSuccess(user, amountToAdd, depositId, getUserBalance(userId));
            } catch (error) {}
        }

        const depositKey = `${userId}_${depositId}`;
        const qrMessageId = userDepositMessages.get(depositKey);
        if (qrMessageId) {
            try {
                await bot.deleteMessage(chatId, qrMessageId);
            } catch (deleteError) {}
            userDepositMessages.delete(depositKey);
        }
        
        const successMessage = `
Deposit Berhasil

${formatCurrency(amountToAdd)} telah ditambahkan ke saldo Anda
Saldo sekarang: ${formatCurrency(getUserBalance(userId))}

Terima kasih telah melakukan deposit`;
        
        const keyboard = {
            inline_keyboard: [
                [
                    { text: 'Deposit Lagi', callback_data: 'deposit_main' },
                    { text: 'Menu Utama', callback_data: 'main_menu' }
                ]
            ]
        };
        
        if (messageId) {
            await editMessage(chatId, messageId, null, successMessage, {
                parse_mode: 'HTML',
                reply_markup: keyboard
            });
        } else {
            await sendNewMessage(chatId, successMessage, {
                parse_mode: 'HTML',
                reply_markup: keyboard
            });
        }
        
    } else if ((deposit.status === 'pending' || deposit.status === 'waiting') && messageId) {
        const updateMessage = `
Status Deposit

ID: #${depositId}
Jumlah: ${formatCurrency(deposit.total || depositAmount || 0)}
Status: Menunggu pembayaran`;
        
        await editMessage(chatId, messageId, null, updateMessage, {
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: 'Periksa Status', callback_data: `deposit_status_${depositId}` },
                        { text: 'Batalkan', callback_data: `deposit_cancel_${depositId}` }
                    ],
                    [
                        { text: 'Menu Utama', callback_data: 'main_menu' }
                    ]
                ]
            }
        });
        
        setTimeout(() => {
            checkDepositStatus(chatId, depositId, userId, messageId, retryCount + 1);
        }, 10000);
        
    } else if (deposit.status === 'cancel' || deposit.status === 'cancelled' || deposit.status === 'expired' || deposit.status === 'failed') {
        const transactionType = isCashify ? 'cashify_deposits' : 'rumahotp_deposits';
        updateTransactionStatus(transactionType, depositId, deposit.status);

        const failedMessage = `
Deposit ${deposit.status.toUpperCase()}

ID: #${depositId}
Jumlah: ${formatCurrency(deposit.total || depositAmount || 0)}
Status: ${deposit.status}

Silakan ulangi deposit lagi.`;
    
        if (messageId) {
            await editMessage(chatId, messageId, null, failedMessage, {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: 'Ulangi Deposit', callback_data: 'deposit_main' },
                            { text: 'Menu Utama', callback_data: 'main_menu' }
                        ]
                    ]
                }
            });
        }
    } else {
        setTimeout(() => {
            checkDepositStatus(chatId, depositId, userId, messageId, retryCount + 1);
        }, 10000);
    }
}

// ========================= MESSAGE HANDLER =========================

bot.on('message', async (msg) => {
  if (msg.text && msg.text.startsWith('/')) return;
  
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const text = msg.text;
  
  const selection = userSelections.get(userId);
  
  // Handler untuk input pencarian layanan
if (selection && selection.step === 'search_service_input') {
    await bot.deleteMessage(chatId, msg.message_id).catch(() => {});
    
    const searchTerm = text.trim();
    
    if (searchTerm === '0' || searchTerm.toLowerCase() === 'batal') {
        userSelections.delete(userId);
        await showOtherServices(chatId, userId, msg.message_id, callbackQueryId, 0);
        return;
    }
    
    if (searchTerm.length < 2) {
        await sendNewMessage(chatId,
            '❌ Kata kunci terlalu pendek. Minimal 2 karakter.\n\nSilakan coba lagi.',
            { parse_mode: 'HTML' }
        );
        return;
    }
    
    await searchService(chatId, userId, searchTerm, msg.message_id);
    userSelections.delete(userId);
    return;
}

// Handler untuk input pencarian negara
if (selection && selection.step === 'search_country_input') {
    await bot.deleteMessage(chatId, msg.message_id).catch(() => {});
    
    const searchTerm = text.trim();
    const serviceId = selection.serviceId;
    
    if (searchTerm === '0' || searchTerm.toLowerCase() === 'batal') {
        userSelections.delete(userId);
        await showCountryMenu(chatId, userId, serviceId, selection.serviceName, msg.message_id, callbackQueryId, 0);
        return;
    }
    
    if (searchTerm.length < 2) {
        await sendNewMessage(chatId,
            '❌ Kata kunci terlalu pendek. Minimal 2 karakter.\n\nSilakan coba lagi.',
            { parse_mode: 'HTML' }
        );
        return;
    }
    
    await searchCountry(chatId, userId, serviceId, searchTerm, msg.message_id);
    userSelections.delete(userId);
    return;
}
  
  if (selection && selection.step === 'awaiting_withdraw_target') {
    await bot.deleteMessage(chatId, msg.message_id).catch(() => {});
    
    const targetNumber = text.trim();
    
    if (targetNumber === '0' || targetNumber.toLowerCase() === 'batal') {
        userSelections.delete(userId);
        
        await sendNewMessage(chatId,
            '❌ Withdraw dibatalkan.',
            {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '💰 Withdraw Menu', callback_data: 'withdraw_menu' }]
                    ]
                }
            }
        );
        return;
    }
    
    // Validasi nomor
    const cleanNumber = targetNumber.replace(/[^\d]/g, '');
    if (cleanNumber.length < 10 || cleanNumber.length > 15) {
        await sendNewMessage(chatId,
            `❌ <b>NOMOR TIDAK VALID</b>\n\n` +
            `Nomor: <code>${targetNumber}</code>\n` +
            `Panjang nomor harus 10-15 digit.\n\n` +
            `Contoh: <code>08123456789</code>\n\n` +
            `Silakan kirim nomor yang valid atau ketik 0 untuk batal.`,
            {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '❌ Batalkan', callback_data: `withdraw_brand_${selection.brand}_${selection.menuPage}` }]
                    ]
                }
            }
        );
        return;
    }
    
    // Proses withdraw
    await processWithdrawOrder(chatId, userId, selection.productCode, cleanNumber);
    
    userSelections.delete(userId);
    return;
}
  
  // Handler untuk pesan CS Chat
if (selection && selection.step === 'cs_chat_active') {
    await handleUserToCSMessage(msg);
    return;
}

// Handler untuk balasan CS Admin
if (selection && selection.step === 'cs_admin_chat') {
    await handleCSToUserMessage(msg);
    return;
}
  
// Handler untuk Add CS Admin
if (selection && selection.step === 'awaiting_cs_admin_id') {
  await bot.deleteMessage(chatId, msg.message_id).catch(() => {});
  
  const targetUserId = text.trim();
  
  if (!/^\d+$/.test(targetUserId)) {
    await sendNewMessage(chatId,
      'Invalid User ID. Must be numbers only.\nExample: 123456789',
      { parse_mode: 'HTML' }
    );
    userSelections.delete(userId);
    return;
  }
  
  // Cek apakah sudah menjadi CS admin
  const csAdmins = config.cs_admins || [];
  if (csAdmins.includes(targetUserId)) {
    await sendNewMessage(chatId,
      `User <code>${targetUserId}</code> is already a CS Admin.`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '➖ Remove CS', callback_data: `cs_remove_confirm_${targetUserId}` },
              { text: '🔙 Back', callback_data: 'owner_cs_menu' }
            ]
          ]
        }
      }
    );
    userSelections.delete(userId);
    return;
  }
  
  // Konfirmasi penambahan
  await sendNewMessage(chatId,
    `<b>➕ CONFIRM ADD CS ADMIN</b>\n\n` +
    `User ID: <code>${targetUserId}</code>\n\n` +
    `Are you sure you want to add this user as CS Admin?\n\n` +
    `<i>User will be able to access CS features</i>`,
    {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [
            { text: '✅ Yes, Add', callback_data: `cs_add_confirm_${targetUserId}` },
            { text: '❌ Cancel', callback_data: 'owner_cs_menu' }
          ]
        ]
      }
    }
  );
  
  userSelections.delete(userId);
  return;
}

// Handler untuk Remove CS Admin
if (selection && selection.step === 'awaiting_remove_cs_admin_id') {
  await bot.deleteMessage(chatId, msg.message_id).catch(() => {});
  
  const targetUserId = text.trim();
  const csAdmins = config.cs_admins || [];
  
  if (!csAdmins.includes(targetUserId)) {
    await sendNewMessage(chatId,
      `User <code>${targetUserId}</code> is not a CS Admin.\n\n` +
      `Check the CS Admin list first.`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '📋 List CS Admins', callback_data: 'list_cs_admins' },
              { text: '🔙 Back', callback_data: 'owner_cs_menu' }
            ]
          ]
        }
      }
    );
    userSelections.delete(userId);
    return;
  }
  
  // Konfirmasi penghapusan
  await sendNewMessage(chatId,
    `<b>➖ CONFIRM REMOVE CS ADMIN</b>\n\n` +
    `User ID: <code>${targetUserId}</code>\n\n` +
    `Are you sure you want to remove this user as CS Admin?\n\n` +
    `<i>User will no longer access CS features</i>`,
    {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [
            { text: '✅ Yes, Remove', callback_data: `cs_remove_confirm_${targetUserId}` },
            { text: '❌ Cancel', callback_data: 'owner_cs_menu' }
          ]
        ]
      }
    }
  );
  
  userSelections.delete(userId);
  return;
}
  
// Quick balance add any user
if (selection && selection.step === 'balance_add_any') {
  await bot.deleteMessage(chatId, msg.message_id).catch(() => {});
  
  const parts = text.trim().split(/\s+/);
  if (parts.length < 2) {
    await sendNewMessage(chatId,
      'Invalid format. Use: user_id amount\nExample: 123456789 10000',
      { parse_mode: 'HTML' }
    );
    userSelections.delete(userId);
    return;
  }
  
  const targetUserId = parts[0];
  const amount = parseInt(parts[1]);
  
  if (isNaN(amount) || amount < 1000) {
    await sendNewMessage(chatId,
      'Invalid amount. Minimum: 1000',
      { parse_mode: 'HTML' }
    );
    userSelections.delete(userId);
    return;
  }
  
  // Cek user exists
  const data = loadData();
  if (!data.users?.includes(targetUserId)) {
    await sendNewMessage(chatId,
      `User ${targetUserId} not found in system.`,
      { parse_mode: 'HTML' }
    );
    userSelections.delete(userId);
    return;
  }
  
  const oldBalance = getUserBalance(targetUserId);
  const success = addUserBalance(targetUserId, amount);
  const newBalance = getUserBalance(targetUserId);
  
  if (success) {
    await sendNewMessage(chatId,
      `<b>✅ BALANCE ADDED</b>\n\n` +
      `User: ${targetUserId}\n` +
      `Amount: ${formatCurrency(amount)}\n` +
      `Old: ${formatCurrency(oldBalance)}\n` +
      `New: ${formatCurrency(newBalance)}\n\n` +
      `<i>Balance updated</i>`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '➕ Add More', callback_data: 'balance_add_quick' },
              { text: '🔙 Balance Manager', callback_data: 'owner_balance_manager' }
            ]
          ]
        }
      }
    );
  }
  
  userSelections.delete(userId);
  return;
}

// Quick balance deduct any user
if (selection && selection.step === 'balance_deduct_any') {
  await bot.deleteMessage(chatId, msg.message_id).catch(() => {});
  
  const parts = text.trim().split(/\s+/);
  if (parts.length < 2) {
    await sendNewMessage(chatId,
      'Invalid format. Use: user_id amount\nExample: 123456789 5000',
      { parse_mode: 'HTML' }
    );
    userSelections.delete(userId);
    return;
  }
  
  const targetUserId = parts[0];
  const amount = parseInt(parts[1]);
  const currentBalance = getUserBalance(targetUserId);
  
  if (isNaN(amount) || amount <= 0) {
    await sendNewMessage(chatId,
      'Invalid amount.',
      { parse_mode: 'HTML' }
    );
    userSelections.delete(userId);
    return;
  }
  
  if (amount > currentBalance) {
    await sendNewMessage(chatId,
      `Insufficient balance.\nCurrent: ${formatCurrency(currentBalance)}`,
      { parse_mode: 'HTML' }
    );
    userSelections.delete(userId);
    return;
  }
  
  const success = deductUserBalance(targetUserId, amount);
  const newBalance = getUserBalance(targetUserId);
  
  if (success) {
    await sendNewMessage(chatId,
      `<b>✅ BALANCE DEDUCTED</b>\n\n` +
      `User: ${targetUserId}\n` +
      `Amount: ${formatCurrency(amount)}\n` +
      `Old: ${formatCurrency(currentBalance)}\n` +
      `New: ${formatCurrency(newBalance)}\n\n` +
      `<i>Balance updated</i>`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '➖ Deduct More', callback_data: 'balance_deduct_quick' },
              { text: '🔙 Balance Manager', callback_data: 'owner_balance_manager' }
            ]
          ]
        }
      }
    );
  }
  
  userSelections.delete(userId);
  return;
}

// Quick balance reset any user
if (selection && selection.step === 'balance_reset_any') {
  await bot.deleteMessage(chatId, msg.message_id).catch(() => {});
  
  const targetUserId = text.trim();
  const oldBalance = getUserBalance(targetUserId);
  
  const success = setUserBalance(targetUserId, 0);
  
  if (success) {
    await sendNewMessage(chatId,
      `<b>✅ BALANCE RESET</b>\n\n` +
      `User: ${targetUserId}\n` +
      `Old Balance: ${formatCurrency(oldBalance)}\n` +
      `New Balance: ${formatCurrency(0)}\n\n` +
      `<i>Balance reset to 0</i>`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '🔄 Reset More', callback_data: 'balance_reset_quick' },
              { text: '🔙 Balance Manager', callback_data: 'owner_balance_manager' }
            ]
          ]
        }
      }
    );
  }
  
  userSelections.delete(userId);
  return;
}

// Quick ban any user
if (selection && selection.step === 'ban_any_user') {
  await bot.deleteMessage(chatId, msg.message_id).catch(() => {});
  
  const parts = text.trim().split(/\s+/);
  const targetUserId = parts[0];
  const reason = parts.slice(1).join(' ') || 'No reason';
  
  const success = banUser(targetUserId, reason, userId.toString());
  
  if (success) {
    await sendNewMessage(chatId,
      `<b>✅ USER BANNED</b>\n\n` +
      `User: ${targetUserId}\n` +
      `Reason: ${reason}\n` +
      `By: ${user.first_name}\n\n` +
      `<i>User has been banned</i>`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '🚫 Ban More', callback_data: 'ban_user_quick' },
              { text: '🔙 Ban Manager', callback_data: 'owner_ban_manager' }
            ]
          ]
        }
      }
    );
  }
  
  userSelections.delete(userId);
  return;
}

// Quick unban any user
if (selection && selection.step === 'unban_any_user') {
  await bot.deleteMessage(chatId, msg.message_id).catch(() => {});
  
  const targetUserId = text.trim();
  const success = unbanUser(targetUserId, userId.toString());
  
  if (success) {
    await sendNewMessage(chatId,
      `<b>✅ USER UNBANNED</b>\n\n` +
      `User: ${targetUserId}\n` +
      `By: ${user.first_name}\n\n` +
      `<i>User can now access bot</i>`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '✅ Unban More', callback_data: 'unban_user_quick' },
              { text: '🔙 Ban Manager', callback_data: 'owner_ban_manager' }
            ]
          ]
        }
      }
    );
  }
  
  userSelections.delete(userId);
  return;
}

// Handler untuk user management
if (selection && selection.step === 'add_balance_user') {
  await bot.deleteMessage(chatId, msg.message_id).catch(() => {});
  
  const amount = parseInt(text.replace(/[^\d]/g, ''));
  const targetUserId = selection.targetUserId;
  
  if (isNaN(amount) || amount < 1000) {
    await sendNewMessage(chatId,
      `Invalid amount.\n\nMinimum: Rp 1,000\n\nPlease try again.`,
      { parse_mode: 'HTML' }
    );
    return;
  }
  
  const oldBalance = getUserBalance(targetUserId);
  const success = addUserBalance(targetUserId, amount);
  const newBalance = getUserBalance(targetUserId);
  
  if (success) {
    await sendNewMessage(chatId,
      `<b>✅ BALANCE ADDED SUCCESSFULLY</b>\n\n` +
      `User ID: <code>${targetUserId}</code>\n` +
      `Amount Added: ${formatCurrency(amount)}\n` +
      `Old Balance: ${formatCurrency(oldBalance)}\n` +
      `New Balance: ${formatCurrency(newBalance)}\n` +
      `Added by: ${msg.from.first_name}\n\n` +
      `<i>Balance has been updated</i>`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '➕ Add More', callback_data: `user_add_balance_${targetUserId}` },
              { text: '🔙 User Details', callback_data: `user_manage_${targetUserId}` }
            ]
          ]
        }
      }
    );
  } else {
    await sendNewMessage(chatId,
      'Failed to add balance. Please try again.',
      { parse_mode: 'HTML' }
    );
  }
  
  userSelections.delete(userId);
  return;
}

if (selection && selection.step === 'deduct_balance_user') {
  await bot.deleteMessage(chatId, msg.message_id).catch(() => {});
  
  const amount = parseInt(text.replace(/[^\d]/g, ''));
  const targetUserId = selection.targetUserId;
  const currentBalance = getUserBalance(targetUserId);
  
  if (isNaN(amount) || amount <= 0) {
    await sendNewMessage(chatId,
      'Invalid amount. Please try again.',
      { parse_mode: 'HTML' }
    );
    return;
  }
  
  if (amount > currentBalance) {
    await sendNewMessage(chatId,
      `Amount too high.\n\nCurrent balance: ${formatCurrency(currentBalance)}\nRequested: ${formatCurrency(amount)}`,
      { parse_mode: 'HTML' }
    );
    return;
  }
  
  const success = deductUserBalance(targetUserId, amount);
  const newBalance = getUserBalance(targetUserId);
  
  if (success) {
    await sendNewMessage(chatId,
      `<b>✅ BALANCE DEDUCTED SUCCESSFULLY</b>\n\n` +
      `User ID: <code>${targetUserId}</code>\n` +
      `Amount Deducted: ${formatCurrency(amount)}\n` +
      `Old Balance: ${formatCurrency(currentBalance)}\n` +
      `New Balance: ${formatCurrency(newBalance)}\n` +
      `Deducted by: ${msg.from.first_name}\n\n` +
      `<i>Balance has been updated</i>`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '➖ Deduct More', callback_data: `user_deduct_balance_${targetUserId}` },
              { text: '🔙 User Details', callback_data: `user_manage_${targetUserId}` }
            ]
          ]
        }
      }
    );
  } else {
    await sendNewMessage(chatId,
      'Failed to deduct balance. Please try again.',
      { parse_mode: 'HTML' }
    );
  }
  
  userSelections.delete(userId);
  return;
}

if (selection && selection.step === 'ban_user_reason') {
  await bot.deleteMessage(chatId, msg.message_id).catch(() => {});
  
  const reason = text || 'No reason provided';
  const targetUserId = selection.targetUserId;
  
  const success = banUser(targetUserId, reason, userId.toString());
  
  if (success) {
    await sendNewMessage(chatId,
      `<b>✅ USER BANNED SUCCESSFULLY</b>\n\n` +
      `User ID: <code>${targetUserId}</code>\n` +
      `Reason: ${reason}\n` +
      `Banned by: ${msg.from.first_name}\n` +
      `Time: ${new Date().toLocaleString('id-ID')}\n\n` +
      `<i>User has been banned from the bot</i>`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '🔙 User Details', callback_data: `user_manage_${targetUserId}` },
              { text: '🚫 Ban Manager', callback_data: 'owner_ban_manager' }
            ]
          ]
        }
      }
    );
  }
  
  userSelections.delete(userId);
  return;
}

if (selection && selection.step === 'search_user_quick') {
  await bot.deleteMessage(chatId, msg.message_id).catch(() => {});
  
  const searchTerm = text.trim();
  
  if (searchTerm.toLowerCase() === 'banned') {
    // Tampilkan daftar banned users
    const bannedUsers = loadBannedUsers();
    const activeBans = bannedUsers.filter(u => u.status === 'banned');
    
    if (activeBans.length === 0) {
      await sendNewMessage(chatId,
        'No banned users found.',
        { parse_mode: 'HTML' }
      );
      userSelections.delete(userId);
      return;
    }
    
    let message = `<b>🚫 BANNED USERS LIST</b>\n\n`;
    message += `<b>Total:</b> ${activeBans.length} users\n\n`;
    
    activeBans.slice(0, 10).forEach((ban, index) => {
      const banDate = new Date(ban.bannedAt).toLocaleDateString('id-ID');
      message += `<b>${index + 1}. User ${ban.userId.substring(0, 8)}...</b>\n`;
      message += `├ Reason: ${ban.reason || 'No reason'}\n`;
      message += `├ Banned by: ${ban.bannedBy || 'System'}\n`;
      message += `└ Date: ${banDate}\n\n`;
    });
    
    if (activeBans.length > 10) {
      message += `... and ${activeBans.length - 10} more\n`;
    }
    
    const keyboard = [];
    
    // Tambahkan tombol untuk 5 banned user pertama
    activeBans.slice(0, 5).forEach((ban, index) => {
      keyboard.push([
        { 
          text: `${index + 1}. ${ban.userId.substring(0, 8)}...`, 
          callback_data: `user_manage_${ban.userId}` 
        }
      ]);
    });
    
    keyboard.push([
      { text: '🚫 Ban Manager', callback_data: 'owner_ban_manager' },
      { text: '👥 User Manager', callback_data: 'owner_user_manager' }
    ]);
    
    await sendNewMessage(chatId, message, {
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: keyboard }
    });
    
    userSelections.delete(userId);
    return;
  }
  
  // Cari user berdasarkan ID atau username
  let targetUserId = '';
  
  if (searchTerm.startsWith('@')) {
    // Cari berdasarkan username
    const username = searchTerm.substring(1);
    // Di sini perlu query ke database atau cache untuk mencari username
    // Untuk sederhananya, kita minta user ID
    await sendNewMessage(chatId,
      `Please provide User ID instead of username.\n\n` +
      `You can get User ID by forwarding a message from the user to @userinfobot`,
      { parse_mode: 'HTML' }
    );
    userSelections.delete(userId);
    return;
  } else if (/^\d+$/.test(searchTerm)) {
    // Valid user ID
    targetUserId = searchTerm;
  } else {
    await sendNewMessage(chatId,
      'Invalid search term. Please provide User ID (numbers only).',
      { parse_mode: 'HTML' }
    );
    userSelections.delete(userId);
    return;
  }
  
  // Cek apakah user ada di sistem
  const data = loadData();
  if (!data.users?.includes(targetUserId)) {
    await sendNewMessage(chatId,
      `User <code>${targetUserId}</code> not found in system.\n\n` +
      `User may not have started the bot yet.`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '➕ Add to System', callback_data: `force_add_user_${targetUserId}` },
              { text: '🔍 Search Again', callback_data: 'search_user_quick' }
            ]
          ]
        }
      }
    );
    userSelections.delete(userId);
    return;
  }
  
  // Tampilkan detail user
  await showUserManageDetail(chatId, userId, targetUserId);
  userSelections.delete(userId);
  return;
}
  
  // Tambahkan di message handler untuk add/remove admin
if (selection && selection.step === 'add_admin_input') {
  await bot.deleteMessage(chatId, msg.message_id).catch(() => {});
  
  const newAdminId = text.trim();
  
  if (!/^\d+$/.test(newAdminId)) {
    await sendNewMessage(chatId,
      'User ID tidak valid. Harus berupa angka.\n\nContoh: 123456789',
      { parse_mode: 'HTML' }
    );
    userSelections.delete(userId);
    return;
  }
  
  // Cek apakah sudah menjadi admin
  if (owner_ids.includes(newAdminId)) {
    await sendNewMessage(chatId,
      `User ID <code>${newAdminId}</code> sudah menjadi admin.`,
      { parse_mode: 'HTML' }
    );
    userSelections.delete(userId);
    return;
  }
  
  // Tambahkan ke config
  try {
    const configPath = path.join(__dirname, 'config.js');
    let configContent = fs.readFileSync(configPath, 'utf8');
    
    // Update owner_ids array
    configContent = configContent.replace(
      /owner_ids:\s*\[([^\]]+)\]/,
      `owner_ids: [$1, '${newAdminId}']`
    );
    
    fs.writeFileSync(configPath, configContent);
    
    // Reload config
    delete require.cache[require.resolve('./config')];
    const newConfig = require('./config');
    
    // Update global arrays
    owner_ids.length = 0;
    owner_ids.push(...newConfig.owner_ids);
    
    await sendNewMessage(chatId,
      `<b>✅ ADMIN BERHASIL DITAMBAH</b>\n\n` +
      `User ID: <code>${newAdminId}</code>\n` +
      `Ditambahkan oleh: ${msg.from.first_name}\n` +
      `Waktu: ${new Date().toLocaleString('id-ID')}\n\n` +
      `<i>User sekarang memiliki akses owner menu</i>`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: '🔙 Admin Menu', callback_data: 'owner_admin_menu' }]
          ]
        }
      }
    );
    
  } catch (error) {
    await sendNewMessage(chatId,
      `❌ Gagal menambah admin.\n\nError: ${error.message}`,
      { parse_mode: 'HTML' }
    );
  }
  
  userSelections.delete(userId);
  return;
}

if (selection && selection.step === 'remove_admin_input') {
  await bot.deleteMessage(chatId, msg.message_id).catch(() => {});
  
  const adminIdToRemove = text.trim();
  
  // Cek apakah user ID valid
  if (!/^\d+$/.test(adminIdToRemove)) {
    await sendNewMessage(chatId,
      'User ID tidak valid. Harus berupa angka.',
      { parse_mode: 'HTML' }
    );
    userSelections.delete(userId);
    return;
  }
  
  // Cek apakah memang admin
  if (!owner_ids.includes(adminIdToRemove)) {
    await sendNewMessage(chatId,
      `User ID <code>${adminIdToRemove}</code> bukan admin.`,
      { parse_mode: 'HTML' }
    );
    userSelections.delete(userId);
    return;
  }
  
  // Cek apakah mencoba menghapus diri sendiri
  if (adminIdToRemove === userId.toString()) {
    await sendNewMessage(chatId,
      '❌ Tidak bisa menghapus diri sendiri sebagai admin.',
      { parse_mode: 'HTML' }
    );
    userSelections.delete(userId);
    return;
  }
  
  // Hapus dari config
  try {
    const configPath = path.join(__dirname, 'config.js');
    let configContent = fs.readFileSync(configPath, 'utf8');
    
    // Dapatkan current owner_ids
    const match = configContent.match(/owner_ids:\s*\[([^\]]+)\]/);
    if (match) {
      const ownersArray = match[1].split(',').map(id => id.trim().replace(/'/g, '').replace(/"/g, ''));
      const filteredOwners = ownersArray.filter(id => id !== adminIdToRemove);
      
      configContent = configContent.replace(
        /owner_ids:\s*\[([^\]]+)\]/,
        `owner_ids: [${filteredOwners.map(id => `'${id}'`).join(', ')}]`
      );
      
      fs.writeFileSync(configPath, configContent);
      
      // Reload config
      delete require.cache[require.resolve('./config')];
      const newConfig = require('./config');
      
      // Update global arrays
      owner_ids.length = 0;
      owner_ids.push(...newConfig.owner_ids);
      
      await sendNewMessage(chatId,
        `<b>✅ ADMIN BERHASIL DIHAPUS</b>\n\n` +
        `User ID: <code>${adminIdToRemove}</code>\n` +
        `Dihapus oleh: ${msg.from.first_name}\n` +
        `Waktu: ${new Date().toLocaleString('id-ID')}\n\n` +
        `<i>User tidak lagi memiliki akses owner menu</i>`,
        {
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [{ text: '🔙 Admin Menu', callback_data: 'owner_admin_menu' }]
            ]
          }
        }
      );
    }
    
  } catch (error) {
    await sendNewMessage(chatId,
      `❌ Gagal menghapus admin.\n\nError: ${error.message}`,
      { parse_mode: 'HTML' }
    );
  }
  
  userSelections.delete(userId);
  return;
}

if (selection && selection.step === 'search_user_id') {
  await bot.deleteMessage(chatId, msg.message_id).catch(() => {});
  
  const targetUserId = text.trim();
  
  if (!/^\d+$/.test(targetUserId)) {
    await sendNewMessage(chatId,
      'User ID tidak valid. Harus berupa angka.\n\nContoh: 123456789',
      { parse_mode: 'HTML' }
    );
    return;
  }
  
  await showUserDetails(userId, targetUserId, chatId);
  userSelections.delete(userId);
  return;
}

if (selection && selection.step === 'add_balance') {
  await bot.deleteMessage(chatId, msg.message_id).catch(() => {});
  
  const amount = parseInt(text.replace(/[^\d]/g, ''));
  const targetUserId = selection.targetUserId;
  
  if (isNaN(amount) || amount < 2000) {
    await sendNewMessage(chatId,
      `Jumlah tidak valid.\n\nMinimal: Rp 1,000\n\nSilakan coba lagi.`,
      { parse_mode: 'HTML' }
    );
    return;
  }
  
  const oldBalance = getUserBalance(targetUserId);
  const success = addUserBalance(targetUserId, amount);
  const newBalance = getUserBalance(targetUserId);
  
  if (success) {
    await sendNewMessage(chatId,
      `<b>✅ SALDO BERHASIL DITAMBAH</b>\n\n` +
      `User ID: <code>${targetUserId}</code>\n` +
      `Jumlah: ${formatCurrency(amount)}\n` +
      `Saldo Lama: ${formatCurrency(oldBalance)}\n` +
      `Saldo Baru: ${formatCurrency(newBalance)}\n` +
      `Admin: ${user.first_name}\n\n` +
      `<i>Saldo telah berhasil ditambahkan</i>`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: '🔙 User Details', callback_data: `user_detail_${targetUserId}` }]
          ]
        }
      }
    );
  } else {
    await sendNewMessage(chatId,
      'Gagal menambah saldo. Silakan coba lagi.',
      { parse_mode: 'HTML' }
    );
  }
  
  userSelections.delete(userId);
  return;
}

if (selection && selection.step === 'deduct_balance') {
  await bot.deleteMessage(chatId, msg.message_id).catch(() => {});
  
  const amount = parseInt(text.replace(/[^\d]/g, ''));
  const targetUserId = selection.targetUserId;
  
  if (isNaN(amount) || amount <= 0) {
    await sendNewMessage(chatId,
      'Jumlah tidak valid. Silakan coba lagi.',
      { parse_mode: 'HTML' }
    );
    return;
  }
  
  const oldBalance = getUserBalance(targetUserId);
  
  if (amount > oldBalance) {
    await sendNewMessage(chatId,
      `Jumlah terlalu besar.\n\nSaldo user: ${formatCurrency(oldBalance)}\nJumlah yang diminta: ${formatCurrency(amount)}`,
      { parse_mode: 'HTML' }
    );
    return;
  }
  
  const success = deductUserBalance(targetUserId, amount);
  const newBalance = getUserBalance(targetUserId);
  
  if (success) {
    await sendNewMessage(chatId,
      `<b>✅ SALDO BERHASIL DIKURANGI</b>\n\n` +
      `User ID: <code>${targetUserId}</code>\n` +
      `Jumlah: ${formatCurrency(amount)}\n` +
      `Saldo Lama: ${formatCurrency(oldBalance)}\n` +
      `Saldo Baru: ${formatCurrency(newBalance)}\n` +
      `Admin: ${user.first_name}\n\n` +
      `<i>Saldo telah berhasil dikurangi</i>`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: '🔙 User Details', callback_data: `user_detail_${targetUserId}` }]
          ]
        }
      }
    );
  } else {
    await sendNewMessage(chatId,
      'Gagal mengurangi saldo. Silakan coba lagi.',
      { parse_mode: 'HTML' }
    );
  }
  
  userSelections.delete(userId);
  return;
}

if (selection && selection.step === 'ban_user') {
  await bot.deleteMessage(chatId, msg.message_id).catch(() => {});
  
  selection.reason = text || 'No reason provided';
  userSelections.set(userId, selection);
  
  const targetUserId = selection.targetUserId;
  
  await editMessage(chatId, selection.messageId, null,
    `<b>🚫 KONFIRMASI BAN USER</b>\n\n` +
    `User ID: <code>${targetUserId}</code>\n` +
    `Alasan: ${selection.reason}\n\n` +
    `Yakin ingin memblokir user ini?`,
    {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [
            { text: '✅ Ya, Ban User', callback_data: `confirm_ban_${targetUserId}` },
            { text: '❌ Batalkan', callback_data: `user_detail_${targetUserId}` }
          ]
        ]
      }
    }
  );
  return;
}
  
  if (selection && selection.step === 'awaiting_voucher_value') {
    await bot.deleteMessage(chatId, msg.message_id).catch(() => {});
    
    const value = parseInt(text);
    
    if (isNaN(value) || value <= 0) {
        await sendNewMessage(chatId,
            'Nilai tidak valid. Silakan masukkan angka yang benar.',
            { parse_mode: 'HTML' }
        );
        return;
    }
    
    const voucherType = selection.voucherData.type;
    
    if (voucherType === 'percentage' && value > 100) {
        await sendNewMessage(chatId,
            'Persentase tidak boleh lebih dari 100%.',
            { parse_mode: 'HTML' }
        );
        return;
    }
    
    if (voucherType === 'fixed' && value > 1000000) {
        await sendNewMessage(chatId,
            'Fixed amount tidak boleh lebih dari Rp 1.000.000.',
            { parse_mode: 'HTML' }
        );
        return;
    }
    
    selection.voucherData.value = value;
    selection.step = 'awaiting_voucher_minmax';
    userSelections.set(userId, selection);
    
    await showCreateVoucherStep3(chatId, userId);
    return;
  }
  
  if (selection && selection.step === 'awaiting_voucher_minmax') {
    await bot.deleteMessage(chatId, msg.message_id).catch(() => {});
    
    const parts = text.trim().split(/\s+/);
    
    if (parts.length === 1 && parts[0].toLowerCase() === 'skip') {
        selection.voucherData.min_purchase = 0;
        selection.voucherData.max_discount = null;
    } else {
        const minPurchase = parseInt(parts[0]) || 0;
        const maxDiscount = parts[1] ? parseInt(parts[1]) : null;
        
        selection.voucherData.min_purchase = minPurchase;
        selection.voucherData.max_discount = maxDiscount;
    }
    
    selection.step = 'awaiting_voucher_limit';
    userSelections.set(userId, selection);
    
    await showCreateVoucherStep4(chatId, userId);
    return;
  }
  
  if (selection && selection.step === 'awaiting_voucher_limit') {
    await bot.deleteMessage(chatId, msg.message_id).catch(() => {});
    
    const parts = text.trim().split(/\s+/);
    
    if (parts.length === 1 && parts[0].toLowerCase() === 'skip') {
        selection.voucherData.usage_limit = 1;
        selection.voucherData.expiry = null;
    } else {
        const limit = parseInt(parts[0]) || 1;
        let expiry = null;
        
        if (parts[1]) {
            const dateParts = parts[1].split('-');
            if (dateParts.length === 3) {
                const day = parseInt(dateParts[0]);
                const month = parseInt(dateParts[1]) - 1;
                const year = parseInt(dateParts[2]);
                
                if (!isNaN(day) && !isNaN(month) && !isNaN(year)) {
                    expiry = new Date(year, month, day, 23, 59, 59).toISOString();
                }
            }
        }
        
        selection.voucherData.usage_limit = limit;
        selection.voucherData.expiry = expiry;
    }
    
    selection.step = 'awaiting_voucher_final';
    userSelections.set(user.id, selection);
    
    await showCreateVoucherStep5(chatId, user.id);
    return;
  }
  
  if (selection && selection.step === 'awaiting_voucher_final') {
    await bot.deleteMessage(chatId, msg.message_id).catch(() => {});
    
    const parts = text.trim().split(/\s+/);
    let code = null;
    let description = null;
    
    if (parts.length > 0) {
        code = parts[0].toUpperCase();
        description = parts.slice(1).join(' ') || null;
    }
    
    if (code && code !== 'SKIP') {
        selection.voucherData.code = code;
    }
    
    if (description && description !== 'SKIP') {
        selection.voucherData.description = description;
    }
    
    await finalizeVoucherCreation(chatId, userId);
    
    userSelections.delete(user.id);
    return;
  }
  
  if (selection && selection.voucherInput && selection.voucherInput.step === 'awaiting_voucher') {
    await bot.deleteMessage(chatId, msg.message_id).catch(() => {});
    
    const voucherInput = selection.voucherInput;
    
    if (text === '0' || text.toLowerCase() === 'batal') {
      delete selection.voucherInput;
      userSelections.set(userId, selection);
      
      await showOrderConfirmation(chatId, userId, voucherInput.operatorId, voucherInput.providerId, voucherInput.price);
      return;
    }
    
    await validateAndApplyVoucher(chatId, userId, voucherInput.operatorId, voucherInput.providerId, voucherInput.price, text.toUpperCase());
    
    delete selection.voucherInput;
    userSelections.set(userId, selection);
    
    return;
  }
  
  if (selection && selection.step === 'rumahotp_deposit_amount') {
    const amount = parseInt(text.replace(/[^\d]/g, ''));
    
    if (isNaN(amount) || amount < 2000 || amount > 5000000) {
        await sendNewMessage(chatId,
            `Nilai tidak valid.\n\nMinimal: Rp 2,000\nMaksimal: Rp 5,000,000`,
            { 
              parse_mode: 'HTML',
              reply_markup: { 
                inline_keyboard: [
                  [{ text: 'Coba Lagi', callback_data: 'deposit_main' }]
                ] 
              } 
            }
        );
        userSelections.delete(userId);
        return;
    }

    userSelections.delete(userId);
    
    await bot.deleteMessage(chatId, msg.message_id).catch(() => {});
    
    await handleRumahOTPDeposit(chatId, userId, amount);
  }
});

// ========================= CALLBACK QUERY HANDLER =========================

bot.on("callback_query", async (callbackQuery) => {
  const msg = callbackQuery.message;
  const user = callbackQuery.from;
  const data = callbackQuery.data;
  const chatId = msg.chat.id;
  const messageId = msg.message_id;
  const callbackQueryId = callbackQuery.id;
  
  try {
    bot.answerCallbackQuery(callbackQueryId, { 
      text: '',
      show_alert: false 
    }).catch(() => {});
    
    // Handler untuk tombol Previous (◀️)
if (data.startsWith('nokos_menu_prev_')) {
    const currentPage = parseInt(data.replace('nokos_menu_prev_', ''));
    const newPage = currentPage - 1;
    console.log(`Previous clicked: currentPage=${currentPage}, newPage=${newPage}`);
    await showNokosMenu(chatId, user.id, messageId, callbackQueryId, newPage);
    return;
}

// Handler untuk tombol Next (▶️)
if (data.startsWith('nokos_menu_next_')) {
    const currentPage = parseInt(data.replace('nokos_menu_next_', ''));
    const newPage = currentPage + 1;
    console.log(`Next clicked: currentPage=${currentPage}, newPage=${newPage}`);
    await showNokosMenu(chatId, user.id, messageId, callbackQueryId, newPage);
    return;
}

// Handler untuk page tertentu (jika masih ada)
if (data.startsWith('nokos_menu_page_')) {
    const page = parseInt(data.replace('nokos_menu_page_', ''));
    console.log(`Direct page: ${page}`);
    await showNokosMenu(chatId, user.id, messageId, callbackQueryId, page);
    return;
}
    
    // Handler untuk pagination menu utama (layanan lainnya)
if (data.startsWith('nokos_menu_page_')) {
    const page = parseInt(data.replace('nokos_menu_page_', ''));
    await showNokosMenu(chatId, user.id, messageId, callbackQueryId, 0);
    return;
}
    
// Handler untuk pagination layanan lainnya
if (data.startsWith('other_services_page_')) {
    const page = parseInt(data.replace('other_services_page_', ''));
    await showOtherServices(chatId, user.id, messageId, callbackQueryId, page);
    return;
}

// Handler untuk pagination negara
if (data.startsWith('nokos_country_page_')) {
    const parts = data.replace('nokos_country_page_', '').split('_');
    const serviceId = parts[0];
    const page = parseInt(parts[1]);
    
    // Dapatkan service name dari cache atau selection
    const servicesData = await getServicesCached();
    if (servicesData && servicesData.success) {
        const service = servicesData.data.find(s => s.service_code == serviceId);
        if (service) {
            await showCountryMenu(chatId, user.id, serviceId, service.service_name, messageId, callbackQueryId, page);
        }
    }
    return;
}

// Handler untuk pencarian layanan
if (data === 'search_service') {
    await showSearchService(chatId, user.id, messageId, callbackQueryId);
    return;
}

// Handler untuk pencarian negara
if (data.startsWith('search_country_')) {
    const serviceId = data.replace('search_country_', '');
    await showSearchCountry(chatId, user.id, serviceId, messageId, callbackQueryId);
    return;
}

// WITHDRAW CALLBACK HANDLERS
if (data === 'withdraw_menu') {
    await showWithdrawMenu(chatId, user.id, messageId, callbackQueryId);
    return;
}

if (data.startsWith('withdraw_menu_page_')) {
    const page = parseInt(data.replace('withdraw_menu_page_', ''));
    await showWithdrawMenu(chatId, user.id, messageId, callbackQueryId, page);
    return;
}

if (data.startsWith('withdraw_brand_')) {
    const parts = data.replace('withdraw_brand_', '').split('_');
    const brand = parts[0];
    const menuPage = parseInt(parts[1]) || 0;
    await showWithdrawBrandProducts(chatId, user.id, brand, menuPage, messageId, callbackQueryId);
    return;
}

if (data.startsWith('withdraw_brand_products_')) {
    const parts = data.replace('withdraw_brand_products_', '').split('_');
    const brand = parts[0];
    const menuPage = parseInt(parts[1]) || 0;
    const productPage = parseInt(parts[2]) || 0;
    await showWithdrawBrandProducts(chatId, user.id, brand, menuPage, messageId, callbackQueryId, productPage);
    return;
}

if (data.startsWith('withdraw_product_')) {
    const parts = data.replace('withdraw_product_', '').split('_');
    const productCode = parts[0];
    const brand = parts[1];
    const menuPage = parseInt(parts[2]) || 0;
    const productPage = parseInt(parts[3]) || 0;
    await showWithdrawProductDetail(chatId, user.id, productCode, brand, menuPage, productPage, messageId, callbackQueryId);
    return;
}

if (data === 'withdraw_history') {
    await showWithdrawHistory(chatId, user.id, messageId, callbackQueryId);
    return;
}

if (data.startsWith('withdraw_history_page_')) {
    const page = parseInt(data.replace('withdraw_history_page_', ''));
    await showWithdrawHistory(chatId, user.id, messageId, callbackQueryId, page);
    return;
}
    
    // CS Chat Callbacks
if (data === 'cs_chat') {
    await startCSChat(chatId, user.id, messageId, callbackQueryId);
    return;
}
    
if (data.startsWith('cs_join_')) {
    const threadId = data.replace('cs_join_', '');
    await joinCSThread(chatId, user.id, threadId, messageId, callbackQueryId);
    return;
}
    
if (data.startsWith('cs_view_thread_')) {
    const threadId = data.replace('cs_view_thread_', '');
    await showCSStatus(chatId, user.id, threadId, messageId, callbackQueryId);
    return;
}
    
if (data.startsWith('cs_status_')) {
    const threadId = data.replace('cs_status_', '');
    await showCSStatus(chatId, user.id, threadId, messageId, callbackQueryId);
    return;
}
    
if (data.startsWith('cs_reply_')) {
    const threadId = data.replace('cs_reply_', '');
    await promptCSReply(chatId, user.id, threadId, messageId, callbackQueryId);
    return;
}
    
if (data.startsWith('cs_close_')) {
    const threadId = data.replace('cs_close_', '');
    await endCSChat(chatId, user.id, messageId, callbackQueryId, true);
    return;
}
    
if (data === 'cs_cancel_chat') {
    await endCSChat(chatId, user.id, messageId, callbackQueryId);
    return;
}
    
if (data === 'cs_end_chat_user') {
    await endCSChat(chatId, user.id, messageId, callbackQueryId);
    return;
}
    
if (data === 'cs_active_threads') {
    await showActiveCSThreads(chatId, user.id, messageId, callbackQueryId);
    return;
}
    
if (data === 'cs_stats') {
    await showCSStats(chatId, user.id, messageId, callbackQueryId);
    return;
}
    
    // CS Admin Callback Handlers
if (data === 'add_cs_admin') {
  await addCSAdminHandler(chatId, user.id, messageId, callbackQueryId);
  return;
}

if (data === 'remove_cs_admin') {
  await removeCSAdminHandler(chatId, user.id, messageId, callbackQueryId);
  return;
}

if (data === 'list_cs_admins') {
  await listCSAdminsHandler(chatId, user.id, messageId, callbackQueryId);
  return;
}

if (data.startsWith('cs_admin_info_')) {
  const targetAdminId = data.replace('cs_admin_info_', '');
  await showCSAdminInfo(chatId, user.id, targetAdminId, messageId, callbackQueryId);
  return;
}

if (data.startsWith('cs_add_confirm_')) {
  const targetAdminId = data.replace('cs_add_confirm_', '');
  await confirmAddCSAdmin(chatId, user.id, targetAdminId, messageId, callbackQueryId);
  return;
}

if (data.startsWith('cs_remove_confirm_')) {
  const targetAdminId = data.replace('cs_remove_confirm_', '');
  await confirmRemoveCSAdmin(chatId, user.id, targetAdminId, messageId, callbackQueryId);
  return;
}
    
    if (data === 'ban_list_full') {
  const bannedUsers = loadBannedUsers();
  const activeBans = bannedUsers.filter(user => user.status === 'banned');
  
  if (activeBans.length === 0) {
    await editMessage(chatId, messageId, callbackQueryId,
      `<b>🚫 BANNED USERS</b>\n\nNo users are currently banned.`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: '🔙 Back', callback_data: 'owner_ban_manager' }]
          ]
        }
      }
    );
    return;
  }
  
  let message = `<b>🚫 FULL BAN LIST</b>\n\n`;
  message += `<b>Total Banned:</b> ${activeBans.length}\n\n`;
  
  activeBans.forEach((ban, index) => {
    const banDate = new Date(ban.bannedAt).toLocaleDateString('id-ID');
    message += `<b>${index + 1}. User ${ban.userId}</b>\n`;
    message += `├ Reason: ${ban.reason || 'No reason'}\n`;
    message += `├ By: ${ban.bannedBy || 'System'}\n`;
    message += `└ Date: ${banDate}\n\n`;
  });
  
  const keyboard = [];
  
  // Add buttons for first 5 banned users
  activeBans.slice(0, 5).forEach((ban, index) => {
    keyboard.push([
      { 
        text: `${index + 1}. ${ban.userId.substring(0, 8)}...`, 
        callback_data: `user_manage_${ban.userId}` 
      }
    ]);
  });
  
  keyboard.push([
    { text: '🔙 Back', callback_data: 'owner_ban_manager' },
    { text: '🔄 Refresh', callback_data: 'ban_list_full' }
  ]);
  
  await editMessage(chatId, messageId, callbackQueryId, message, {
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: keyboard },
    disable_web_page_preview: true
  });
  
  return;
}

if (data === 'balance_add_quick') {
  const selection = {
    step: 'balance_add_any',
    timestamp: Date.now()
  };
  userSelections.set(userId, selection);
  
  await editMessage(chatId, messageId, callbackQueryId,
    `<b>➕ ADD BALANCE</b>\n\n` +
    `Send user ID and amount:\n\n` +
    `Format: <code>user_id amount</code>\n` +
    `Example: <code>123456789 10000</code>\n\n` +
    `<i>User must exist in system</i>`,
    {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [{ text: '🔙 Back', callback_data: 'owner_balance_manager' }]
        ]
      }
    }
  );
  return;
}

if (data === 'balance_deduct_quick') {
  const selection = {
    step: 'balance_deduct_any',
    timestamp: Date.now()
  };
  userSelections.set(userId, selection);
  
  await editMessage(chatId, messageId, callbackQueryId,
    `<b>➖ DEDUCT BALANCE</b>\n\n` +
    `Send user ID and amount:\n\n` +
    `Format: <code>user_id amount</code>\n` +
    `Example: <code>123456789 5000</code>\n\n` +
    `<i>User must have enough balance</i>`,
    {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [{ text: '🔙 Back', callback_data: 'owner_balance_manager' }]
        ]
      }
    }
  );
  return;
}

if (data === 'balance_reset_quick') {
  const selection = {
    step: 'balance_reset_any',
    timestamp: Date.now()
  };
  userSelections.set(userId, selection);
  
  await editMessage(chatId, messageId, callbackQueryId,
    `<b>🔄 RESET BALANCE</b>\n\n` +
    `Send user ID to reset balance to 0:\n\n` +
    `Example: <code>123456789</code>\n\n` +
    `<i>This cannot be undone!</i>`,
    {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [{ text: '🔙 Back', callback_data: 'owner_balance_manager' }]
        ]
      }
    }
  );
  return;
}

if (data === 'ban_user_quick') {
  const selection = {
    step: 'ban_any_user',
    timestamp: Date.now()
  };
  userSelections.set(userId, selection);
  
  await editMessage(chatId, messageId, callbackQueryId,
    `<b>🚫 BAN USER</b>\n\n` +
    `Send user ID and reason:\n\n` +
    `Format: <code>user_id reason</code>\n` +
    `Example: <code>123456789 spamming</code>\n\n` +
    `<i>User will be banned immediately</i>`,
    {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [{ text: '🔙 Back', callback_data: 'owner_ban_manager' }]
        ]
      }
    }
  );
  return;
}

if (data === 'unban_user_quick') {
  const selection = {
    step: 'unban_any_user',
    timestamp: Date.now()
  };
  userSelections.set(userId, selection);
  
  await editMessage(chatId, messageId, callbackQueryId,
    `<b>✅ UNBAN USER</b>\n\n` +
    `Send user ID to unban:\n\n` +
    `Example: <code>123456789</code>\n\n` +
    `<i>User will be able to use bot again</i>`,
    {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [{ text: '🔙 Back', callback_data: 'owner_ban_manager' }]
        ]
      }
    }
  );
  return;
}
    
    if (data === 'owner_database') {
  await showDatabaseMenu(chatId, user.id, messageId, callbackQueryId);
  return;
}
    
if (data === 'owner_user_stats') {
  await showUserStats(chatId, user.id, messageId, callbackQueryId);
  return;
}

// Owner Settings Sub-menus
if (data === 'owner_user_manager') {
  await showUserManager(chatId, user.id, messageId, callbackQueryId);
  return;
}

if (data === 'owner_balance_manager') {
  await showBalanceManager(chatId, user.id, messageId, callbackQueryId);
  return;
}

if (data === 'owner_ban_manager') {
  await showBanManager(chatId, user.id, messageId, callbackQueryId);
  return;
}

if (data.startsWith('user_manager_page_')) {
  const page = parseInt(data.replace('user_manager_page_', ''));
  await showUserManager(chatId, user.id, messageId, callbackQueryId, page);
  return;
}

if (data.startsWith('user_manage_')) {
  const targetUserId = data.replace('user_manage_', '');
  await showUserManageDetail(chatId, user.id, targetUserId, messageId, callbackQueryId);
  return;
}

// Balance actions
if (data.startsWith('user_add_balance_')) {
  const targetUserId = data.replace('user_add_balance_', '');
  const selection = {
    step: 'add_balance_user',
    targetUserId: targetUserId,
    timestamp: Date.now()
  };
  userSelections.set(user.id, selection);
  
  await editMessage(chatId, messageId, callbackQueryId,
    `<b>➕ ADD BALANCE TO USER</b>\n\n` +
    `User ID: <code>${targetUserId}</code>\n\n` +
    `Enter amount to add:\n` +
    `Example: <code>10000</code> for Rp 10,000\n\n` +
    `<i>Minimum: Rp 1,000</i>`,
    {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [{ text: '💰 Quick: 10K', callback_data: `quick_add_${targetUserId}_10000` }],
          [{ text: '💰 Quick: 50K', callback_data: `quick_add_${targetUserId}_50000` }],
          [{ text: '💰 Quick: 100K', callback_data: `quick_add_${targetUserId}_100000` }],
          [
            { text: '🔙 Back', callback_data: `user_manage_${targetUserId}` },
            { text: '❌ Cancel', callback_data: `user_manage_${targetUserId}` }
          ]
        ]
      }
    }
  );
  return;
}

if (data.startsWith('quick_add_')) {
  const parts = data.replace('quick_add_', '').split('_');
  const targetUserId = parts[0];
  const amount = parseInt(parts[1]);
  
  const oldBalance = getUserBalance(targetUserId);
  const success = addUserBalance(targetUserId, amount);
  const newBalance = getUserBalance(targetUserId);
  
  if (success) {
    await editMessage(chatId, messageId, callbackQueryId,
      `<b>✅ BALANCE ADDED SUCCESSFULLY</b>\n\n` +
      `User ID: <code>${targetUserId}</code>\n` +
      `Amount Added: ${formatCurrency(amount)}\n` +
      `Old Balance: ${formatCurrency(oldBalance)}\n` +
      `New Balance: ${formatCurrency(newBalance)}\n` +
      `Added by: ${user.first_name}\n\n` +
      `<i>Balance has been updated</i>`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '➕ Add More', callback_data: `user_add_balance_${targetUserId}` },
              { text: '🔙 Back', callback_data: `user_manage_${targetUserId}` }
            ]
          ]
        }
      }
    );
  }
  return;
}

if (data.startsWith('user_deduct_balance_')) {
  const targetUserId = data.replace('user_deduct_balance_', '');
  const currentBalance = getUserBalance(targetUserId);
  
  const selection = {
    step: 'deduct_balance_user',
    targetUserId: targetUserId,
    timestamp: Date.now()
  };
  userSelections.set(user.id, selection);
  
  await editMessage(chatId, messageId, callbackQueryId,
    `<b>➖ DEDUCT BALANCE FROM USER</b>\n\n` +
    `User ID: <code>${targetUserId}</code>\n` +
    `Current Balance: ${formatCurrency(currentBalance)}\n\n` +
    `Enter amount to deduct:\n` +
    `Example: <code>5000</code> for Rp 5,000\n\n` +
    `<i>Maximum: ${formatCurrency(currentBalance)}</i>`,
    {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [
            { text: '🔙 Back', callback_data: `user_manage_${targetUserId}` },
            { text: '❌ Cancel', callback_data: `user_manage_${targetUserId}` }
          ]
        ]
      }
    }
  );
  return;
}

if (data.startsWith('user_reset_balance_')) {
  const targetUserId = data.replace('user_reset_balance_', '');
  const currentBalance = getUserBalance(targetUserId);
  
  await editMessage(chatId, messageId, callbackQueryId,
    `<b>🔄 RESET USER BALANCE</b>\n\n` +
    `User ID: <code>${targetUserId}</code>\n` +
    `Current Balance: ${formatCurrency(currentBalance)}\n\n` +
    `Are you sure you want to reset this user's balance to 0?\n\n` +
    `<i>This action cannot be undone!</i>`,
    {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [
            { text: '✅ Yes, Reset to 0', callback_data: `confirm_reset_balance_${targetUserId}` },
            { text: '❌ Cancel', callback_data: `user_manage_${targetUserId}` }
          ]
        ]
      }
    }
  );
  return;
}

if (data.startsWith('confirm_reset_balance_')) {
  const targetUserId = data.replace('confirm_reset_balance_', '');
  const oldBalance = getUserBalance(targetUserId);
  
  const success = setUserBalance(targetUserId, 0);
  
  if (success) {
    await editMessage(chatId, messageId, callbackQueryId,
      `<b>✅ BALANCE RESET SUCCESSFULLY</b>\n\n` +
      `User ID: <code>${targetUserId}</code>\n` +
      `Old Balance: ${formatCurrency(oldBalance)}\n` +
      `New Balance: ${formatCurrency(0)}\n` +
      `Reset by: ${user.first_name}\n\n` +
      `<i>Balance has been reset to 0</i>`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '🔙 Back', callback_data: `user_manage_${targetUserId}` },
              { text: '👥 User List', callback_data: 'owner_user_manager' }
            ]
          ]
        }
      }
    );
  }
  return;
}

// Ban actions
if (data.startsWith('user_ban_')) {
  const targetUserId = data.replace('user_ban_', '');
  const selection = {
    step: 'ban_user_reason',
    targetUserId: targetUserId,
    timestamp: Date.now()
  };
  userSelections.set(user.id, selection);
  
  await editMessage(chatId, messageId, callbackQueryId,
    `<b>🚫 BAN USER</b>\n\n` +
    `User ID: <code>${targetUserId}</code>\n\n` +
    `Enter ban reason:\n` +
    `Example: <code>Violating terms of service</code>\n\n` +
    `<i>Leave empty for no reason</i>`,
    {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [
            { text: '🚫 Spamming', callback_data: `quick_ban_${targetUserId}_spamming` },
            { text: '💰 Chargeback', callback_data: `quick_ban_${targetUserId}_chargeback` }
          ],
          [
            { text: '📛 Harassment', callback_data: `quick_ban_${targetUserId}_harassment` },
            { text: '⚖️ Terms Violation', callback_data: `quick_ban_${targetUserId}_terms` }
          ],
          [
            { text: '🔙 Back', callback_data: `user_manage_${targetUserId}` },
            { text: '❌ Cancel', callback_data: `user_manage_${targetUserId}` }
          ]
        ]
      }
    }
  );
  return;
}

if (data.startsWith('quick_ban_')) {
  const parts = data.replace('quick_ban_', '').split('_');
  const targetUserId = parts[0];
  const reasonType = parts[1];
  
  const reasonMap = {
    'spamming': 'Spamming/Flooding',
    'chargeback': 'Payment chargeback',
    'harassment': 'Harassment/Abuse',
    'terms': 'Terms of service violation'
  };
  
  const reason = reasonMap[reasonType] || 'Violation of rules';
  const success = banUser(targetUserId, reason, user.id.toString());
  
  if (success) {
    await editMessage(chatId, messageId, callbackQueryId,
      `<b>✅ USER BANNED SUCCESSFULLY</b>\n\n` +
      `User ID: <code>${targetUserId}</code>\n` +
      `Reason: ${reason}\n` +
      `Banned by: ${user.first_name}\n` +
      `Time: ${new Date().toLocaleString('id-ID')}\n\n` +
      `<i>User has been banned from the bot</i>`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '🔙 Back', callback_data: `user_manage_${targetUserId}` },
              { text: '🚫 Ban List', callback_data: 'owner_ban_manager' }
            ]
          ]
        }
      }
    );
  }
  return;
}

if (data.startsWith('user_unban_')) {
  const targetUserId = data.replace('user_unban_', '');
  const success = unbanUser(targetUserId, user.id.toString());
  
  if (success) {
    await editMessage(chatId, messageId, callbackQueryId,
      `<b>✅ USER UNBANNED SUCCESSFULLY</b>\n\n` +
      `User ID: <code>${targetUserId}</code>\n` +
      `Unbanned by: ${user.first_name}\n` +
      `Time: ${new Date().toLocaleString('id-ID')}\n\n` +
      `<i>User can now access the bot again</i>`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '🔙 Back', callback_data: `user_manage_${targetUserId}` },
              { text: '🚫 Ban Manager', callback_data: 'owner_ban_manager' }
            ]
          ]
        }
      }
    );
  }
  return;
}

// Quick search
if (data === 'search_user_quick') {
  const selection = {
    step: 'search_user_quick',
    timestamp: Date.now()
  };
  userSelections.set(user.id, selection);
  
  await editMessage(chatId, messageId, callbackQueryId,
    `<b>🔍 QUICK USER SEARCH</b>\n\n` +
    `Send user ID or username to search:\n\n` +
    `Examples:\n` +
    `• <code>123456789</code> (User ID)\n` +
    `• <code>@username</code> (Username)\n` +
    `• <code>banned</code> (Search banned users)\n\n` +
    `<i>User must have started the bot before</i>`,
    {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [{ text: '🔙 Back', callback_data: 'owner_user_manager' }]
        ]
      }
    }
  );
  return;
}
    
    if (data === 'cs_active_threads') {
  await showActiveCSThreads(chatId, user.id, messageId, callbackQueryId);
  return;
}

if (data === 'cs_stats') {
  await showCSStats(chatId, user.id, messageId, callbackQueryId);
  return;
}
    
    // CS Chat Callback Handlers
if (data.startsWith('cs_start_reply_')) {
  const chatThreadId = data.replace('cs_start_reply_', '');
  
  // Cari chat session
  const chatSession = global.csChatSessions?.get(chatThreadId);
  if (!chatSession) {
    await bot.answerCallbackQuery(callbackQueryId, {
      text: '❌ Thread chat tidak ditemukan',
      show_alert: true
    });
    return;
  }
  
  // Set admin sebagai penanggung jawab
  chatSession.adminId = user.id.toString();
  chatSession.adminName = user.first_name;
  chatSession.status = 'active';
  
  // Update session
  global.csChatSessions.set(chatThreadId, chatSession);
  
  // Set user selection untuk admin
  const adminSelection = {
    step: 'cs_admin_reply',
    csThreadId: chatThreadId,
    targetUserId: chatSession.userId,
    targetUserName: chatSession.userName,
    timestamp: Date.now()
  };
  userSelections.set(user.id, adminSelection);
  
  await editMessage(chatId, messageId, callbackQueryId,
    `<b>💬 BALAS PESAN USER</b>\n\n` +
    `<b>Thread ID:</b> <code>${chatThreadId}</code>\n` +
    `<b>User:</b> ${chatSession.userName}\n` +
    `<b>User ID:</b> <code>${chatSession.userId}</code>\n\n` +
    `<b>Pesan Terakhir:</b>\n${chatSession.messages[chatSession.messages.length - 1]?.message || 'Tidak ada pesan'}\n\n` +
    `<b>Kirim balasan Anda:</b>\n` +
    `<i>Ketik pesan yang ingin dikirim ke user</i>`,
    {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [{ text: '👁️ Lihat Thread Lengkap', callback_data: `cs_view_thread_${chatThreadId}` }],
          [{ text: '❌ Batalkan', callback_data: `cs_cancel_reply_${chatThreadId}` }]
        ]
      }
    }
  );
  
  await bot.answerCallbackQuery(callbackQueryId, {
    text: '✅ Anda sekarang menangani chat ini',
    show_alert: false
  });
  
  return;
}

if (data.startsWith('cs_view_thread_')) {
  const chatThreadId = data.replace('cs_view_thread_', '');
  
  const chatSession = global.csChatSessions?.get(chatThreadId);
  if (!chatSession) {
    await bot.answerCallbackQuery(callbackQueryId, {
      text: '❌ Thread chat tidak ditemukan',
      show_alert: true
    });
    return;
  }
  
  let threadMessage = `<b>💬 CHAT THREAD</b>\n\n`;
  threadMessage += `<b>Thread ID:</b> <code>${chatThreadId}</code>\n`;
  threadMessage += `<b>User:</b> ${chatSession.userName}\n`;
  threadMessage += `<b>User ID:</b> <code>${chatSession.userId}</code>\n`;
  threadMessage += `<b>Status:</b> ${chatSession.status === 'active' ? '🟢 Active' : '🟡 Pending'}\n`;
  if (chatSession.adminName) {
    threadMessage += `<b>Admin:</b> ${chatSession.adminName}\n`;
  }
  threadMessage += `<b>Dibuat:</b> ${new Date(chatSession.createdAt).toLocaleString('id-ID')}\n\n`;
  
  threadMessage += `<b>📋 RIWAYAT PESAN:</b>\n\n`;
  
  if (chatSession.messages.length === 0) {
    threadMessage += `<i>Belum ada pesan</i>\n`;
  } else {
    chatSession.messages.forEach((msg, index) => {
      const time = new Date(msg.timestamp).toLocaleTimeString('id-ID', { 
        hour: '2-digit', 
        minute: '2-digit' 
      });
      threadMessage += `<b>${index + 1}. ${msg.name} (${msg.sender === 'user' ? '👤 User' : '👨‍💼 Admin'}):</b>\n`;
      threadMessage += `${msg.message}\n`;
      threadMessage += `<i>${time}</i>\n\n`;
    });
  }
  
  const keyboard = [];
  
  if (chatSession.status === 'pending' || (chatSession.adminId === user.id.toString())) {
    keyboard.push([
      { 
        text: chatSession.adminId ? '💬 Lanjut Balas' : '💬 Ambil & Balas', 
        callback_data: `cs_start_reply_${chatThreadId}` 
      }
    ]);
  }
  
  keyboard.push([
    { 
      text: '📋 Copy Thread ID', 
      callback_data: `cs_copy_thread_${chatThreadId}` 
    },
    { 
      text: '🔄 Refresh', 
      callback_data: `cs_view_thread_${chatThreadId}` 
    }
  ]);
  
  if (chatSession.adminId === user.id.toString() || owner_ids.includes(user.id.toString())) {
    keyboard.push([
      { 
        text: '❌ Tutup Thread', 
        callback_data: `cs_close_thread_admin_${chatThreadId}` 
      }
    ]);
  }
  
  keyboard.push([
    { text: '🔙 Kembali', callback_data: 'owner_cs_menu' }
  ]);
  
  await editMessage(chatId, messageId, callbackQueryId, threadMessage, {
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: keyboard },
    disable_web_page_preview: true
  });
  
  return;
}

if (data.startsWith('cs_reply_thread_')) {
  const chatThreadId = data.replace('cs_reply_thread_', '');
  
  const chatSession = global.csChatSessions?.get(chatThreadId);
  if (!chatSession) {
    await bot.answerCallbackQuery(callbackQueryId, {
      text: '❌ Thread chat tidak ditemukan',
      show_alert: true
    });
    return;
  }
  
  // Cek apakah admin ini yang menangani
  if (chatSession.adminId !== user.id.toString()) {
    await bot.answerCallbackQuery(callbackQueryId, {
      text: '❌ Hanya admin yang menangani bisa membalas',
      show_alert: true
    });
    return;
  }
  
  // Set user selection untuk admin
  const adminSelection = {
    step: 'cs_admin_reply',
    csThreadId: chatThreadId,
    targetUserId: chatSession.user.id,
    targetUserName: chatSession.userName,
    timestamp: Date.now()
  };
  userSelections.set(user.id, adminSelection);
  
  await editMessage(chatId, messageId, callbackQueryId,
    `<b>💬 BALAS PESAN USER</b>\n\n` +
    `<b>Thread ID:</b> <code>${chatThreadId}</code>\n` +
    `<b>User:</b> ${chatSession.userName}\n\n` +
    `<b>Kirim balasan Anda:</b>\n` +
    `<i>Ketik pesan yang ingin dikirim ke user</i>`,
    {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [{ text: '👁️ Lihat Thread', callback_data: `cs_view_thread_${chatThreadId}` }],
          [{ text: '❌ Batalkan', callback_data: `cs_cancel_reply_${chatThreadId}` }]
        ]
      }
    }
  );
  
  return;
}

if (data.startsWith('cs_copy_thread_')) {
  const chatThreadId = data.replace('cs_copy_thread_', '');
  
  await bot.answerCallbackQuery(callbackQueryId, {
    text: `Thread ID: ${chatThreadId}\n\nCopied to clipboard!`,
    show_alert: true
  });
  
  return;
}

if (data.startsWith('cs_cancel_reply_')) {
  const chatThreadId = data.replace('cs_cancel_reply_', '');
  
  // Hapus selection admin
  userSelections.delete(user.id);
  
  await editMessage(chatId, messageId, callbackQueryId,
    `<b>❌ BALASAN DIBATALKAN</b>\n\n` +
    `Thread ID: <code>${chatThreadId}</code>\n\n` +
    `Anda membatalkan balasan.`,
    {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [{ text: '👁️ Lihat Thread', callback_data: `cs_view_thread_${chatThreadId}` }],
          [{ text: '🔙 CS Menu', callback_data: 'owner_cs_menu' }]
        ]
      }
    }
  );
  
  return;
}

if (data.startsWith('cs_close_chat_')) {
  const chatThreadId = data.replace('cs_close_chat_', '');
  
  // User menutup chat dari sisi mereka
  const chatSession = global.csChatSessions?.get(chatThreadId);
  if (chatSession) {
    chatSession.status = 'closed';
    global.csChatSessions.set(chatThreadId, chatSession);
  }
  
  // Hapus selection user
  userSelections.delete(user.id);
  
  await editMessage(chatId, messageId, callbackQueryId,
    `<b>✅ CHAT DITUTUP</b>\n\n` +
    `Thread ID: <code>${chatThreadId}</code>\n\n` +
    `Chat dengan CS Admin telah ditutup.\n` +
    `Terima kasih telah menghubungi kami.`,
    {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [{ text: '🏠 Menu Utama', callback_data: 'main_menu' }]
        ]
      }
    }
  );
  
  return;
}
    
if (data === 'reset_database_confirm') {
  await editMessage(chatId, messageId, callbackQueryId,
    `<b>⚠️ KONFIRMASI RESET DATABASE</b>\n\n` +
    `<b>PERINGATAN:</b>\n` +
    `• Semua data user akan dihapus\n` +
    `• Semua saldo akan direset ke 0\n` +
    `• Semua riwayat transaksi dihapus\n` +
    `• Semua voucher dihapus\n` +
    `• Backup otomatis akan dibuat\n` +
    `• Proses TIDAK BISA DIBATALKAN\n\n` +
    `Yakin ingin mereset database?`,
    {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [
            { text: '✅ Ya, Reset Sekarang', callback_data: 'reset_database_execute' },
            { text: '❌ Batalkan', callback_data: 'owner_database_menu' }
          ]
        ]
      }
    }
  );
  return;
}
    
    if (data === 'reset_database_execute') {
  await resetDatabase(chatId, user.id, messageId, callbackQueryId);
  return;
}
    
    // Tambahkan di callback handler
if (data === 'add_admin') {
  const selection = {
    step: 'add_admin_input',
    timestamp: Date.now()
  };
  userSelections.set(user.id, selection);
  
  await editMessage(chatId, messageId, callbackQueryId,
    `<b>➕ ADD ADMIN</b>\n\n` +
    `Kirim User ID yang ingin dijadikan admin:\n\n` +
    `Contoh: <code>123456789</code>\n\n` +
    `<i>User ID harus berupa angka</i>`,
    {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [{ text: '🔙 Admin Menu', callback_data: 'owner_admin_menu' }]
        ]
      }
    }
  );
  return;
}

if (data === 'remove_admin') {
  const selection = {
    step: 'remove_admin_input',
    timestamp: Date.now()
  };
  userSelections.set(user.id, selection);
  
  await editMessage(chatId, messageId, callbackQueryId,
    `<b>➖ REMOVE ADMIN</b>\n\n` +
    `Kirim User ID admin yang ingin dihapus:\n\n` +
    `Contoh: <code>123456789</code>\n\n` +
    `<i>User ID harus berupa angka</i>`,
    {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [{ text: '🔙 Admin Menu', callback_data: 'owner_admin_menu' }]
        ]
      }
    }
  );
  return;
}

// Owner Settings Callback Handlers
if (data === 'owner_settings') {
  await showOwnerSettings(chatId, user.id, messageId, callbackQueryId);
  return;
}

if (data === 'owner_user_details') {
  await showUserDetailsMenu(chatId, user.id, messageId, callbackQueryId);
  return;
}

if (data === 'search_user_by_id') {
  await searchUserByID(chatId, user.id, messageId, callbackQueryId);
  return;
}

if (data.startsWith('user_detail_')) {
  const targetUserId = data.replace('user_detail_', '');
  await showUserDetails(user.id, targetUserId, chatId, messageId, callbackQueryId);
  return;
}

if (data === 'owner_user_balance') {
  await showUserBalanceManagement(chatId, user.id, messageId, callbackQueryId);
  return;
}

if (data === 'owner_user_history') {
  await showUserHistoryMenu(chatId, user.id, messageId, callbackQueryId);
  return;
}

if (data === 'owner_ban_management') {
  await showBanManagement(chatId, user.id, messageId, callbackQueryId);
  return;
}

if (data === 'owner_list_users') {
  await showListUsers(chatId, user.id, messageId, callbackQueryId);
  return;
}

if (data.startsWith('list_users_page_')) {
  const page = parseInt(data.replace('list_users_page_', ''));
  await showListUsers(chatId, user.id, messageId, callbackQueryId, page);
  return;
}

if (data === 'owner_database_menu') {
  await showDatabaseMenu(chatId, user.id, messageId, callbackQueryId);
  return;
}

if (data === 'owner_admin_menu') {
  await showAdminMenu(chatId, user.id, messageId, callbackQueryId);
  return;
}

if (data === 'owner_cs_menu') {
  await showCSMenu(chatId, user.id, messageId, callbackQueryId);
  return;
}

// User balance actions
if (data.startsWith('add_balance_')) {
  const targetUserId = data.replace('add_balance_', '');
  const selection = {
    step: 'add_balance',
    targetUserId: targetUserId,
    timestamp: Date.now()
  };
  userSelections.set(userId, selection);
  
  await editMessage(chatId, messageId, callbackQueryId,
    `<b>➕ TAMBAH SALDO USER</b>\n\n` +
    `User ID: <code>${targetUserId}</code>\n\n` +
    `Kirim jumlah saldo yang ingin ditambahkan:\n` +
    `Contoh: <code>10000</code> untuk Rp 10.000\n\n` +
    `<i>Minimal: Rp 1.000</i>`,
    {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [{ text: '🔙 Kembali', callback_data: `user_detail_${targetUserId}` }]
        ]
      }
    }
  );
  return;
}

if (data.startsWith('deduct_balance_')) {
  const targetUserId = data.replace('deduct_balance_', '');
  const selection = {
    step: 'deduct_balance',
    targetUserId: targetUserId,
    timestamp: Date.now()
  };
  userSelections.set(userId, selection);
  
  await editMessage(chatId, messageId, callbackQueryId,
    `<b>➖ KURANGI SALDO USER</b>\n\n` +
    `User ID: <code>${targetUserId}</code>\n\n` +
    `Kirim jumlah saldo yang ingin dikurangi:\n` +
    `Contoh: <code>5000</code> untuk Rp 5.000\n\n` +
    `<i>Maksimal: Saldo user saat ini</i>`,
    {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [{ text: '🔙 Kembali', callback_data: `user_detail_${targetUserId}` }]
        ]
      }
    }
  );
  return;
}

// Ban/Unban actions
if (data.startsWith('ban_user_')) {
  const targetUserId = data.replace('ban_user_', '');
  const selection = {
    step: 'ban_user',
    targetUserId: targetUserId,
    timestamp: Date.now()
  };
  userSelections.set(userId, selection);
  
  await editMessage(chatId, messageId, callbackQueryId,
    `<b>🚫 BAN USER</b>\n\n` +
    `User ID: <code>${targetUserId}</code>\n\n` +
    `Kirim alasan pemblokiran:\n` +
    `Contoh: <code>Melanggar rules</code>\n\n` +
    `<i>Kosongkan untuk tanpa alasan</i>`,
    {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [
            { text: '✅ Confirm Ban', callback_data: `confirm_ban_${targetUserId}` },
            { text: '❌ Cancel', callback_data: `user_detail_${targetUserId}` }
          ]
        ]
      }
    }
  );
  return;
}

if (data.startsWith('confirm_ban_')) {
  const targetUserId = data.replace('confirm_ban_', '');
  const selection = userSelections.get(userId);
  
  if (selection && selection.step === 'ban_user' && selection.targetUserId === targetUserId) {
    const reason = selection.reason || 'No reason provided';
    const success = banUser(targetUserId, reason, userId.toString());
    
    if (success) {
      await editMessage(chatId, messageId, callbackQueryId,
        `<b>✅ USER BANNED</b>\n\n` +
        `User ID: <code>${targetUserId}</code>\n` +
        `Reason: ${reason}\n` +
        `Banned by: ${user.first_name}\n` +
        `Time: ${new Date().toLocaleString('id-ID')}\n\n` +
        `<i>User telah diblokir dari bot</i>`,
        {
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [{ text: '🔙 User Details', callback_data: `user_detail_${targetUserId}` }]
            ]
          }
        }
      );
    }
  }
  return;
}
  
  if (data === 'owner_voucher_menu') {
    await showVoucherOwnerMenu(chatId, user.id, messageId, callbackQueryId);
    return;
  }
  
  if (data === 'voucher_create') {
    await showCreateVoucherStep1(chatId, user.id, messageId, callbackQueryId);
    return;
  }
  
  if (data === 'voucher_list') {
    await showVoucherList(chatId, user.id, messageId, callbackQueryId);
    return;
  }
  
  if (data === 'voucher_stats_detail') {
    await showVoucherStatsDetail(chatId, user.id, messageId, callbackQueryId);
    return;
  }
  
  if (data.startsWith('voucher_list_page_')) {
    const page = parseInt(data.replace('voucher_list_page_', ''));
    await showVoucherList(chatId, user.id, messageId, callbackQueryId, page);
    return;
  }
  
  if (data.startsWith('voucher_detail_')) {
    const voucherId = data.replace('voucher_detail_', '');
    await showVoucherDetail(chatId, user.id, voucherId, messageId, callbackQueryId);
    return;
  }
  
  if (data.startsWith('voucher_delete_')) {
    const voucherId = data.replace('voucher_delete_', '');
    await confirmDeleteVoucher(chatId, user.id, voucherId, messageId, callbackQueryId);
    return;
  }
  
  if (data.startsWith('voucher_delete_confirm_')) {
    const voucherId = data.replace('voucher_delete_confirm_', '');
    await deleteVoucher(chatId, user.id, voucherId, messageId, callbackQueryId);
    return;
  }
  
  if (data === 'create_voucher_type_percentage') {
    userSelections.set(user.id, {
        step: 'create_voucher',
        voucherData: { type: 'percentage' }
    });
    await showCreateVoucherStep2(chatId, user.id, messageId, callbackQueryId);
    return;
  }
  
  if (data === 'create_voucher_type_fixed') {
    userSelections.set(user.id, {
        step: 'create_voucher',
        voucherData: { type: 'fixed' }
    });
    await showCreateVoucherStep2(chatId, user.id, messageId, callbackQueryId);
    return;
  }
  
  if (data === 'create_voucher_nomin') {
    const selection = userSelections.get(user.id);
    if (selection && selection.voucherData) {
        selection.voucherData.min_purchase = 0;
        selection.voucherData.max_discount = null;
        selection.step = 'awaiting_voucher_limit';
        userSelections.set(user.id, selection);
        await showCreateVoucherStep4(chatId, user.id, messageId, callbackQueryId);
    }
    return;
  }
  
  if (data === 'create_voucher_custom_min') {
    const selection = userSelections.get(user.id);
    if (selection && selection.voucherData) {
        selection.step = 'awaiting_voucher_minmax';
        userSelections.set(user.id, selection);
        await sendNewMessage(chatId, 
            'Masukkan minimum pembelian dan maksimal discount:\n\nFormat: <code>min_purchase max_discount</code>\nContoh: <code>10000 5000</code>\n\nKetik "skip" untuk tanpa minimum',
            { parse_mode: 'HTML' }
        );
    }
    return;
  }
  
  if (data === 'create_voucher_back_step3') {
    const selection = userSelections.get(user.id);
    if (selection && selection.voucherData) {
        selection.step = 'awaiting_voucher_value';
        userSelections.set(user.id, selection);
        await showCreateVoucherStep2(chatId, user.id, messageId, callbackQueryId);
    }
    return;
  }
  
  if (data.startsWith('create_voucher_limit_')) {
    const limit = parseInt(data.replace('create_voucher_limit_', ''));
    const selection = userSelections.get(user.id);
    if (selection && selection.voucherData) {
        selection.voucherData.usage_limit = limit;
        selection.step = 'awaiting_voucher_final';
        userSelections.set(user.id, selection);
        await showCreateVoucherStep5(chatId, user.id, messageId, callbackQueryId);
    }
    return;
  }
  
  if (data.startsWith('create_voucher_expiry_')) {
    const days = parseInt(data.replace('create_voucher_expiry_', ''));
    const selection = userSelections.get(user.id);
    if (selection && selection.voucherData) {
        const expiryDate = new Date();
        expiryDate.setDate(expiryDate.getDate() + days);
        expiryDate.setHours(23, 59, 59, 0);
        selection.voucherData.expiry = expiryDate.toISOString();
        selection.step = 'awaiting_voucher_final';
        userSelections.set(user.id, selection);
        await showCreateVoucherStep5(chatId, user.id, messageId, callbackQueryId);
    }
    return;
  }
  
  if (data === 'create_voucher_back_step4') {
    const selection = userSelections.get(user.id);
    if (selection && selection.voucherData) {
        selection.step = 'awaiting_voucher_limit';
        userSelections.set(user.id, selection);
        await showCreateVoucherStep4(chatId, user.id, messageId, callbackQueryId);
    }
    return;
  }
  
  if (data === 'create_voucher_random_code') {
    const selection = userSelections.get(user.id);
    if (selection && selection.voucherData) {
        selection.voucherData.code = generateVoucherCode();
        selection.step = 'awaiting_voucher_final';
        userSelections.set(user.id, selection);
        await sendNewMessage(chatId,
            `Kode voucher: <code>${selection.voucherData.code}</code>\n\nMasukkan deskripsi (opsional):\n\nContoh: <code>Diskon spesial untuk member</code>\n\nKetik "skip" untuk tanpa deskripsi`,
            { parse_mode: 'HTML' }
        );
    }
    return;
  }
  
  if (data === 'create_voucher_custom_code') {
    const selection = userSelections.get(user.id);
    if (selection && selection.voucherData) {
        selection.step = 'awaiting_voucher_final';
        userSelections.set(user.id, selection);
        await sendNewMessage(chatId,
            'Masukkan kode voucher dan deskripsi:\n\nFormat: <code>KODE deskripsi</code>\nContoh: <code>DISKON50 Diskon 50% spesial</code>\n\nKetik "skip skip" untuk random code tanpa deskripsi',
            { parse_mode: 'HTML' }
        );
    }
    return;
  }
  
  if (data === 'create_voucher_finalize') {
    const selection = userSelections.get(user.id);
    if (selection && selection.voucherData) {
        if (!selection.voucherData.code) {
            selection.voucherData.code = generateVoucherCode();
        }
        await finalizeVoucherCreation(chatId, user.id, messageId, callbackQueryId);
    }
    return;
  }
  
  if (data === 'create_voucher_add_desc') {
    const selection = userSelections.get(user.id);
    if (selection && selection.voucherData) {
        if (!selection.voucherData.code) {
            selection.voucherData.code = generateVoucherCode();
        }
        selection.step = 'awaiting_voucher_final';
        userSelections.set(user.id, selection);
        await sendNewMessage(chatId,
            'Masukkan deskripsi voucher (opsional):\n\nContoh: <code>Diskon spesial untuk member baru</code>\n\nKetik "skip" untuk tanpa deskripsi',
            { parse_mode: 'HTML' }
        );
    }
    return;
  }
  
  // User voucher handlers
  if (data.startsWith('apply_voucher_')) {
    const parts = data.replace('apply_voucher_', '').split('_');
    const operatorId = parts[0];
    const providerId = parts[1];
    const price = parts[2];
    
    await showVoucherInput(chatId, user.id, operatorId, providerId, price, messageId, callbackQueryId);
    return;
  }
  
  if (data.startsWith('change_voucher_')) {
    const parts = data.replace('change_voucher_', '').split('_');
    const operatorId = parts[0];
    const providerId = parts[1];
    const price = parts[2];
    
    const userSelection = userSelections.get(user.id);
    if (userSelection) {
        delete userSelection.appliedVoucher;
        userSelections.set(user.id, userSelection);
    }
    
    await showVoucherInput(chatId, user.id, operatorId, providerId, price, messageId, callbackQueryId);
    return;
  }
  
 /* if (data.startsWith('remove_voucher_')) {
    const parts = data.replace('remove_voucher_', '').split('_');
    const operatorId = parts[0];
    const providerId = parts[1];
    const price = parts[2];
    
    const userSelection = userSelections.get(user.id);
    if (userSelection) {
        delete userSelection.appliedVoucher;
        userSelections.set(userId, userSelection);
    }
    
    await showOrderConfirmation(chatId, user.id, operatorId, providerId, price, messageId, callbackQueryId);
    return;
  }*/
  
  if (data.startsWith('remove_voucher_')) {
    const parts = data.split('_');
    if (parts.length >= 5) {
        const operatorId = parts[2];
        const providerId = parts[3];
        const price = parts[4];
        await showOrderConfirmation(chatId, userId, operatorId, providerId, price, messageId, callbackQueryId);
    }
}
  
  // ========================= BACKUP CALLBACK HANDLERS =========================
  
  if (data === 'restore_menu') {
    await showBackupList(chatId, user.id, messageId, callbackQueryId);
    return;
  }
  
  if (data.startsWith('restore_view_')) {
    const backupFileName = data.replace('restore_view_', '');
    await showBackupDetail(chatId, user.id, backupFileName, messageId, callbackQueryId);
    return;
  }
  
  if (data.startsWith('restore_confirm_')) {
    const backupFileName = data.replace('restore_confirm_', '');
    await confirmRestore(chatId, user.id, backupFileName, messageId, callbackQueryId);
    return;
  }
  
  if (data.startsWith('restore_execute_')) {
    const backupFileName = data.replace('restore_execute_', '');
    await bot.deleteMessage(chatId, messageId).catch(() => {});
    await executeRestore(chatId, user.id, backupFileName);
    return;
  }
  
  if (data.startsWith('restore_download_')) {
    const backupFileName = data.replace('restore_download_', '');
    await downloadBackup(chatId, user.id, backupFileName, messageId, callbackQueryId);
    return;
  }
  
  if (data.startsWith('restore_delete_')) {
    const backupFileName = data.replace('restore_delete_', '');
    await deleteBackup(chatId, user.id, backupFileName, messageId, callbackQueryId);
    return;
  }
  
  if (data.startsWith('delete_execute_')) {
    const backupFileName = data.replace('delete_execute_', '');
    await executeDeleteBackup(chatId, user.id, backupFileName, messageId, callbackQueryId);
    return;
  }
  
  if (data.startsWith('create_backup_now')) {
    await createBackupNow(chatId, user.id, messageId, callbackQueryId);
    return;
  }
  
  if (data === 'restore_reload') {
    await reloadDataAfterRestore(chatId, user.id, messageId, callbackQueryId);
    return;
  }
  
  // ========================= MAIN MENU CALLBACK HANDLERS =========================
    
    if (data === 'main_menu') {
      await showMainMenu(chatId, user.id, user, messageId, callbackQueryId);
      return;
    }
    
    if (data === 'owner_menu') {
    await showOwnerMenu(chatId, user.id, messageId, callbackQueryId);
      return;
    }
    
    if (data === 'owner_stats') {
        const simulatedMsg = {
            ...msg,
            text: '/stats',
            from: user,
            chat: { id: chatId }
        };
        bot.emit('text', simulatedMsg);
        return;
    }
    
    if (data === 'nokos_menu') {
      await showNokosMenu(chatId, user.id, messageId, callbackQueryId, 0);
      return;
    }
    
    if (data === 'nokos_other_services') {
      await showOtherServices(chatId, user.id, messageId, callbackQueryId);
      return;
    }
    
    if (data.startsWith('nokos_service_')) {
      const serviceId = data.replace('nokos_service_', '');
      const servicesData = await getServicesCached(); 
      if (servicesData && servicesData.success) {
        const service = servicesData.data.find(s => s.service_code == serviceId);
        if (service) {
          await showCountryMenu(chatId, user.id, serviceId, service.service_name, messageId, callbackQueryId);
        }
      }
      return;
    }

    if (data === 'setpay_rumahotp') {
      if (!owner_ids.includes(userId.toString())) {
        return bot.answerCallbackQuery(callbackQueryId, {
          text: 'Hanya owner yang bisa setting',
          show_alert: true
        });
      }
      setPaymentMethod('rumahotp');
      await editMessage(chatId, messageId, callbackQueryId,
        `Metode pembayaran berhasil diubah.

Status saat ini:
Rumah OTP: Aktif
Cashify: Nonaktif

Detail sistem:
Provider: Rumah OTP
Tipe: QRIS
Auto Confirm: Ya
Biaya: Gratis

Pengubah: ${user.first_name}
Waktu: ${new Date().toLocaleTimeString('id-ID')}`,
        { 
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [
                { text: 'RUMAH OTP', callback_data: 'setpay_rumahotp' },
                { text: 'CASHIFY', callback_data: 'setpay_cashify' }
              ],
              [
                { text: 'Refresh Status', callback_data: 'setpay_refresh' }
              ]
            ]
          }
        }
      );
      return;
    }

    if (data === 'setpay_cashify') {
      if (!owner_ids.includes(user.id.toString())) {
        return bot.answerCallbackQuery(callbackQueryId, {
          text: 'Hanya owner yang bisa setting',
          show_alert: true
        });
      }
      setPaymentMethod('cashify');
      await editMessage(chatId, messageId, callbackQueryId,
        `Metode pembayaran berhasil diubah.

Status saat ini:
Rumah OTP: Nonaktif
Cashify: Aktif

Detail sistem:
Provider: Cashify.my.id
Tipe: QRIS Dynamic
E-Wallet: DANA
Auto Confirm: Ya
Biaya: Sesuai unique code

Pengubah: ${user.first_name}
Waktu: ${new Date().toLocaleTimeString('id-ID')}`,
        { 
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [
                { text: 'RUMAH OTP', callback_data: 'setpay_rumahotp' },
                { text: 'CASHIFY', callback_data: 'setpay_cashify' }
              ],
              [
                { text: 'Refresh Status', callback_data: 'setpay_refresh' }
              ]
            ]
          }
        }
      );
      return;
    }

    if (data === 'setpay_refresh') {
      if (!owner_ids.includes(user.id.toString())) {
        return bot.answerCallbackQuery(callbackQueryId, {
          text: 'Hanya owner yang bisa setting',
          show_alert: true
        });
      }
      const currentMethod = getPaymentMethod();
      const isRumahOTP = currentMethod === 'rumahotp';
      const isCashify = currentMethod === 'cashify';
      
      await editMessage(chatId, messageId, callbackQueryId,
        `Setting metode pembayaran.

Status system:
Rumah OTP: ${isRumahOTP ? 'Aktif' : 'Nonaktif'}
Cashify: ${isCashify ? 'Aktif' : 'Nonaktif'}

Informasi:
Semua deposit menggunakan metode ini
QRIS otomatis menyesuaikan
User tidak perlu pilih manual

Pilih metode yang ingin digunakan:`,
        { 
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [
                { 
                  text: isRumahOTP ? 'RUMAH OTP' : 'RUMAH OTP', 
                  callback_data: 'setpay_rumahotp' 
                },
                { 
                  text: isCashify ? 'CASHIFY' : 'CASHIFY', 
                  callback_data: 'setpay_cashify' 
                }
              ]
            ]
          }
        }
      );
      return;
    }

    if (data.startsWith('nokos_country_page_')) {
      const parts = data.replace('nokos_country_page_', '').split('_');
      const serviceId = parts[0];
      const page = parseInt(parts[1]);
      const servicesData = await getServicesCached();
      if (servicesData && servicesData.success) {
        const service = servicesData.data.find(s => s.service_code == serviceId);
        if (service) {
          await showCountryMenu(chatId, user.id, serviceId, service.service_name, messageId, callbackQueryId, page);
        }
      }
      return;
    }
    
    if (data.startsWith('nokos_server_list_')) {
      try {
        const parts = data.replace('nokos_server_list_', '').split('_');
        if (parts.length < 2) {
            throw new Error('Format data server tidak valid');
        }
        const numberId = parts[0];
        const countryName = decodeURIComponent(parts.slice(1).join('_'));
        await showServerList(chatId, user.id, numberId, countryName, messageId, callbackQueryId);
        return;
      } catch (error) {
        bot.answerCallbackQuery(callbackQueryId, {
            text: 'Error memproses pilihan server',
            show_alert: true
        }).catch(() => {});
        return;
      }
    }
    
    if (data.startsWith('nokos_server_')) {
    try {
        const parts = data.replace('nokos_server_', '').split('_');
        if (parts.length < 3) {
            throw new Error('Format data server tidak valid');
        }
        const providerId = parts[0];
        const price = parts[1];
        const rate = parts[2];
        
        const userSelection = userSelections.get(user.id) || {};
        userSelection.providerId = providerId;
        userSelection.price = price;
        userSelection.rate = rate;
        userSelections.set(user.id, userSelection);
        
        console.log(`Server selected: providerId=${providerId}, price=${price}, rate=${rate}`);
        
        await showOperatorMenu(chatId, user.id, userSelection.numberId, price, userSelection.countryName, messageId, callbackQueryId);
        return;
    } catch (error) {
        console.error('Error in nokos_server callback:', error);
        bot.answerCallbackQuery(callbackQueryId, {
            text: 'Error memilih server',
            show_alert: true
        }).catch(() => {});
        return;
    }
}
    
    if (data.startsWith('nokos_operator_')) {
    try {
        const parts = data.replace('nokos_operator_', '').split('_');
        
        // Pastikan ada cukup bagian
        if (parts.length < 3) {
            throw new Error('Format data operator tidak valid');
        }
        
        const operatorId = parts[0];
        const providerId = parts[1];
        const price = parts[2];
        
        // Debug logging
        console.log(`Operator clicked: operatorId=${operatorId}, providerId=${providerId}, price=${price}`);
        
        await showOrderConfirmation(chatId, user.id, operatorId, providerId, price, messageId, callbackQueryId);
        return;
    } catch (error) {
        console.error('Error in nokos_operator callback:', error);
        bot.answerCallbackQuery(callbackQueryId, {
            text: '❌ Error memproses operator',
            show_alert: true
        }).catch(() => {});
        return;
    }
}
    
   if (data.startsWith('nokos_confirm_')) {
    const parts = data.replace('nokos_confirm_', '').split('_');
    const numberId = parts[0];
    const providerId = parts[1];
    const operatorId = parts[2];
    const price = parts[3];
    
    // Panggil fungsi dengan parameter yang benar
    await processNokosOrder(chatId, user.id, numberId, providerId, operatorId, price, messageId, callbackQueryId, data);
    return;
}
    
    if (data.startsWith('server_prev_')) {
      const parts = data.replace('server_prev_', '').split('_');
      const numberId = parts[0];
      const countryName = decodeURIComponent(parts.slice(1, parts.length - 1).join('_'));
      const startIndex = parseInt(parts[parts.length - 1]);
      await showServerListEnhanced(chatId, user.id, numberId, countryName, messageId, callbackQueryId, startIndex);
      return;
    }
    
    if (data.startsWith('server_next_')) {
      const parts = data.replace('server_next_', '').split('_');
      const numberId = parts[0];
      const countryName = decodeURIComponent(parts.slice(1, parts.length - 1).join('_'));
      const startIndex = parseInt(parts[parts.length - 1]);
      await showServerListEnhanced(chatId, user.id, numberId, countryName, messageId, callbackQueryId, startIndex);
      return;
    }
    
    if (data.startsWith('nokos_check_')) {
      const orderId = data.replace('nokos_check_', '');
      await checkOTP(chatId, orderId, messageId, callbackQueryId);
      return;
    }
    
    if (data === 'deposit_main') {
      await showDepositMenu(chatId, user.id, messageId, callbackQueryId);
      return;
    }
    
    if (data === 'order_history') {
      await showOrderHistory(chatId, user.id, messageId, callbackQueryId);
      return;
    }
    
    if (data === 'deposit_history') {
      await showDepositHistory(chatId, user.id, messageId, callbackQueryId);
      return;
    }
    
    if (data.startsWith('deposit_status_')) {
      const depositId = data.replace('deposit_status_', '');
      await editMessage(chatId, messageId, callbackQueryId,
        'Memeriksa status deposit...',
        { parse_mode: 'HTML' }
      );
      checkDepositStatus(chatId, depositId, user.id, messageId);
      return;
    }
    
    if (data.startsWith('wait_cancel_')) {
    const orderId = data.replace('wait_cancel_', '');
    const transactions = loadTransactions();
    const order = transactions.nokos_orders?.find(o => 
        o.id === orderId || o.data?.orderId === orderId
    );
    
    if (!order) {
        await bot.answerCallbackQuery(callbackQueryId, {
            text: 'Order tidak ditemukan',
            show_alert: true
        });
        return;
    }
    
    const orderTime = new Date(order.timestamp).getTime();
    const now = Date.now();
    const threeMinutes = 3 * 60 * 1000;
    const timeLeft = threeMinutes - (now - orderTime);
    
    if (timeLeft <= 0) {
        await bot.answerCallbackQuery(callbackQueryId, {
            text: '✅ Sekarang bisa membatalkan order',
            show_alert: true
        });

        await editMessage(chatId, messageId, callbackQueryId,
            `Order ID: <code>#${orderId}</code>\n\n✅ Order sudah bisa dibatalkan.\nKlik tombol "Batal Order" untuk membatalkan.`,
            {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { 
                                text: 'Cek OTP', 
                                callback_data: `nokos_check_${orderId}` 
                            }
                        ],
                        [
                            { 
                                text: 'Order Baru', 
                                callback_data: 'nokos_menu' 
                            },
                            { 
                                text: 'Menu Utama', 
                                callback_data: 'main_menu' 
                            }
                        ]
                    ]
                }
            }
        );
    } else {
        const minutesLeft = Math.floor(timeLeft / 60000);
        const secondsLeft = Math.floor((timeLeft % 60000) / 1000);
        
        let timeText = '';
        if (minutesLeft > 0) {
            timeText = `${minutesLeft}m ${secondsLeft}s`;
        } else {
            timeText = `${secondsLeft}s`;
        }
        
        let buttonText = '';
        if (minutesLeft > 0) {
            buttonText = `${minutesLeft}m`;
        } else if (secondsLeft > 0) {
            buttonText = `${secondsLeft}s`;
        } else {
            buttonText = '0s';
        }
        
        await bot.answerCallbackQuery(callbackQueryId, {
            text: `⏳ Tunggu ${timeText} sebelum bisa membatalkan`,
            show_alert: true
        });
        
        await editMessage(chatId, messageId, callbackQueryId,
            `Order ID: <code>#${orderId}</code>\n\n⏳ Tunggu ${timeText} sebelum bisa membatalkan order.\n\nOrder masih dalam proses aktivasi nomor.`,
            {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { 
                                text: 'Cek OTP', 
                                callback_data: `nokos_check_${orderId}` 
                            },
                            { 
                                text: buttonText, 
                                callback_data: `wait_cancel_${orderId}` 
                            }
                        ],
                        [
                            { 
                                text: 'Order Baru', 
                                callback_data: 'nokos_menu' 
                            },
                            { 
                                text: 'Menu Utama', 
                                callback_data: 'main_menu' 
                            }
                        ]
                    ]
                }
            }
        );
    }
    return;
    }

    if (data.startsWith('deposit_cancel_')) {
  const depositId = data.replace('deposit_cancel_', '');
  bot.deleteMessage(chatId, messageId).catch(() => {});
  const loadingMsg = await sendNewMessage(chatId,
    'Membatalkan deposit...',
    { parse_mode: 'HTML' }
  );
  
  const paymentMethod = getPaymentMethod();
  let cancelResult;
  
  if (paymentMethod === 'cashify') {
    cancelResult = await cashifyService.cancelDeposit(depositId);
  } else {
    cancelResult = await api.cancelRumahOTPDeposit(depositId);
  }
  
  const isCashify = paymentMethod === 'cashify';
  const successCheck = isCashify ? 
    cancelResult?.success : 
    cancelResult?.success;
  
  if (successCheck) {
    const transactionType = isCashify ? 'cashify_deposits' : 'rumahotp_deposits';
    updateTransactionStatus(transactionType, depositId, 'cancelled');
    
    await editMessage(chatId, loadingMsg.message_id, null,
      `Deposit berhasil dibatalkan
      
ID Deposit: <code>${depositId}</code>
Status: Dibatalkan
Waktu: ${new Date().toLocaleTimeString('id-ID')}`,
      { 
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: 'Deposit Lagi', callback_data: 'deposit_main' }],
            [{ text: 'Menu Utama', callback_data: 'main_menu' }]
          ]
        }
      }
    );
  } else {
    const errorMsg = cancelResult?.message || 
                    cancelResult?.error?.message || 
                    cancelResult?.error || 
                    'Gagal membatalkan deposit';
    
    await editMessage(chatId, loadingMsg.message_id, null,
      `Gagal membatalkan deposit
      
Pesan Error: ${errorMsg}
ID Deposit: <code>${depositId}</code>`,
      { 
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: 'Coba Lagi', callback_data: 'deposit_main' }],
            [{ text: 'Menu Utama', callback_data: 'main_menu' }]
          ]
        }
      }
    );
  }
  return;
}
    
    if (data === 'refresh_maintenance') {
      const userId = userId.toString();
      const maintenance = getMaintenanceInfo();
      if (maintenance.active && !owner_ids.includes(userId)) {
        await bot.answerCallbackQuery(callbackQueryId, {
          text: 'Bot masih dalam maintenance',
          show_alert: true
        });
        return;
      }
      
      balanceCache.delete(userId);
      
      await bot.deleteMessage(chatId, messageId).catch(() => {});
      saveUser(userId);
      await showMainMenu(chatId, user.id, user, null, callbackQueryId);
      return;
    }
    
    if (data.startsWith('deposit_amount_')) {
      const amount = data.replace('deposit_amount_', '');
      userSelections.delete(user.id);
      bot.deleteMessage(chatId, messageId).catch(() => {});
      await handleRumahOTPDeposit(chatId, user.id, parseInt(amount));
      return;
    }
    
    if (data === 'deposit_custom') {
      await editMessage(chatId, messageId, callbackQueryId,
        `Deposit Custom

Kirim jumlah deposit dalam angka:
Minimal: Rp2.000
Maksimal: Rp5.000.000

Contoh: <code>25000</code>
Format: Angka saja (tanpa titik/koma)`,
        { 
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [{ text: 'Kembali', callback_data: 'deposit_main' }]
            ]
          }
        }
      );
      userSelections.set(user.id, { step: 'rumahotp_deposit_amount' });
      return;
    }
    
    bot.answerCallbackQuery(callbackQueryId, { 
      text: 'Tombol tidak dikenali', 
      show_alert: false 
    }).catch(() => {});
    
  } catch (error) {
    try {
      await sendNewMessage(chatId,
        `Terjadi kesalahan sistem.

Pesan Error: ${error.message || 'Unknown error'}
Waktu: ${new Date().toLocaleTimeString('id-ID')}

Silakan coba lagi atau hubungi admin`,
        { 
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [{ text: 'Coba Lagi', callback_data: 'main_menu' }]
            ]
          }
        }
      );
    } catch (e) {}
  }
});

bot.on("callback_query", async (query) => {
  const userId = query.from.id.toString();
  const chatId = query.message.chat.id;

  if (query.data === "check_join_again") {
    await bot.answerCallbackQuery(query.id, {
      text: "Memeriksa kembali...",
      show_alert: false
    });

    const isMember = await checkChannelMembership(userId);

    if (isMember) {
      await bot.deleteMessage(chatId, query.message.message_id).catch(() => {});
      
      await sendNewMessage(chatId, 
`<b>✅ Akses Terverifikasi</b>

<i>Informasi Verifikasi</i>
├ Status : ✅ Terverifikasi
└ Akses  : 🎊 Teridentifikasi

🔓 <b>Selamat menggunakan bot sekarang Anda sudah bisa</b>`,
        { parse_mode: 'HTML' }
      );

      const pendingCommand = userPendingCommands.get(userId);
      if (pendingCommand) {
        const simulatedMsg = {
          ...query.message,
          text: pendingCommand,
          from: query.from,
          chat: { id: chatId }
        };

        if (pendingCommand === "/start") {
          await bot.emit("text", simulatedMsg);
        } else {
          setTimeout(() => {
            bot.emit("text", simulatedMsg);
          }, 500);
        }

        userPendingCommands.delete(userId);
      } else {
        setTimeout(() => {
          bot.emit("text", {
            ...query.message,
            text: "/start",
            from: query.from,
            chat: { id: chatId }
          });
        }, 500);
      }

    } else {
      await editMessage(chatId, query.message.message_id, query.id,
`<b>❌ Tidak Termasuk Member</b>

<i>Informasi Verifikasi</i>
├ Status : ⛔ Tidak termasuk member
└ Akses  : ⛔ Terblokir

🔒 <b>Perlu Pengecekan</b>
└─ Silahkan join channel untuk mengakses fitur bot

🔰 <i>Tunggu terlebih dahulu sampai terverifikasi</i>`,
        {
          reply_markup: {
            inline_keyboard: [
              [{ 
                text: "➕ Join Channel", 
                url: `https://t.me/${channel.replace('@','')}` 
              }],
              [{ 
                text: "🔄 Verifikasi Ulang", 
                callback_data: "check_join_again" 
              }]
            ]
          },
          parse_mode: 'HTML'
        }
      );
    }
  }
});

// ========================= SERVICES CACHE =========================

// Perluas servicesCache untuk menyimpan lebih banyak data
const servicesCache = {
  data: null,
  timestamp: 0,
  ttl: 2 * 60 * 1000, // 2 menit
  loading: false,
  // Tambahkan untuk menyimpan data lain
  countries: new Map(), // Map<serviceId, {data, timestamp}>
  servers: new Map(), // Map<numberId, {data, timestamp}>
  filtered: new Map() // Untuk hasil filter
};

// Fungsi untuk membersihkan cache lama
function cleanupServicesCache() {
    const now = Date.now();
    const maxAge = 10 * 60 * 1000; // 10 menit
    
    // Clean services cache
    if (servicesCache.data && (now - servicesCache.timestamp > servicesCache.ttl)) {
        servicesCache.data = null;
    }
    
    // Clean countries cache
    for (const [key, value] of servicesCache.countries.entries()) {
        if (now - value.timestamp > maxAge) {
            servicesCache.countries.delete(key);
        }
    }
    
    // Clean servers cache
    for (const [key, value] of servicesCache.servers.entries()) {
        if (now - value.timestamp > maxAge) {
            servicesCache.servers.delete(key);
        }
    }
}

// Jalankan cleanup setiap 5 menit
setInterval(cleanupServicesCache, 5 * 60 * 1000);

async function getServicesCached(forceRefresh = false) {
    const now = Date.now();
    
    if (!forceRefresh && servicesCache.data && (now - servicesCache.timestamp < servicesCache.ttl)) {
        return servicesCache.data;
    }
    
    if (servicesCache.loading) {
        let waitCount = 0;
        while (servicesCache.loading && waitCount < 50) {
            await new Promise(resolve => setTimeout(resolve, 100));
            waitCount++;
        }
        return servicesCache.data || { success: false, data: [] };
    }
    
    servicesCache.loading = true;
    
    try {
        let servicesData;
        
        if (config.active_provider === 'otpnum') {
            // Get countries first to get Indonesia ID
            const countriesResult = await otpnumService.getCountries();
            if (countriesResult && countriesResult.success) {
                const countries = countriesResult.data.countries || [];
                const indonesia = countries.find(c => 
                    c.name.toLowerCase().includes('indonesia') || c.id === 6
                );
                
                if (indonesia) {
                    // Get services for Indonesia
                    const servicesResult = await otpnumService.getServices(indonesia.id);
                    if (servicesResult && servicesResult.success) {
                        servicesData = {
                            success: true,
                            data: servicesResult.data.services || []
                        };
                    }
                }
            }
        } else {
            // Use RumahOTP API
            servicesData = await api.getServices();
        }
        
        if (servicesData && servicesData.success) {
            servicesCache.data = servicesData;
            servicesCache.timestamp = now;
        }
        return servicesData;
    } catch (error) {
        console.error('Error fetching services:', error);
        return servicesCache.data || { success: false, data: [] };
    } finally {
        servicesCache.loading = false;
    }
}

async function preloadAllData() {
  try {
    await getServicesCached();
    
    const balances = loadBalances();
    Object.entries(balances).forEach(([userId, balance]) => {
      balanceCache.set(userId, parseInt(balance) || 0);
    });
    
    loadTransactions();
    loadVouchers();
  } catch (error) {}
}

preloadAllData();

// ========================= NOTIFICATION FUNCTIONS =========================

async function notifyOrderSuccess(user, orderData, price, hasOTP = false) {
    try {
        const orderId = orderData.order_id;
        const notificationKey = `order_${orderId}_${hasOTP ? 'otp' : 'pending'}`;
        
        if (sentNotifications.has(notificationKey)) {
            return;
        }
        
        const transactions = loadTransactions();
        const order = transactions.nokos_orders?.find(o => 
            o.id === orderId || o.data?.orderId === orderId
        );
        
        let voucherInfo = '';
        if (order && order.data && order.data.voucher_code) {
            voucherInfo = `\n<b>Voucher:</b> ${order.data.voucher_code}`;
            if (order.data.discount && order.data.discount > 0) {
                voucherInfo += ` (Diskon: ${formatCurrency(order.data.discount)})`;
            }
        }
        
        const userId = user.id;
        const firstName = user.first_name || 'User';
        const username = user.username ? `@${user.username}` : 'Tidak ada username';
        const maskedPhone = maskPhoneNumber(orderData.phone_number);     
        const formattedPrice = formatCurrency(price);

        if (!hasOTP || !orderData.otp_code || orderData.otp_code === '-') {
            const ownerMessage = `Order baru - Menunggu OTP${voucherInfo}

User:
Nama: ${firstName}
Username: ${username}
ID: ${userId}

Order:
ID: #${orderData.order_id}
Nomor: ${maskedPhone}
Layanan: ${orderData.service}
Negara: ${orderData.country}
Operator: ${orderData.operator || '-'}
Harga: ${formattedPrice}
Status: Menunggu OTP

Waktu: ${new Date().toLocaleString('id-ID')}`;

           await bot.sendMessage(channel_otp, ownerMessage, {
                parse_mode: 'HTML',
                disable_web_page_preview: true,
            });
            
            sentNotifications.set(notificationKey, Date.now());
            return;
        } else {
            const otpCode = orderData.otp_code;
            const formattedOTP = otpCode.length === 6 ? `${otpCode.substring(0, 3)}-${otpCode.substring(3)}` : otpCode;
            
            // GUNAKAN FUNGSI BARU UNTUK MENGIRIM OTP DENGAN AUTO-DELETE
            await sendOTPToChannelWithAutoDelete(orderData, user, price, formattedOTP, voucherInfo);
            
            // Tetap kirim notifikasi ke channel_otp (untuk admin)
            /*await bot.sendMessage(channel_otp, `✅ OTP DITERIMA: ${orderData.order_id} - ${formattedOTP}`, {
                parse_mode: 'HTML',
                disable_web_page_preview: true
            });*/
            
            sentNotifications.set(notificationKey, Date.now());
        }
    } catch (error) {
        console.error('Notify Order Error:', error);
    }
}

async function notifyDepositSuccess(user, amount, depositId, newBalance) {
    try {
        const notificationKey = `deposit_${depositId}`;
        
        if (sentNotifications.has(notificationKey)) {
            return;
        }
        
        const userId = user.id;
        const firstName = user.first_name || 'User';
        const username = user.username ? `@${user.username}` : 'Tidak ada username';
        const dateStr = new Date().toLocaleString('id-ID', { 
            day: 'numeric', 
            month: 'short', 
            year: 'numeric', 
            hour: '2-digit', 
            minute: '2-digit' 
        });
        
        const channelMessage = `<blockquote>💰 DEPOSIT BERHASIL
━━━━━━━━━━━━━━━━━

<b>ID:</b> ${depositId}
<b>Users:</b> ${firstName}
<b>Nominal:</b> ${formatCurrency(amount)}
<b>Method:</b> QRIS 
<b>Tanggal:</b> ${dateStr}</blockquote>`;
        
        const keyboard = {
            inline_keyboard: [
                [
                    { 
                        text: '🛒 Orders', 
                        url: 'https://t.me/andinnstorebot'
                    },
                    { 
                        text: '💬 Support', 
                        url: `https://t.me/${channel.replace('@','')}`
                    }
                ]
            ]
        };
        
        await bot.sendMessage(channel, channelMessage, {
            parse_mode: 'HTML',
            disable_web_page_preview: true,
            reply_markup: keyboard
        });
        
        sentNotifications.set(notificationKey, Date.now());
        
    } catch (error) {}
}

setInterval(() => {
    const now = Date.now();
    const oneHour = 60 * 60 * 1000;
    
    for (const [key, timestamp] of sentNotifications.entries()) {
        if (now - timestamp > oneHour) {
            sentNotifications.delete(key);
        }
    }

    for (const [key, timestamp] of orderProcessing.entries()) {
        if (now - timestamp > 5 * 60 * 1000) { 
            orderProcessing.delete(key);
        }
    }
}, 60 * 60 * 1000);

async function notifyOwnerDepositCreated(depositData, userId, amount, paymentMethod) {
    try {
        const user = await bot.getChat(userId);
        const dateStr = new Date().toLocaleString('id-ID', { 
            day: 'numeric', 
            month: 'short', 
            year: 'numeric', 
            hour: '2-digit', 
            minute: '2-digit' 
        });
        
        const message = `DEPOSIT PENDING

<b>Users:</b> ${user.first_name}
<b>Username:</b> ${user.username ? '@' + user.username : 'Tidak ada'}
<b>ID:</b> ${user.id}

<b>Deposit:</b>
ID: #${depositData.id || depositData.no_inv}
Jumlah: ${formatCurrency(amount)}
Metode: QRIS
Fee: ${formatCurrency(depositData.fee || 0)}
Diterima: ${formatCurrency(depositData.diterima || amount)}

<b>Status:</b> Menunggu pembayaran
<b>Batas waktu:</b> 20 menit
<b>Tanggal:</b> ${dateStr}`;

                await bot.sendMessage(channel_otp, message, { 
                    parse_mode: 'HTML',
                    disable_web_page_preview: true 
                });
    } catch (error) {}
}

/*function maskPhoneNumber(phoneNumber) {
    if (!phoneNumber) return '-';
    const cleanNumber = phoneNumber.replace(/\D/g, '');
    if (cleanNumber.length <= 4) return cleanNumber;
    const visibleDigits = Math.min(4, Math.floor(cleanNumber.length / 2));
    const firstPart = cleanNumber.substring(0, visibleDigits);
    const lastPart = cleanNumber.substring(cleanNumber.length - visibleDigits);
    return `${firstPart}****${lastPart}`;
}*/
function maskPhoneNumber(phoneNumber) {
    if (!phoneNumber) return '-';
    
    // Hapus semua karakter non-digit
    const cleanNumber = phoneNumber.replace(/\D/g, '');
    
    // Jika nomor kosong setelah dibersihkan, return '-'
    if (cleanNumber.length === 0) return '-';
    
    // Tambahkan prefix 62 dan bintang untuk sisa nomor
    const maskedPart = '*'.repeat(cleanNumber.length);
    return `62${maskedPart}`;
}

function loadUserNotifications() {
    try {
        const notificationsFile = path.join(dataDir, 'notified_users.json');
        if (!fs.existsSync(notificationsFile)) {
            return;
        }
        
        const data = JSON.parse(fs.readFileSync(notificationsFile, 'utf8'));
        data.users.forEach(userId => {
            userFirstTimeNotifications.add(userId);
        });
    } catch (error) {
        console.error('Error loading user notifications:', error);
    }
}

function saveUserNotifications() {
    try {
        const notificationsFile = path.join(dataDir, 'notified_users.json');
        const data = {
            users: Array.from(userFirstTimeNotifications),
            lastUpdated: new Date().toISOString()
        };
        fs.writeFileSync(notificationsFile, JSON.stringify(data, null, 2));
    } catch (error) {
        console.error('Error saving user notifications:', error);
    }
}

async function notifyNewUser(user, userBalance = 0) {
    try {
        const userId = user.id.toString();
        
        if (userFirstTimeNotifications.has(userId)) {
            return;
        }
        
        userFirstTimeNotifications.add(userId);
        
        const firstName = user.first_name || 'Tidak ada';
        const username = user.username ? `@${user.username}` : 'Tidak ada username';
        
        const message = `<b>📋 USER BARU MEMULAI BOT</b>

<b>Informasi User:</b>
├ User ID: <code>${userId}</code>
├ Username: ${username}
├ Nama: ${firstName}
└ Saldo Awal: ${formatCurrency(userBalance)}

<b>Waktu:</b> ${new Date().toLocaleString('id-ID')}

<i>Status: ✅ User baru terdaftar</i>`;
        
            try {
                await bot.sendMessage(channel, message, {
                    parse_mode: 'HTML',
                    disable_web_page_preview: true
                });
            } catch (error) {}
        
    } catch (error) {
        console.error('Error in notifyNewUser:', error);
    }
}

// ========================= COMMAND HANDLERS =========================

bot.onText(/\/start/, withRequireJoin(async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const user = msg.from;
  
  if (!(await checkMaintenance(msg))) {
    return;
  }
  
  const data = loadData();
  const userIdStr = String(userId);
  
  const saveResult = saveUser(userId);
  
  const userBalance = getUserBalance(userId);
  
  if (saveResult.isNewUser) {
    await notifyNewUser(user, userBalance);
  }
  
  balanceCache.delete(userIdStr);
  
  await showMainMenu(chatId, userId, user);
}));

bot.onText(/^\/broadcast$/, async (msg) => {
  try {
    const chatId = msg.chat.id;
    const senderId = msg.from.id.toString();
    const mainOwnerId = owner_ids[0];
    
    if (senderId !== mainOwnerId) {
      return await bot.sendMessage(chatId, 
        "Akses ditolak.\n\nHanya owner utama yang dapat menggunakan command ini.",
        { parse_mode: "HTML" }
      ).catch(() => {});
    }

    if (!msg.reply_to_message) {
      return await bot.sendMessage(chatId, 
        `Broadcast message.

Cara penggunaan:
1. Reply pesan yang ingin di broadcast
2. Ketik command /broadcast

Supported message:
Text, Photo, Document, Video

Pastikan pesan sudah benar sebelum dikirim`,
        { parse_mode: "HTML" }
      ).catch(() => {});
    }

    const data = loadData();
    const uniqueUsers = [...new Set(data.users || [])];
    const total = uniqueUsers.length;

    if (total === 0) {
      return await bot.sendMessage(chatId, "Tidak ada user yang terdaftar.", { parse_mode: "HTML" }).catch(() => {});
    }

    const processingMsg = await bot.sendMessage(chatId, 
      `Memulai broadcast.

Statistik:
Total user: ${total}
Status: Mengirim...
Progress: 0%

Mohon tunggu proses broadcast...`, 
      { parse_mode: "HTML" }
    );

    const reply = msg.reply_to_message;
    let sukses = 0, gagal = 0;
    const broadcastHeader = `📢 BROADCAST DARI ADMIN\n`;

    for (let i = 0; i < uniqueUsers.length; i++) {
      const userId = uniqueUsers[i];
      try {
        if (reply.text) {
          const messageWithHeader = `${broadcastHeader}${reply.text}`;
          await bot.sendMessage(userId, messageWithHeader, { 
            parse_mode: 'HTML',
            disable_web_page_preview: true
          }).catch(() => {
            bot.sendMessage(userId, `${broadcastHeader}${reply.text}`).catch(() => {});
          });
        } else if (reply.photo) {
          const fileId = reply.photo[reply.photo.length - 1].file_id;
          const captionWithHeader = reply.caption ? `${broadcastHeader}${reply.caption}` : broadcastHeader;
          await bot.sendPhoto(userId, fileId, { 
            caption: captionWithHeader,
            parse_mode: 'HTML'
          }).catch(() => {});
        } else if (reply.document) {
          const captionWithHeader = reply.caption ? `${broadcastHeader}${reply.caption}` : broadcastHeader;
          await bot.sendDocument(userId, reply.document.file_id, { 
            caption: captionWithHeader,
            parse_mode: 'HTML'
          }).catch(() => {});
        } else if (reply.video) {
          const captionWithHeader = reply.caption ? `${broadcastHeader}${reply.caption}` : broadcastHeader;
          await bot.sendVideo(userId, reply.video.file_id, { 
            caption: captionWithHeader,
            parse_mode: 'HTML'
          }).catch(() => {});
        } else {
          await bot.sendMessage(userId, `${broadcastHeader}Jenis pesan ini belum bisa di broadcast.`, {
            parse_mode: 'HTML'
          }).catch(() => {});
        }
        sukses++;
      } catch (err) {
        gagal++;
      }

      if (i % 10 === 0 || i === uniqueUsers.length - 1) {
        const progress = Math.round(((i + 1) / uniqueUsers.length) * 100);
        try {
          await bot.editMessageText(
            `Memulai broadcast.

Statistik:
Total user: ${total}
Status: Mengirim...
Progress: ${progress}%

Mohon tunggu proses broadcast...`,
            {
              chat_id: chatId,
              message_id: processingMsg.message_id,
              parse_mode: "HTML"
            }
          );
        } catch (editError) {}
      }

      await new Promise(r => setTimeout(r, 200));
    }

    try {
      await bot.editMessageText(
        `Broadcast selesai.

Hasil broadcast:
Total user: ${total}
Sukses: ${sukses}
Gagal: ${gagal}

Statistik:
Success rate: ${Math.round((sukses / total) * 100)}%`,
        {
          chat_id: chatId,
          message_id: processingMsg.message_id,
          parse_mode: "HTML"
        }
      );
    } catch (editError) {
      await bot.sendMessage(chatId,
        `Broadcast selesai.

Hasil broadcast:
Total user: ${total}
Sukses: ${sukses}
Gagal: ${gagal}

Statistik:
Success rate: ${Math.round((sukses / total) * 100)}%`,
        { parse_mode: 'HTML' }
      ).catch(() => {});
    }
  } catch (err) {
    await bot.sendMessage(msg.chat.id, "Terjadi error saat memproses broadcast.", { parse_mode: "HTML" }).catch(() => {});
  }
});

bot.onText(/^\/setpay$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  
  if (!owner_ids.includes(userId)) {
    return bot.sendMessage(chatId, 
      "Hanya owner yang bisa mengganti metode pembayaran",
      { parse_mode: 'HTML' }
    );
  }
  
  const currentMethod = getPaymentMethod();
  const isRumahOTP = currentMethod === 'rumahotp';
  const isCashify = currentMethod === 'cashify';   
  const message = `Setting metode pembayaran.

Status saat ini:
Rumah OTP: ${isRumahOTP ? 'Aktif' : 'Nonaktif'}
Cashify: ${isCashify ? 'Aktif' : 'Nonaktif'}

Informasi:
QRIS akan menyesuaikan metode
User tidak akan melihat perbedaan
Sistem otomatis

Klik tombol untuk mengganti:`;
  
  await bot.sendMessage(chatId, message, {
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [
          { 
            text: isRumahOTP ? 'RUMAH OTP' : 'RUMAH OTP', 
            callback_data: 'setpay_rumahotp' 
          },
          { 
            text: isCashify ? 'CASHIFY' : 'CASHIFY', 
            callback_data: 'setpay_cashify' 
          }
        ]
      ]
    }
  });
});

bot.onText(/^\/maintenance/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  
  if (!owner_ids.includes(userId)) {
    return bot.sendMessage(chatId, 
      "Hanya owner yang bisa menggunakan command ini",
      { parse_mode: 'HTML' }
    );
  }
  
  const text = msg.text || '';
  const args = text.trim().split(/\s+/);
  
  if (args.length === 1) {
    const maintenance = getMaintenanceInfo();
    const status = maintenance.active ? 'ON' : 'OFF';
    const reason = maintenance.reason ? `\n\nAlasan: ${maintenance.reason}` : '';
    
    return bot.sendMessage(chatId,
      `Status maintenance.

Status: ${status}${reason}

Format:
/maintenance on (reply pesan untuk alasan)
/maintenance off`,
      { parse_mode: 'HTML' }
    );
  }
  
  const command = args[1].toLowerCase();
  
  if (command === 'off') {
    setMaintenance(false);
    return bot.sendMessage(chatId,
      `Maintenance mode dimatikan.

Bot sekarang bisa digunakan oleh semua user.`,
      { parse_mode: 'HTML' }
    );
  }
  
  if (command === 'on') {
    if (!msg.reply_to_message) {
      return bot.sendMessage(chatId,
        `Reply pesan untuk alasan maintenance.

Contoh:
1. Ketik alasan maintenance (contoh: "Perbaikan server")
2. Reply pesan tersebut
3. Kirim /maintenance on`,
        { parse_mode: 'HTML' }
      );
    }
    
    const reason = msg.reply_to_message.text || 'Bot sedang dalam perbaikan';
    setMaintenance(true, reason);
    
    return bot.sendMessage(chatId,
      `Maintenance mode diaktifkan.

Alasan: ${reason}

Efek:
User biasa tidak bisa menggunakan bot
Owner masih bisa mengakses
User akan lihat pesan maintenance`,
      { parse_mode: 'HTML' }
    );
  }
  
  bot.sendMessage(chatId,
    "Format salah.\n\nGunakan: /maintenance on atau /maintenance off",
    { parse_mode: 'HTML' }
  );
});

bot.onText(/\/stats/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    
    if (!owner_ids.includes(userId.toString())) {
        await bot.sendMessage(chatId, 
            "Command ini hanya untuk owner!",
            { parse_mode: 'HTML' }
        );
        return;
    }
    
    const data = loadData();
    const balances = loadBalances();
    const transactions = loadTransactions();
    const vouchers = loadVouchers();
    
    const totalUsers = data.users?.length || 0;
    const totalOrders = transactions.nokos_orders?.length || 0;
    const cashifyDeposits = transactions.cashify_deposits?.length || 0; 
    const rumahotpDeposits = transactions.rumahotp_deposits?.length || 0;
    const totalDeposits = cashifyDeposits + rumahotpDeposits; 
    const totalVouchers = vouchers.voucher_stats.total_created || 0;
    const usedVouchers = vouchers.voucher_stats.total_used || 0;

    let totalBalance = 0;
    let usersWithBalance = 0;
    Object.values(balances).forEach(balance => {
        const amount = parseInt(balance) || 0;
        totalBalance += amount;
        if (amount > 0) usersWithBalance++;
    });
    
    let apiBalanceResult = '';
    try {
        const balanceResult = await api.getUserBalanceAPI();
        if (balanceResult && balanceResult.success) {
            const apiBalance = balanceResult.data?.balance || balanceResult.data?.saldo || 0;
            const apiCurrency = balanceResult.data?.currency || 'IDR';
            apiBalanceResult = `${formatCurrency(apiBalance)} (${apiCurrency})`;
        } else {
            apiBalanceResult = 'Gagal mengambil';
        }
    } catch (error) {
        apiBalanceResult = 'Gagal mengambil';
    }
    
    const message = `📊 <b>STATISTIK BOT</b>

<b>📱 User Statistics:</b>
├ Total users: ${totalUsers}
├ User dengan saldo: ${usersWithBalance}
└ User tanpa saldo: ${totalUsers - usersWithBalance}

<b>💰 Financial Statistics:</b>
├ Total saldo bot: ${formatCurrency(totalBalance)}
├ Saldo API: ${apiBalanceResult}
├ Total discount voucher: ${formatCurrency(vouchers.voucher_stats.total_discount || 0)}
├ Rata-rata saldo/user: ${formatCurrency(totalUsers > 0 ? Math.round(totalBalance / totalUsers) : 0)}
└ User terbanyak saldo: ${getTopUserBalance(balances)}

<b>🔄 Transaction Statistics:</b>
├ Total order: ${totalOrders}
├ Total deposit: ${totalDeposits}
├ └ Cashify: ${cashifyDeposits} 
├ └ Rumah OTP: ${rumahotpDeposits}
├ Total voucher: ${totalVouchers}
├ └ Digunakan: ${usedVouchers}
└ Success rate: ${totalOrders > 0 ? Math.round((totalOrders / (totalOrders + totalDeposits)) * 100) : 0}%

<b>📈 Today's Activity:</b>
${getTodayStats(transactions)}

<b>⏰ System:</b>
└ Update terakhir: ${new Date().toLocaleString('id-ID')}`;
    
    await bot.sendMessage(chatId, message, {
        parse_mode: 'HTML',
        disable_web_page_preview: true
    });
});

function getTopUserBalance(balances) {
    let topUserId = null;
    let topBalance = 0;
    
    Object.entries(balances).forEach(([userId, balance]) => {
        const amount = parseInt(balance) || 0;
        if (amount > topBalance) {
            topBalance = amount;
            topUserId = userId;
        }
    });
    
    return topUserId ? `${topUserId} (${formatCurrency(topBalance)})` : 'Tidak ada';
}

bot.onText(/^\/voucher/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    
    if (!owner_ids.includes(userId)) {
        return bot.sendMessage(chatId,
            "⛔ Akses Ditolak\n\nHanya owner yang bisa menggunakan command ini.",
            { parse_mode: 'HTML' }
        );
    }
    
    const text = msg.text || '';
    const args = text.trim().split(/\s+/);
    
    if (args.length === 1) {
        await showVoucherOwnerMenu(chatId, userId);
        return;
    }
    
    const subCommand = args[1].toLowerCase();
    
    if (subCommand === 'create') {
        await showCreateVoucherStep1(chatId, userId);
        return;
    }
    
    if (subCommand === 'list') {
        await showVoucherList(chatId, userId);
        return;
    }
    
    if (subCommand === 'stats') {
        await showVoucherStatsDetail(chatId, userId);
        return;
    }
    
    if (subCommand === 'quick') {
        if (args.length < 4) {
            return bot.sendMessage(chatId,
                `<b>❌ FORMAT SALAH</b>\n\n` +
                `Format: <code>/voucher quick [type] [value] [min] [max] [limit] [expiry] [code]</code>\n\n` +
                `Contoh: <code>/voucher quick percentage 10 10000 5000 10 31-12-2024 DISKON10</code>\n` +
                `Contoh: <code>/voucher quick fixed 5000 0 0 1 0 QUICK5K</code>`,
                { parse_mode: 'HTML' }
            );
        }
        
        const type = args[2]; // percentage or fixed
        const value = parseInt(args[3]);
        const minPurchase = parseInt(args[4]) || 0;
        const maxDiscount = args[5] !== '0' ? parseInt(args[5]) : null;
        const limit = parseInt(args[6]) || 1;
        let expiry = null;
        let code = args[8] || generateVoucherCode();
        
        if (args[7] && args[7] !== '0') {
            const dateParts = args[7].split('-');
            if (dateParts.length === 3) {
                const day = parseInt(dateParts[0]);
                const month = parseInt(dateParts[1]) - 1;
                const year = parseInt(dateParts[2]);
                
                if (!isNaN(day) && !isNaN(month) && !isNaN(year)) {
                    expiry = new Date(year, month, day, 23, 59, 59).toISOString();
                }
            }
        }
        
        const voucherData = {
            type: type,
            value: value,
            min_purchase: minPurchase,
            max_discount: maxDiscount,
            usage_limit: limit,
            expiry: expiry,
            code: code,
            created_by: userId
        };
        
        const voucher = createVoucher(voucherData);
        
        if (voucher) {
            await bot.sendMessage(chatId,
                `<b>✅ VOUCHER BERHASIL DIBUAT</b>\n\n` +
                `<b>Kode:</b> <code>${voucher.code}</code>\n` +
                `<b>Tipe:</b> ${voucher.type === 'percentage' ? 'Persentase' : 'Fixed Amount'}\n` +
                `<b>Nilai:</b> ${voucher.type === 'percentage' ? `${voucher.value}%` : formatCurrency(voucher.value)}\n` +
                `<b>Status:</b> ✅ Aktif`,
                { parse_mode: 'HTML' }
            );
        }
        return;
    }
});

bot.onText(/^\/restore(\s|$)/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  
  if (!owner_ids.includes(userId)) {
    return bot.sendMessage(chatId,
      "⛔ Akses Ditolak\n\nHanya owner yang bisa menggunakan command ini.",
      { parse_mode: 'HTML' }
    );
  }
  
  const text = msg.text || '';
  const args = text.trim().split(/\s+/);
  
  if (args.length === 1) {
    await showBackupList(chatId, userId);
    return;
  }
  
  const backupFileName = args[1];
  
  if (!backupFileName || !backupFileName.startsWith('backup_') || !backupFileName.endsWith('.zip')) {
    return bot.sendMessage(chatId,
      `<b>❌ NAMA FILE TIDAK VALID</b>\n\n` +
      `Format nama file backup harus:\n` +
      `<code>backup_YYYY-MM-DD_HH-MM-SS.zip</code>\n\n` +
      `Gunakan <code>/restore</code> untuk melihat daftar backup yang tersedia.`,
      { parse_mode: 'HTML' }
    );
  }
  
  await executeRestore(chatId, userId, backupFileName);
});

bot.onText(/^\/deletebackup(\s|$)/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  
  if (!owner_ids.includes(userId)) {
    return bot.sendMessage(chatId,
      "⛔ Akses Ditolak\n\nHanya owner yang bisa menggunakan command ini.",
      { parse_mode: 'HTML' }
    );
  }
  
  const text = msg.text || '';
  const args = text.trim().split(/\s+/);
  
  if (args.length < 2) {
    return bot.sendMessage(chatId,
      `<b>❌ FORMAT SALAH</b>\n\n` +
      `Format: <code>/deletebackup [nama_file]</code>\n` +
      `Contoh: <code>/deletebackup backup_2024-01-15_10-30-00.zip</code>\n\n` +
      `Gunakan <code>/restore</code> untuk melihat daftar backup.`,
      { parse_mode: 'HTML' }
    );
  }
  
  const backupFileName = args[1];
  const backupDir = path.join(__dirname, 'backup');
  const backupPath = path.join(backupDir, backupFileName);
  
  if (!fs.existsSync(backupPath)) {
    return bot.sendMessage(chatId,
      `<b>❌ FILE TIDAK DITEMUKAN</b>\n\n` +
      `File backup tidak ditemukan:\n` +
      `<code>${backupFileName}</code>\n\n` +
      `Pastikan file ada di directory:\n` +
      `<code>${backupDir}</code>`,
      { parse_mode: 'HTML' }
    );
  }
  
  const stats = fs.statSync(backupPath);
  const fileSize = (stats.size / 1024).toFixed(2);
  
  try {
    fs.unlinkSync(backupPath);
    
    await bot.sendMessage(chatId,
      `<b>✅ FILE TERHAPUS</b>\n\n` +
      `<b>File:</b> <code>${backupFileName}</code>\n` +
      `<b>Ukuran:</b> ${fileSize} KB\n` +
      `<b>Waktu:</b> ${new Date().toLocaleString('id-ID')}\n\n` +
      `<i>File backup telah dihapus permanen</i>`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: '📁 Lihat Backup Lain', callback_data: 'restore_menu' }]
          ]
        }
      }
    );
    
  } catch (error) {
    await bot.sendMessage(chatId,
      `<b>❌ GAGAL MENGHAPUS</b>\n\n` +
      `Terjadi kesalahan:\n\n` +
      `<code>${error.message}</code>`,
      { parse_mode: 'HTML' }
    );
  }
});

function getTodayStats(transactions) {
    const today = new Date().toISOString().split('T')[0];
    let todayOrders = 0;
    let todayDeposits = 0;
    let todayDepositAmount = 0;
    
    if (transactions.nokos_orders) {
        todayOrders = transactions.nokos_orders.filter(order => {
            const orderDate = new Date(order.timestamp).toISOString().split('T')[0];
            return orderDate === today;
        }).length;
    }
    
    ['cashify_deposits', 'rumahotp_deposits'].forEach(type => { 
        if (transactions[type]) {
            const todayDepositsData = transactions[type].filter(deposit => {
                const depositDate = new Date(deposit.timestamp).toISOString().split('T')[0];
                return depositDate === today;
            });
            
            todayDeposits += todayDepositsData.length;
            todayDepositsData.forEach(deposit => {
                todayDepositAmount += parseInt(deposit.data?.amount || deposit.data?.total || 0);
            });
        }
    });
    
    return `├ Order hari ini: ${todayOrders}\n├ Deposit hari ini: ${todayDeposits}\n└ Total deposit hari ini: ${formatCurrency(todayDepositAmount)}`;
}

async function addBalanceAdmin(chatId, adminId, commandText) {
    try {
        const parts = commandText.split(' ');
        if (parts.length < 3) {
            await bot.sendMessage(chatId,
                `Format salah.

Format: /addsaldo [user_id] [jumlah]
Contoh: /addsaldo 123456789 20000

Catatan:
User ID harus berupa angka
Jumlah minimal Rp 1.000`,
                { parse_mode: 'HTML' }
            );
            return;
        }

        const targetUserId = parts[1];
        const amount = parseInt(parts[2]);
        const userIdValidation = validateUserId(targetUserId);
        if (!userIdValidation.valid) {
            await bot.sendMessage(chatId,
                `User ID tidak valid: ${userIdValidation.error}

User ID yang dimasukkan: ${targetUserId}`,
                { parse_mode: 'HTML' }
            );
            return;
        }

        const amountValidation = validateAmount(amount);
        if (!amountValidation.valid || amountValidation.amount < 1000) {
            await bot.sendMessage(chatId,
                `Jumlah tidak valid: ${amountValidation.error || 'Minimal Rp 1.000'}

Jumlah yang dimasukkan: ${formatCurrency(amount)}`,
                { parse_mode: 'HTML' }
            );
            return;
        }

        const numAmount = amountValidation.amount;

        if (numAmount > 5000000) {
            await bot.sendMessage(chatId,
                `Jumlah terlalu besar.

Maksimal penambahan saldo: Rp 5,000,000
Jumlah yang dimasukkan: ${formatCurrency(numAmount)}`,
                { parse_mode: 'HTML' }
            );
            return;
        }

        const data = loadData();
        if (!data.users) data.users = [];
        
        const userExists = data.users.some(id => id === targetUserId);
        if (!userExists) {
            data.users.push(targetUserId);
            saveData(data);
        }
        
        balanceCache.delete(targetUserId);
        
        const oldBalance = getUserBalance(targetUserId);
        const success = addUserBalance(targetUserId, numAmount);
        const newBalance = getUserBalance(targetUserId);

        if (!success) {
            await bot.sendMessage(chatId,
                `Gagal menambah saldo.

Terjadi kesalahan sistem saat menambah saldo
User ID: ${targetUserId}
Jumlah: ${formatCurrency(numAmount)}`,
                { parse_mode: 'HTML' }
            );
            return;
        }

        await bot.sendMessage(chatId,
            `Saldo berhasil ditambahkan.

Detail transaksi:
User ID: ${targetUserId}
Jumlah: ${formatCurrency(numAmount)}
Saldo lama: ${formatCurrency(oldBalance)}
Saldo baru: ${formatCurrency(newBalance)}
Admin: ${adminId}

Notifikasi telah dikirim ke user`,
            { parse_mode: 'HTML' }
        );

        try {
            const user = await bot.getChat(targetUserId);
            await bot.sendMessage(targetUserId,
                `Saldo Anda telah ditambahkan.

Detail penambahan:
Jumlah: ${formatCurrency(numAmount)}
Saldo lama: ${formatCurrency(oldBalance)}
Saldo baru: ${formatCurrency(newBalance)}

Saldo telah berhasil ditambahkan oleh Admin
Terima kasih telah menggunakan layanan kami!`,
                { parse_mode: 'HTML' }
            );
        } catch {
            await bot.sendMessage(chatId,
                `Peringatan.

Saldo berhasil ditambahkan ke user ID: ${targetUserId}
Namun tidak dapat mengirim notifikasi ke user (mungkin belum pernah start bot)`,
                { parse_mode: 'HTML' }
            );
        }

    } catch (error) {
        await bot.sendMessage(chatId,
            `Terjadi kesalahan.

Gagal memproses perintah /addsaldo
Silakan coba lagi atau hubungi developer`,
            { parse_mode: 'HTML' }
        );
    }
}

bot.onText(/^\/addsaldo(\s|$)/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    
    if (!owner_ids.includes(userId)) {
        await bot.sendMessage(chatId,
            `Akses ditolak.

Command ini hanya untuk Admin
Silakan hubungi Admin untuk bantuan`,
            { parse_mode: 'HTML' }
        );
        return;
    }
    
    await addBalanceAdmin(chatId, userId, msg.text);
});

// ========================= AUTO BACKUP =========================

async function autoBackupTransactions(eventType, data = {}) {
    try {
        const now = new Date();
        const dateStr = now.toISOString().split('T')[0];
        const timeStr = now.getHours().toString().padStart(2, '0') + '-' + 
                       now.getMinutes().toString().padStart(2, '0') + '-' +
                       now.getSeconds().toString().padStart(2, '0');
        
        const backupDir = path.join(__dirname, 'backup');
        if (!fs.existsSync(backupDir)) {
            fs.mkdirSync(backupDir, { recursive: true });
        }
        
        const backupFiles = [
            { name: 'balances.json', file: balanceFile },
            { name: 'users.json', file: datafile },
            { name: 'transactions.json', file: transactionsFile },
            { name: 'settings.json', file: settingsFile },
            { name: 'vouchers.json', file: vouchersFile }
        ];
        
        const backupFileName = `backup_${dateStr}_${timeStr}.zip`;
        const backupPath = path.join(backupDir, backupFileName);
        
        const output = fs.createWriteStream(backupPath);
        const archive = archiver('zip', {
            zlib: { level: 9 }
        });
        
        output.on('close', async () => {
            const eventMessages = {
                'deposit_success': 'Deposit sukses',
                'deposit_pending': 'Deposit pending',
                'order_success': 'Order sukses',
                'order_cancelled': 'Order dibatalkan',
                'order_expired': 'Order expired',
                'balance_added': 'Saldo ditambahkan',
                'balance_deducted': 'Saldo dikurangi',
                'voucher_created': 'Voucher dibuat',
                'voucher_used': 'Voucher digunakan'
            };
            
        const eventMessage = eventMessages[eventType] || 'Event sistem';
        const fileSize = (archive.pointer() / 1024).toFixed(2);
            
            for (const ownerId of owner_ids) {
                try {
                    await bot.sendDocument(ownerId, backupPath, {
                        caption: `📁 Backup Database\n\nEvent: ${eventMessage}\nFile: ${backupFileName}\nSize: ${fileSize} KB\nWaktu: ${now.toLocaleString('id-ID')}`,
                        parse_mode: 'HTML'
                    });
                } catch (error) {}
            }
            
            const maxBackups = 10;
            const files = fs.readdirSync(backupDir)
                .filter(f => f.startsWith('backup_') && f.endsWith('.zip'))
                .sort((a, b) => {
                    const aPath = path.join(backupDir, a);
                    const bPath = path.join(backupDir, b);
                    return fs.statSync(bPath).mtime.getTime() - fs.statSync(aPath).mtime.getTime();
                });
            
            if (files.length > maxBackups) {
                for (let i = maxBackups; i < files.length; i++) {
                    fs.unlinkSync(path.join(backupDir, files[i]));
                }
            }
        });
        
        archive.on('error', (err) => {
        });
        
        archive.pipe(output);
        
        for (const file of backupFiles) {
            if (fs.existsSync(file.file)) {
                archive.file(file.file, { name: file.name });
            }
        }
        
        await archive.finalize();
        
    } catch (error) {}
}

setInterval(() => {
    autoBackupTransactions('auto_backup', {});
}, 7200000);

// ========================= PRICE MONITORING =========================

setInterval(monitorSpecificPrices, 15 * 60 * 1000); 
setInterval(monitorStockLevels, 30 * 60 * 1000);
scheduleDailySummary();

async function monitorSpecificPrices() {
  try {
    if (isCheckingPrices) return;
    isCheckingPrices = true;
    
    const servicesData = await getServicesCached();
    
    if (!servicesData || !servicesData.success) {
      isCheckingPrices = false;
      return;
    }

    const services = servicesData.data;
    const targetServices = [];
    
    for (const service of services) {
      const serviceName = service.service_name.toLowerCase();
      
      if (serviceName.includes('whatsapp') || serviceName.includes('telegram')) {
        targetServices.push(service);
      }
      
      if (targetServices.length >= 2) break;
    }
    
    for (const service of targetServices) {
      await checkServiceIndonesia(service);
      await new Promise(resolve => setTimeout(resolve, 5000));
    }
    
    isCheckingPrices = false;
  } catch (error) {
    isCheckingPrices = false;
  }
}

async function checkServiceIndonesia(service) {
  try {
    const countriesData = await api.getCountries(service.service_code);
    
    if (!countriesData || !countriesData.success) {
      return;
    }

    const countries = countriesData.data || [];
    
    for (const country of countries) {
      const countryName = country.name.toLowerCase();
      
      if (!countryName.includes('indonesia') && !countryName.includes('indo')) {
        continue;
      }
      
      if (!country.pricelist || country.pricelist.length === 0) {
        continue;
      }

      const cacheKey = `${service.service_code}_${country.number_id}`;
      const currentPrices = country.pricelist.map(server => ({
        provider_id: server.provider_id,
        price: server.price,
        rate: server.rate,
        stock: server.stock
      }));

      const previousPrices = priceCache.get(cacheKey);
      
      priceCache.set(cacheKey, currentPrices);
      
      if (previousPrices) {
        const changes = detectPriceChanges(previousPrices, currentPrices, service, country);
        if (changes.length > 0) {
          await notifyPriceChanges(changes, service, country);
        }
      } else {
        priceCache.set(cacheKey, currentPrices);
      }
    }
    
  } catch (error) {}
}

function detectPriceChanges(oldPrices, newPrices, service, country) {
  const changes = [];
  const notificationKey = `${service.service_code}_${country.number_id}`;
  const lastNotified = lastNotificationTime.get(notificationKey) || 0;
  const now = Date.now();
  
  if (now - lastNotified < 60 * 60 * 1000) {
    return changes;
  }

  for (let i = 0; i < Math.min(oldPrices.length, newPrices.length); i++) {
    const oldPrice = oldPrices[i];
    const newPrice = newPrices[i];
    
    if (oldPrice && newPrice && oldPrice.price !== newPrice.price) {
      const changeAmount = Math.abs(newPrice.price - oldPrice.price);
      const minChange = 500;
      
      if (changeAmount >= minChange) {
        const changePercent = ((newPrice.price - oldPrice.price) / oldPrice.price * 100).toFixed(1);
        
        changes.push({
          service: service.service_name,
          country: country.name,
          server: i + 1,
          oldPrice: oldPrice.price,
          newPrice: newPrice.price,
          change: parseInt(newPrice.price) - parseInt(oldPrice.price),
          changePercent: changePercent,
          rate: newPrice.rate,
          stock: newPrice.stock
        });
      }
    }
  }
  
  if (changes.length > 0) {
    lastNotificationTime.set(notificationKey, now);
  }
  
  return changes;
}

async function notifyPriceChanges(changes, service, country) {
  try {
    if (changes.length === 0) return;
    
    const priceDownChanges = changes.filter(c => c.change < 0);
    const priceUpChanges = changes.filter(c => c.change > 0);
    
    if (priceDownChanges.length === 0 && priceUpChanges.length === 0) return;
    
    let message = ``;
    
    if (priceDownChanges.length > 0) {
      message += `🟢 <b>HARGA TURUN!</b>\n\n`;
    } else if (priceUpChanges.length > 0) {
      message += `🔴 <b>HARGA NAIK!</b>\n\n`;
    }
    
    message += `<b>${service.service_name} - ${country.name}</b>\n\n`;
    
    if (priceDownChanges.length > 0) {
      message += `<b>💰 HARGA TURUN:</b>\n`;
      priceDownChanges.forEach(change => {
        const discount = Math.abs(change.change);
        message += `• Server ${change.server}: Rp${change.oldPrice.toLocaleString('id-ID')} → <b>Rp${change.newPrice.toLocaleString('id-ID')}</b>\n`;
        message += `  🔻 Turun Rp${discount.toLocaleString('id-ID')} (${Math.abs(change.changePercent)}%)\n`;
        message += `  📊 Rate: ${change.rate}% | 📦 Stok: ${change.stock}\n\n`;
      });
    }
    
    if (priceUpChanges.length > 0) {
      message += `<b>📈 HARGA NAIK:</b>\n`;
      priceUpChanges.forEach(change => {
        const increase = Math.abs(change.change);
        message += `• Server ${change.server}: Rp${change.oldPrice.toLocaleString('id-ID')} → <b>Rp${change.newPrice.toLocaleString('id-ID')}</b>\n`;
        message += `  🔺 Naik Rp${increase.toLocaleString('id-ID')} (${Math.abs(change.changePercent)}%)\n`;
        message += `  📊 Rate: ${change.rate}% | 📦 Stok: ${change.stock}\n\n`;
      });
    }
    
    message += `<i>Update: ${new Date().toLocaleString('id-ID')}</i>`;
    
    await bot.sendMessage(channel, message, {
      parse_mode: 'HTML',
      disable_web_page_preview: true
    });
    
    savePriceChangeHistory({
      service: service.service_name,
      country: country.name,
      changes: changes,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {}
}

function savePriceChangeHistory(data) {
  try {
    const historyFile = path.join(dataDir, 'price_history.json');
    let history = [];
    
    if (fs.existsSync(historyFile)) {
      history = JSON.parse(fs.readFileSync(historyFile, 'utf8'));
    }
    
    history.unshift(data);
    
    if (history.length > 50) {
      history = history.slice(0, 50);
    }
    
    fs.writeFileSync(historyFile, JSON.stringify(history, null, 2));
  } catch (error) {}
}

async function monitorStockLevels() {
  try {
    const servicesData = await getServicesCached();
    
    if (!servicesData || !servicesData.success) {
      return;
    }

    const services = servicesData.data;
    
    for (const service of services) {
      const serviceName = service.service_name.toLowerCase();
      
      if (!serviceName.includes('whatsapp') && !serviceName.includes('telegram')) {
        continue;
      }
      
      const countriesData = await api.getCountries(service.service_code);
      
      if (!countriesData || !countriesData.success) {
        continue;
      }

      const countries = countriesData.data || [];
      
      for (const country of countries) {
        const countryName = country.name.toLowerCase();
        
        if (!countryName.includes('indonesia') && !countryName.includes('indo')) {
          continue;
        }
        
        if (!country.pricelist) continue;
        
        if (country.stock_total < 5) {
          await notifyLowStock(service, country);
        }
      }
    }
    
  } catch (error) {}
}

async function notifyLowStock(service, country) {
  try {
    const cacheKey = `lowstock_${service.service_code}_${country.number_id}`;
    const lastNotified = lastNotificationTime.get(cacheKey) || 0;
    const now = Date.now();
    
    if (now - lastNotified < 4 * 60 * 60 * 1000) {
      return;
    }
    
    const message = `⚠️ <b>STOK MENIPIS!</b>\n\n` +
                   `<b>Layanan:</b> ${service.service_name}\n` +
                   `<b>Negara:</b> ${country.name}\n` +
                   `<b>Stok Tersisa:</b> ${country.stock_total}\n\n` +
                   `<i>Segera tambah stok!</i>`;
    
    await bot.sendMessage(channel, message, {
      parse_mode: 'HTML',
      disable_web_page_preview: true
    });
    
    lastNotificationTime.set(cacheKey, now);
    
  } catch (error) {}
}

async function sendDailyPriceSummary() {
  try {
    const servicesData = await getServicesCached();
    
    if (!servicesData || !servicesData.success) {
      return;
    }

    const services = servicesData.data;
    const targetServices = [];
    
    for (const service of services) {
      const serviceName = service.service_name.toLowerCase();
      
      if (serviceName.includes('whatsapp') || serviceName.includes('telegram')) {
        targetServices.push(service);
      }
      
      if (targetServices.length >= 2) break;
    }
    
    if (targetServices.length === 0) return;
    
    let message = `📊 <b>REKAP HARGA HARIAN</b>\n\n`;
    message += `<i>${new Date().toLocaleDateString('id-ID', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    })}</i>\n\n`;
    
    for (const service of targetServices) {
      const countriesData = await api.getCountries(service.service_code);
      
      if (!countriesData || !countriesData.success || !countriesData.data.length) {
        continue;
      }
      
      const indonesiaCountry = countriesData.data.find(c => 
        c.name.toLowerCase().includes('indonesia') || c.name.toLowerCase().includes('indo')
      );
      
      if (!indonesiaCountry || !indonesiaCountry.pricelist || !indonesiaCountry.pricelist.length) continue;
      
      const server = indonesiaCountry.pricelist[0];
      
      message += `<b>${service.service_name} - Indonesia</b>\n`;
      message += `💰 Rp${server.price.toLocaleString('id-ID')}\n`;
      message += `📊 Rate: ${server.rate}%\n`;
      message += `📦 Stok: ${indonesiaCountry.stock_total}\n`;
      message += `📡 Server: ${indonesiaCountry.pricelist.length}\n\n`;
    }
    
    message += `<i>Pantau terus @${channel.replace('@', '')} untuk update harga!</i>`;
    
    await bot.sendMessage(channel, message, {
      parse_mode: 'HTML',
      disable_web_page_preview: true
    });
    
  } catch (error) {}
}

function scheduleDailySummary() {
  const now = new Date();
  const target = new Date();
  target.setHours(9, 0, 0, 0);
  
  if (now > target) {
    target.setDate(target.getDate() + 1);
  }
  
  const timeUntilTarget = target.getTime() - now.getTime();
  
  setTimeout(() => {
    sendDailyPriceSummary();
    setInterval(sendDailyPriceSummary, 24 * 60 * 60 * 1000);
  }, timeUntilTarget);
}

// ========================= ORDER HISTORY =========================

async function showOrderHistory(chatId, userId, messageId, callbackQueryId) {
    try {
        const transactions = loadTransactions();
        const allOrders = transactions.nokos_orders || [];
        const userOrders = allOrders.filter(order => 
            String(order.userId) === String(userId)
        );
        
        const completedOrders = userOrders.filter(order => 
            order.status === 'completed' || 
            order.status === 'cancelled' || 
            order.status === 'expired'
        );
        
        if (completedOrders.length === 0) {
            await editMessage(chatId, messageId, callbackQueryId,
                'Riwayat Order\n\nBelum ada riwayat order yang selesai.',
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Buat Order', callback_data: 'nokos_menu' }],
                            [{ text: 'Menu Utama', callback_data: 'main_menu' }]
                        ]
                    }
                }
            );
            return;
        }

        const recentOrders = completedOrders.slice(-15).reverse();
        
        let message = '<b>📋 Riwayat Order Anda</b>\n';
        message += `Total Order Anda: ${completedOrders.length}\n\n`;
        
        recentOrders.forEach((order, index) => {
            const orderData = order.data;
            const date = new Date(order.timestamp).toLocaleString('id-ID');
            const maskedPhone = maskPhoneNumber(orderData.phoneNumber);
            
            let statusText = '';
            if (order.status === 'completed') {
                statusText = '✅ Sukses';
            } else if (order.status === 'cancelled') {
                statusText = '❌ Dibatalkan';
            } else if (order.status === 'expired') {
                statusText = '⏱️ Expired';
            } else {
                statusText = order.status || 'unknown';
            }
            
            message += `<b>${index + 1}. ${orderData.service || 'Nokos'}</b>\n`;
            message += `ID: <code>#${orderData.orderId}</code>\n`;
            message += `Nomor: ${maskedPhone}\n`;
            message += `Harga: ${formatCurrency(orderData.price || 0)}\n`;
            
            if (orderData.discount && orderData.discount > 0) {
                message += `Diskon: ${formatCurrency(orderData.discount)}\n`;
                if (orderData.voucher_code) {
                    message += `Voucher: ${orderData.voucher_code}\n`;
                }
            }
            
            message += `Status: ${statusText}\n`;
 
            if (orderData.otp_code && orderData.otp_code !== '-' && orderData.otp_code !== '') {
                message += `OTP: <code>${orderData.otp_code}</code>\n`;
            }
            
            message += `Tanggal: ${date}\n\n`;
        });

        await editMessage(chatId, messageId, callbackQueryId, message, {
            parse_mode: 'HTML',
            disable_web_page_preview: true,
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: 'Order Baru', callback_data: 'nokos_menu' },
                        { text: 'Refresh', callback_data: 'order_history' }
                    ],
                    [
                        { text: 'Menu Utama', callback_data: 'main_menu' }
                    ]
                ]
            }
        });

    } catch (error) {
        await editMessage(chatId, messageId, callbackQueryId,
            '❌ Error\n\nGagal memuat riwayat order.',
            { 
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: 'Coba Lagi', callback_data: 'order_history' }]
                    ]
                }
            }
        );
    }
}

// ========================= DEPOSIT HISTORY =========================

async function showDepositHistory(chatId, userId, messageId, callbackQueryId) {
    try {
        const transactions = loadTransactions();
        const allDeposits = [];
        
        if (transactions.rumahotp_deposits) {
            const userRumahOTP = transactions.rumahotp_deposits.filter(deposit => 
                String(deposit.userId) === String(userId)
            );
            allDeposits.push(...userRumahOTP);
        }
        
        if (transactions.cashify_deposits) { 
            const userCashify = transactions.cashify_deposits.filter(deposit => 
                String(deposit.userId) === String(userId)
            );
            allDeposits.push(...userCashify);
        }
        
        if (transactions.otpnum_deposits) {
            const userOTPNUM = transactions.otpnum_deposits.filter(deposit => 
                String(deposit.userId) === String(userId)
            );
            allDeposits.push(...userOTPNUM);
        }
        
        const successfulDeposits = allDeposits.filter(deposit => 
            deposit.status === 'success' || deposit.status === 'paid' || deposit.status === 'PAID'
        );
        
        successfulDeposits.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
        
        if (successfulDeposits.length === 0) {
            await editMessage(chatId, messageId, callbackQueryId,
                '💰 Riwayat Deposit\n\nBelum ada riwayat deposit yang sukses.',
                { 
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Deposit', callback_data: 'deposit_main' }],
                            [{ text: 'Menu Utama', callback_data: 'main_menu' }]
                        ]
                    }
                }
            );
            return;
        }

        const recentDeposits = successfulDeposits.slice(0, 15);
        
        let message = '<b>💰 Riwayat Deposit Anda</b>\n';
        message += `Total Deposit Anda: ${successfulDeposits.length}\n\n`;
        
        recentDeposits.forEach((deposit, index) => {
            const depositData = deposit.data;
            const date = new Date(deposit.timestamp).toLocaleString('id-ID');
            
            let provider = 'QRIS';
            if (depositData.method) {
                provider = depositData.method;
            }
            
            message += `<b>${index + 1}. Deposit ${formatCurrency(depositData.amount || depositData.total || 0)}</b>\n`;
            message += `ID: <code>#${depositData.id || depositData.no_inv}</code>\n`;
            message += `Jumlah: ${formatCurrency(depositData.amount || depositData.total || 0)}\n`;
            message += `Metode: ${provider}\n`;
            message += `Tanggal: ${date}\n\n`;
        });

        await editMessage(chatId, messageId, callbackQueryId, message, {
            parse_mode: 'HTML',
            disable_web_page_preview: true,
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: 'Deposit Lagi', callback_data: 'deposit_main' },
                        { text: 'Refresh', callback_data: 'deposit_history' }
                    ],
                    [
                        { text: 'Menu Utama', callback_data: 'main_menu' }
                    ]
                ]
            }
        });

    } catch (error) {
        console.error('Error in showDepositHistory:', error);
        await editMessage(chatId, messageId, callbackQueryId,
            '❌ Error\n\nGagal memuat riwayat deposit.',
            { 
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: 'Coba Lagi', callback_data: 'deposit_history' }]
                    ]
                }
            }
        );
    }
}

bot.onText(/^\/finduser(\s|$)/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();
  
  if (!owner_ids.includes(userId)) {
    return bot.sendMessage(chatId,
      "⛔ Akses Ditolak\n\nHanya owner yang bisa menggunakan command ini.",
      { parse_mode: 'HTML' }
    );
  }
  
  const text = msg.text || '';
  const args = text.trim().split(/\s+/);
  
  if (args.length < 2) {
    return bot.sendMessage(chatId,
      `<b>🔍 FIND USER</b>\n\n` +
      `Format: <code>/finduser [user_id|@username|banned]</code>\n\n` +
      `Examples:\n` +
      `• <code>/finduser 123456789</code>\n` +
      `• <code>/finduser @username</code>\n` +
      `• <code>/finduser banned</code>\n\n` +
      `<i>User must have started the bot before</i>`,
      { parse_mode: 'HTML' }
    );
  }
  
  const searchTerm = args[1];
  
  // Simulasikan callback untuk search
  const simulatedCallback = {
    data: 'search_user_quick',
    from: msg.from,
    message: msg,
    id: 'manual_search_' + Date.now()
  };
  
  // Set selection untuk search
  const selection = {
    step: 'search_user_quick',
    timestamp: Date.now()
  };
  userSelections.set(userId, selection);
  
  // Handle search
  if (searchTerm.toLowerCase() === 'banned') {
    const bannedUsers = loadBannedUsers();
    const activeBans = bannedUsers.filter(u => u.status === 'banned');
    
    if (activeBans.length === 0) {
      return bot.sendMessage(chatId,
        'No banned users found.',
        { parse_mode: 'HTML' }
      );
    }
    
    let message = `<b>🚫 BANNED USERS LIST</b>\n\n`;
    message += `<b>Total:</b> ${activeBans.length} users\n\n`;
    
    activeBans.slice(0, 10).forEach((ban, index) => {
      const banDate = new Date(ban.bannedAt).toLocaleDateString('id-ID');
      message += `<b>${index + 1}. User ${ban.userId.substring(0, 8)}...</b>\n`;
      message += `├ Reason: ${ban.reason || 'No reason'}\n`;
      message += `├ Banned by: ${ban.bannedBy || 'System'}\n`;
      message += `└ Date: ${banDate}\n\n`;
    });
    
    if (activeBans.length > 10) {
      message += `... and ${activeBans.length - 10} more\n`;
    }
    
    const keyboard = [];
    
    // Tambahkan tombol untuk 5 banned user pertama
    activeBans.slice(0, 5).forEach((ban, index) => {
      keyboard.push([
        { 
          text: `${index + 1}. ${ban.userId.substring(0, 8)}...`, 
          callback_data: `user_manage_${ban.userId}` 
        }
      ]);
    });
    
    keyboard.push([
      { text: '🚫 Ban Manager', callback_data: 'owner_ban_manager' },
      { text: '👥 User Manager', callback_data: 'owner_user_manager' }
    ]);
    
    return bot.sendMessage(chatId, message, {
      parse_mode: 'HTML',
      reply_markup: { inline_keyboard: keyboard }
    });
  }
  
  // Cari user berdasarkan ID
  if (/^\d+$/.test(searchTerm)) {
    const targetUserId = searchTerm;
    const data = loadData();
    
    if (!data.users?.includes(targetUserId)) {
      return bot.sendMessage(chatId,
        `User <code>${targetUserId}</code> not found in system.\n\n` +
        `User may not have started the bot yet.`,
        {
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [
              [
                { text: '➕ Add to System', callback_data: `force_add_user_${targetUserId}` },
                { text: '🔍 Search Again', callback_data: 'search_user_quick' }
              ]
            ]
          }
        }
      );
    }
    
    return showUserManageDetail(chatId, userId, targetUserId);
  }
  
  // Jika username
  if (searchTerm.startsWith('@')) {
    return bot.sendMessage(chatId,
      `Please use User ID instead of username.\n\n` +
      `You can get User ID from @userinfobot`,
      { parse_mode: 'HTML' }
    );
  }
  
  return bot.sendMessage(chatId,
    'Invalid search term. Please provide User ID (numbers only).',
    { parse_mode: 'HTML' }
  );
});

bot.onText(/\/endcs/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    
    await endCSChat(chatId, userId, null, null, false);
});

// Tambahkan command untuk mengatur keuntungan
bot.onText(/^\/setprofit(\s+(\d+))?$/, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    
    if (!owner_ids.includes(userId)) {
        return bot.sendMessage(chatId,
            "⛔ Akses Ditolak\n\nHanya owner yang bisa menggunakan command ini.",
            { parse_mode: 'HTML' }
        );
    }
    
    const newProfit = match[2] ? parseInt(match[2]) : null;
    
    if (!newProfit || isNaN(newProfit) || newProfit < 0) {
        const currentProfit = Number(config.UNTUNG_NOKOS) || 0;
        return bot.sendMessage(chatId,
            `<b>⚙️ PENGATURAN KEUNTUNGAN NOKOS</b>\n\n` +
            `Keuntungan saat ini: <b>${formatCurrency(currentProfit)}</b>\n\n` +
            `Format: <code>/setprofit [jumlah]</code>\n` +
            `Contoh: <code>/setprofit 10000</code>\n\n` +
            `<i>Nilai minimal: 0 (tanpa keuntungan)</i>`,
            { parse_mode: 'HTML' }
        );
    }
    
    // Update config (perlu restart bot)
    try {
        const configPath = path.join(__dirname, 'config.js');
        let configContent = fs.readFileSync(configPath, 'utf8');
        
        // Update atau tambahkan UNTUNG_NOKOS
        if (configContent.includes('UNTUNG_NOKOS:')) {
            configContent = configContent.replace(
                /UNTUNG_NOKOS:\s*\d+/,
                `UNTUNG_NOKOS: ${newProfit}`
            );
        } else {
            // Tambahkan di akhir module.exports
            configContent = configContent.replace(
                /};?\s*$/,
                `    UNTUNG_NOKOS: ${newProfit},\n};`
            );
        }
        
        fs.writeFileSync(configPath, configContent);
        
        // Update global variable
        config.UNTUNG_NOKOS = newProfit;
        
        await bot.sendMessage(chatId,
            `<b>✅ KEUNTUNGAN BERHASIL DIUBAH</b>\n\n` +
            `Keuntungan baru: <b>${formatCurrency(newProfit)}</b>\n\n` +
            `<i>Perubahan akan aktif untuk order selanjutnya</i>`,
            { parse_mode: 'HTML' }
        );
        
    } catch (error) {
        await bot.sendMessage(chatId,
            `❌ Gagal mengubah keuntungan.\n\nError: ${error.message}`,
            { parse_mode: 'HTML' }
        );
    }
});

// ========================= INITIALIZATION =========================

loadUserNotifications();

setInterval(saveUserNotifications, 30 * 60 * 1000);

// Fungsi untuk membersihkan sesi yang rusak
function cleanupUserSessions() {
    const now = Date.now();
    const oneHour = 60 * 60 * 1000;
    
    for (const [userId, session] of userSelections.entries()) {
        if (session.lastActivity && (now - session.lastActivity > oneHour)) {
            userSelections.delete(userId);
            console.log(`Cleaned up stale session for user ${userId}`);
        }
    }
}

// Tambahkan di bagian interval cleaning
setInterval(() => {
    cleanExpiredOrdersWithRefund();
}, 60 * 1000); // Check every minute

function cleanExpiredOrdersWithRefund() {
    try {
        const transactions = loadTransactions();
        const now = Date.now();
        
        if (transactions.nokos_orders) {
            transactions.nokos_orders = transactions.nokos_orders.filter(order => {
                const orderTime = new Date(order.timestamp).getTime();
                const fiveMinutes = 5 * 60 * 1000;
                const fifteenMinutes = 15 * 60 * 1000;
                
                // Hapus order yang sudah lebih dari 15 menit dan sudah selesai/refunded
                if ((order.status === 'completed' || order.status === 'auto_refunded') && 
                    (now - orderTime > fifteenMinutes)) {
                    return false;
                }
                
                // Hapus order pending/active yang lebih dari 15 menit
                if ((order.status === 'pending' || order.status === 'active') && 
                    (now - orderTime > fifteenMinutes)) {
                    return false;
                }
                
                return true;
            });
            
            saveTransactions(transactions);
        }
    } catch (error) {
        console.error('Error cleaning orders:', error);
    }
}

// Command untuk menghapus pesan OTP secara manual (hanya untuk owner)
bot.onText(/^\/deleteotp(\s+(\d+))?$/, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    
    if (!owner_ids.includes(userId)) {
        return bot.sendMessage(chatId,
            "⛔ Akses Ditolak\n\nHanya owner yang bisa menggunakan command ini.",
            { parse_mode: 'HTML' }
        );
    }
    
    const messageId = match[2] ? parseInt(match[2]) : null;
    
    if (!messageId) {
        // Tampilkan daftar pesan OTP aktif
        if (channelOTPMessages.size === 0) {
            return bot.sendMessage(chatId,
                "Tidak ada pesan OTP aktif saat ini.",
                { parse_mode: 'HTML' }
            );
        }
        
        let message = "📋 <b>DAFTAR PESAN OTP AKTIF</b>\n\n";
        for (const [msgId, data] of channelOTPMessages.entries()) {
            const timeLeft = Math.round((data.timestamp + 5*60*1000 - Date.now()) / 1000);
            message += `• Message ID: <code>${msgId}</code>\n`;
            message += `  Order ID: ${data.orderId}\n`;
            message += `  ⏱️ Hapus dalam: ${timeLeft} detik\n\n`;
        }
        
        message += `Gunakan <code>/deleteotp [message_id]</code> untuk menghapus manual.`;
        
        return bot.sendMessage(chatId, message, {
            parse_mode: 'HTML'
        });
    }
    
    const success = await deleteOTPMessageManually(messageId);
    
    if (success) {
        bot.sendMessage(chatId,
            `✅ Pesan OTP dengan ID <code>${messageId}</code> berhasil dihapus.`,
            { parse_mode: 'HTML' }
        );
    } else {
        bot.sendMessage(chatId,
            `❌ Gagal menghapus pesan OTP dengan ID <code>${messageId}</code>.\n\nPesan mungkin sudah tidak ada atau sudah dihapus.`,
            { parse_mode: 'HTML' }
        );
    }
});

// Command to switch between providers
bot.onText(/^\/setprovider(\s+(\w+))?$/, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    
    if (!owner_ids.includes(userId)) {
        return bot.sendMessage(chatId,
            "⛔ Akses Ditolak\n\nHanya owner yang bisa menggunakan command ini.",
            { parse_mode: 'HTML' }
        );
    }
    
    const newProvider = match[2] ? match[2].toLowerCase() : null;
    const availableProviders = ['rumahotp', 'otpnum', 'cashify'];
    
    if (!newProvider || !availableProviders.includes(newProvider)) {
        const currentProvider = config.active_provider || 'rumahotp';
        return bot.sendMessage(chatId,
            `<b>⚙️ PROVIDER SETTINGS</b>\n\n` +
            `Current provider: <b>${currentProvider}</b>\n\n` +
            `Available providers:\n` +
            `• rumahotp - RumahOTP API (for orders)\n` +
            `• otpnum - OTPNUM API (for orders & deposit)\n` +
            `• cashify - Cashify API (for deposit)\n\n` +
            `Usage: <code>/setprovider [provider_name]</code>\n` +
            `Example: <code>/setprovider otpnum</code>`,
            { parse_mode: 'HTML' }
        );
    }
    
    try {
        const configPath = path.join(__dirname, 'config.js');
        let configContent = fs.readFileSync(configPath, 'utf8');
        
        if (configContent.includes('active_provider:')) {
            configContent = configContent.replace(
                /active_provider:\s*['"][^'"]*['"]/,
                `active_provider: '${newProvider}'`
            );
        } else {
            configContent = configContent.replace(
                /};?\s*$/,
                `  active_provider: '${newProvider}',\n};`
            );
        }
        
        fs.writeFileSync(configPath, configContent);
        
        // Update global config
        config.active_provider = newProvider;
        
        await bot.sendMessage(chatId,
            `<b>✅ PROVIDER BERHASIL DIGANTI</b>\n\n` +
            `Provider baru: <b>${newProvider}</b>\n\n` +
            `Perubahan akan aktif untuk order dan deposit selanjutnya.`,
            { parse_mode: 'HTML' }
        );
        
    } catch (error) {
        await bot.sendMessage(chatId,
            `❌ Gagal mengganti provider.\n\nError: ${error.message}`,
            { parse_mode: 'HTML' }
        );
    }
});

// Command to set OTPNUM server version
bot.onText(/^\/setserver(\s+(\w+))?$/, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    
    if (!owner_ids.includes(userId)) {
        return bot.sendMessage(chatId,
            "⛔ Akses Ditolak\n\nHanya owner yang bisa menggunakan command ini.",
            { parse_mode: 'HTML' }
        );
    }
    
    const newServer = match[2] ? match[2].toLowerCase() : null;
    const availableServers = ['v1', 'v2', 'v3', 'v4'];
    
    if (!newServer || !availableServers.includes(newServer)) {
        const currentServer = otpnumService.getCurrentServer();
        return bot.sendMessage(chatId,
            `<b>⚙️ OTPNUM SERVER SETTINGS</b>\n\n` +
            `Current server: <b>${currentServer}</b>\n\n` +
            `Available servers:\n` +
            `• v1 - Standard API\n` +
            `• v2 - Enhanced services\n` +
            `• v3 - Latest features\n` +
            `• v4 - Advanced features\n\n` +
            `Usage: <code>/setserver [version]</code>\n` +
            `Example: <code>/setserver v4</code>`,
            { parse_mode: 'HTML' }
        );
    }
    
    otpnumService.setServer(newServer);
    
    await bot.sendMessage(chatId,
        `<b>✅ OTPNUM SERVER BERHASIL DIGANTI</b>\n\n` +
        `Server baru: <b>${newServer}</b>\n\n` +
        `URL: ${otpnumService.baseUrl}\n\n` +
        `Perubahan akan aktif untuk order selanjutnya.`,
        { parse_mode: 'HTML' }
    );
});

// Tambahkan fungsi cleanup di interval
setInterval(() => {
  try {
    if (global.csChatSessions) {
      const now = Date.now();
      const oneWeek = 7 * 24 * 60 * 60 * 1000;
      
      for (const [threadId, session] of global.csChatSessions.entries()) {
        const sessionTime = new Date(session.createdAt).getTime();
        
        // Hapus session yang sudah lebih dari 1 minggu dan status closed
        if (session.status === 'closed' && (now - sessionTime > oneWeek)) {
          global.csChatSessions.delete(threadId);
        }
        
        // Auto close pending sessions yang lebih dari 24 jam
        if (session.status === 'pending' && (now - sessionTime > 24 * 60 * 60 * 1000)) {
          session.status = 'closed';
          global.csChatSessions.set(threadId, session);
        }
      }
    }
  } catch (error) {
    console.error('Error cleaning CS sessions:', error);
  }
}, 60 * 60 * 1000); // Jalankan setiap 1 jam

// Jadwalkan cleanup setiap 30 menit
setInterval(cleanupUserSessions, 30 * 60 * 1000);


process.on('SIGINT', () => {
    saveUserNotifications();
    process.exit(0);
});

process.on('SIGTERM', () => {
    saveUserNotifications();
    process.exit(0);
});

// Tambahkan di bagian process handlers (sekitar baris 9940)
process.on('SIGINT', () => {
    // Bersihkan semua timeout sebelum exit
    for (const [messageId, data] of channelOTPMessages.entries()) {
        clearTimeout(data.deleteTimeout);
    }
    channelOTPMessages.clear();
    
    saveUserNotifications();
    process.exit(0);
});

process.on('SIGTERM', () => {
    // Bersihkan semua timeout sebelum exit
    for (const [messageId, data] of channelOTPMessages.entries()) {
        clearTimeout(data.deleteTimeout);
    }
    channelOTPMessages.clear();
    
    saveUserNotifications();
    process.exit(0);
});

console.log('Bot telah dimulai!');