import os
from dotenv import load_dotenv

load_dotenv(".env")

MAX_BOT = int(os.getenv("MAX_BOT", "9999"))

DEVS = list(map(int, os.getenv("DEVS", "1147324679").split()))

API_ID = int(os.getenv("API_ID", "38617387"))

API_HASH = os.getenv("API_HASH", "297a1438c58debb60030dd864621d0aa")

BOT_TOKEN = os.getenv("BOT_TOKEN", "8677519583:AAF6jHA3kgcwFiKbg44Pb3vUaE6WxPp1fc4")

OWNER_ID = int(os.getenv("OWNER_ID", "1147324679"))

BLACKLIST_CHAT = list(map(int, os.getenv("BLACKLIST_CHAT", "-1003659966140").split()))

RMBG_API = os.getenv("RMBG_API", "a6qxsmMJ3CsNo7HyxuKGsP1o")

MONGO_URL = os.getenv("MONGO_URL", "mongodb://ubottme_usuallyif:3ff1cb26f356186de048d49df9a5c8d9ce7e18e4@u0ikyu.h.filess.io:61004/ubottme_usuallyif")

LOGS_MAKER_UBOT = int(os.getenv("LOGS_MAKER_UBOT", "-1003659966140"))