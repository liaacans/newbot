import os
from dotenv import load_dotenv

load_dotenv(".env")

MAX_BOT = int(os.getenv("MAX_BOT", "9999"))

DEVS = list(map(int, os.getenv("DEVS", "1147324679").split()))

API_ID = int(os.getenv("API_ID", "38617387"))

API_HASH = os.getenv("API_HASH", "297a1438c58debb60030dd864621d0aa")

BOT_TOKEN = os.getenv("BOT_TOKEN", "8661341883:AAEKg6_dQjpAaWgK_qYKknSqEIPvHRQtst0")

OWNER_ID = int(os.getenv("OWNER_ID", "1147324679"))

BLACKLIST_CHAT = list(map(int, os.getenv("BLACKLIST_CHAT", "-1003775292291").split()))

RMBG_API = os.getenv("RMBG_API", "a6qxsmMJ3CsNo7HyxuKGsP1o")

MONGO_URL = os.getenv("MONGO_URL", "mongodb+srv://blablabla:Zr1JBpCvlbBUnpO3@cluster0.h42mdkb.mongodb.net/?appName=Cluster0")

LOGS_MAKER_UBOT = int(os.getenv("LOGS_MAKER_UBOT", "-1003775292291"))